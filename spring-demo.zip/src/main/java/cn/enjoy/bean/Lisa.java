package cn.enjoy.bean;

import org.springframework.stereotype.Component;

/**
 * @Classname Lisa
 * @Description TODO
 * @Author Jack
 * Date 2021/1/6 14:13
 * Version 1.0
 */
@Component
public class Lisa {
}
