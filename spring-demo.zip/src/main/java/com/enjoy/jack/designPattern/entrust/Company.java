package com.enjoy.jack.designPattern.entrust;

public interface Company {

    void product();
}
