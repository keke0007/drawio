package com.enjoy.jack.designPattern.decorator;

public interface House {

    //人
    public void people();

    //物品
    public void goods();
}
