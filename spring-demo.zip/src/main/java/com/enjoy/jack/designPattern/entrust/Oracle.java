package com.enjoy.jack.designPattern.entrust;

public class Oracle implements Company {
    @Override
    public void product() {
        System.out.println("oracle product");
    }
}
