package com.enjoy.jack.designPattern.entrust;

public class Sun implements Company {
    @Override
    public void product() {
        System.out.println("sun product");
    }
}
