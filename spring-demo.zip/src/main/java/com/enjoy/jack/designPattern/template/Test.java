package com.enjoy.jack.designPattern.template;

public class Test {
    public static void main(String[] args) {
        爸爸 bb = new 张三();
        bb.生活();
    }
}
