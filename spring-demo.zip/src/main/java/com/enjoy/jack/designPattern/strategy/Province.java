package com.enjoy.jack.designPattern.strategy;

public interface Province {

    public boolean support(String flag);

    public String handler();
}
