package com.enjoy.jack.designPattern.responsibilityChain;

public interface Province {

    public String handler(String flag);
}
