package com.enjoy.jack.designPattern.template;

public class 张三 extends 爸爸 {
    @Override
    public void 爱情() {
        System.out.println("======找肤白貌美大长腿=========");
    }
}
