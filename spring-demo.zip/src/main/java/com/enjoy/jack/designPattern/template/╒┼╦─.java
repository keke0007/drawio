package com.enjoy.jack.designPattern.template;

public class 张四 extends 爸爸 {
    @Override
    public void 爱情() {
        System.out.println("======找有钱的=========");
    }
}
