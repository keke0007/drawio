package com.enjoy.jack.importAware;

import org.springframework.context.annotation.ImportAware;
import org.springframework.core.type.AnnotationMetadata;

/**
 * @Classname ImportAwareClass
 * @Description TODO
 * @Author Jack
 * Date 2020/12/22 15:03
 * Version 1.0
 */
public class ImportAwareClass implements ImportAware {
    @Override
    public void setImportMetadata(AnnotationMetadata importMetadata) {
        System.out.println(importMetadata);
    }
}
