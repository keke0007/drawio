package com.enjoy.jack.customTargetSource;

import com.enjoy.jack.service.StudentServiceImpl;
import org.springframework.aop.framework.autoproxy.target.AbstractBeanFactoryBasedTargetSourceCreator;
import org.springframework.aop.target.AbstractBeanFactoryBasedTargetSource;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;

/**
 * @Classname CustomTargetSourceCreator
 * @Description TODO
 * @Author Jack
 * Date 2021/1/17 11:50
 * Version 1.0
 */
//@Component
public class CustomTargetSourceCreator extends AbstractBeanFactoryBasedTargetSourceCreator {

    @Override
    protected AbstractBeanFactoryBasedTargetSource createBeanFactoryBasedTargetSource(Class<?> beanClass, String beanName) {
        if (getBeanFactory() instanceof ConfigurableListableBeanFactory) {
            if(beanClass.isAssignableFrom(StudentServiceImpl.class)) {
                return new CustomTargetSource();
            }
        }
        return null;
    }
}
