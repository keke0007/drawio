package com.enjoy.jack.customTargetSource;

import org.springframework.aop.target.AbstractBeanFactoryBasedTargetSource;

/**
 * @Classname CustomTargetSource
 * @Description TODO
 * @Author Jack
 * Date 2021/1/17 11:53
 * Version 1.0
 */
public class CustomTargetSource extends AbstractBeanFactoryBasedTargetSource {
    @Override
    public Object getTarget() throws Exception {
        return getBeanFactory().getBean(getTargetBeanName());
    }
}
