package com.enjoy.jack.customBean;

import com.enjoy.jack.annotation.MyService;

/**
 * @Classname James13
 * @Description TODO
 * @Author Jack
 * Date 2020/12/13 21:50
 * Version 1.0
 */
@MyService
public class James13 {
}
