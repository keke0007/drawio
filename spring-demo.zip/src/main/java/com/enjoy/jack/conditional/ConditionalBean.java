package com.enjoy.jack.conditional;

import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;

/**
 * @Classname ConditionalBean
 * @Description TODO
 * @Author Jack
 * Date 2021/1/4 16:40
 * Version 1.0
 */
@Component
@Conditional(value = {CustomCondition.class,CustomCondition1.class})
//@ConditionOnClass(name = "com.enjoy.jack.bean.circular.CircularRefConB")
//@ConditionOnBean(CQ.class)
@ConditionOnProperty(name = "cn.enjoy.flag")
public class ConditionalBean {
}
