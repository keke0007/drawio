package com.enjoy.jack.conditional;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * @Classname CustomCondition
 * @Description TODO
 * @Author Jack
 * Date 2021/1/4 16:41
 * Version 1.0
 */
public class CustomCondition implements Condition {
    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
        return true;
    }
}
