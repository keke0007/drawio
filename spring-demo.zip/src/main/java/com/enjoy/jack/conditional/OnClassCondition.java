package com.enjoy.jack.conditional;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.util.ClassUtils;

import java.util.Map;

/**
 * @Classname OnClassCondition
 * @Description TODO
 * @Author Jack
 * Date 2021/1/4 17:07
 * Version 1.0
 */
public class OnClassCondition implements Condition {
    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
        if(metadata.isAnnotated(ConditionOnClass.class.getName())) {
            Map<String, Object> annotationAttributes = metadata.getAnnotationAttributes(ConditionOnClass.class.getName());
            try {
                ClassUtils.forName(annotationAttributes.get("name").toString(),ClassUtils.getDefaultClassLoader());
                return true;
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
                return false;
            }
        }
        return false;
    }
}
