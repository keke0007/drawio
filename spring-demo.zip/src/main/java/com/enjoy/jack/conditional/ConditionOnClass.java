package com.enjoy.jack.conditional;

import org.springframework.context.annotation.Conditional;

import java.lang.annotation.*;

@Target({ ElementType.TYPE, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Conditional(value = OnClassCondition.class)
public @interface ConditionOnClass {
    Class<?>[] value() default {};

    String[] name() default {};
}
