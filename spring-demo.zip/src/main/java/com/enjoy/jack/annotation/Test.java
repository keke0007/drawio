package com.enjoy.jack.annotation;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.concurrent.atomic.AtomicInteger;

public class Test {

    private static AtomicInteger sum = new AtomicInteger((int) LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")));


    public static int nextId(){
        return sum.getAndIncrement();
    }

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            System.out.println(nextId());
        }
    }
}
