package com.enjoy.jack.event;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextStoppedEvent;
import org.springframework.stereotype.Component;

/**
 * @Classname ContextStoppedListener
 * @Description TODO
 * @Author Jack
 * Date 2020/12/17 21:32
 * Version 1.0
 */
@Component
public class ContextStoppedListener implements ApplicationListener<ContextStoppedEvent> {
    @Override
    public void onApplicationEvent(ContextStoppedEvent event) {
        System.out.println("========ContextStoppedListener");
    }
}
