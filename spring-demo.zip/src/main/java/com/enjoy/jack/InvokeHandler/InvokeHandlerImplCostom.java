package com.enjoy.jack.InvokeHandler;

import cn.enjoy.handler.InvokeHandler;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * @Classname InvokeHandlerImplCostom
 * @Description TODO
 * @Author Jack
 * Date 2021/1/10 21:41
 * Version 1.0
 */
public class InvokeHandlerImplCostom implements InvokeHandler {
    @Override
    public boolean support(String s) {
        return "Jack".equalsIgnoreCase(s);
    }

    @Override
    public Object invoke(Object o, Method method, Object[] objects, Field field, String[] strings) {
        System.out.println("========InvokeHandlerImplCostom.Jack==========");
        return null;
    }
}
