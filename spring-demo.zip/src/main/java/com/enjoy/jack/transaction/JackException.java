package com.enjoy.jack.transaction;

/**
 * @Classname JackException
 * @Description TODO
 * @Author Jack
 * Date 2021/1/26 14:26
 * Version 1.0
 */
public class JackException extends RuntimeException {
}
