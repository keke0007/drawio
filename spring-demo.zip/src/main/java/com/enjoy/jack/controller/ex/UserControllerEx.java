package com.enjoy.jack.controller.ex;

import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * @Classname UserControllerEx
 * @Description TODO
 * @Author Jack
 * Date 2021/2/25 14:11
 * Version 1.0
 */
//@ControllerAdvice
public class UserControllerEx {

    @ExceptionHandler(Exception.class)
    public String exceptionHandler() {
        return "error";
    }
}
