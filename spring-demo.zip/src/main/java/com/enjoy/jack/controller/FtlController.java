package com.enjoy.jack.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

/**
 * @Classname FtlController
 * @Description TODO
 * @Author Jack
 * Date 2021/2/22 16:12
 * Version 1.0
 */
@Controller
public class FtlController {

    @RequestMapping("/freemarker")
    public String freemarker(Model model) {

        List<User> list = new ArrayList<>();
        list.add(new User(1, "jack", 25));
        list.add(new User(2, "james", 26));
        list.add(new User(3, "lison", 23));
        list.add(new User(4, "king", 24));

        // 需要一个Model对象
        model.addAttribute("list", list);
        return "user";
    }
}
