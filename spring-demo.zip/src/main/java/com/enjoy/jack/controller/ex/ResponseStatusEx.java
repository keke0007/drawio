package com.enjoy.jack.controller.ex;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @Classname ResponseStatusEx
 * @Description TODO
 * @Author Jack
 * Date 2021/2/25 14:26
 * Version 1.0
 */
@ResponseStatus(code = HttpStatus.FORBIDDEN,reason = "Jack error!")
public class ResponseStatusEx extends RuntimeException {
    public ResponseStatusEx(String x) {
        super(x);
    }
}
