package com.enjoy.jack.controller.beanName;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @Classname BeanNameController
 * @Description TODO
 * @Author Jack
 * Date 2021/2/4 16:27
 * Version 1.0
 */
@Component("/order/index")
public class BeanNameController extends AbstractController {
    @Override
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
        System.out.println("====/order/index");
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("ok");
        return modelAndView;
    }
}
