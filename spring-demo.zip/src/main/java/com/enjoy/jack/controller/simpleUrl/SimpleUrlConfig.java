package com.enjoy.jack.controller.simpleUrl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;

import java.util.Properties;

/**
 * @Classname SimpleUrlConfig
 * @Description TODO
 * @Author Jack
 * Date 2021/2/4 16:49
 * Version 1.0
 */
@Configuration
public class SimpleUrlConfig {

    @Bean
    public SimpleUrlHandlerMapping simpleUrlHandlerMapping() {
        SimpleUrlHandlerMapping suhm = new SimpleUrlHandlerMapping();
        Properties properties = new Properties();
        properties.put("area/index","areaController");
        suhm.setMappings(properties);
        return suhm;
    }
}
