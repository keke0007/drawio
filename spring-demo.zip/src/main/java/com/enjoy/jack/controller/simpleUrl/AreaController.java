package com.enjoy.jack.controller.simpleUrl;

import org.springframework.stereotype.Component;
import org.springframework.web.HttpRequestHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @Classname AreaController
 * @Description TODO
 * @Author Jack
 * Date 2021/2/4 16:51
 * Version 1.0
 */
@Component
public class AreaController implements HttpRequestHandler {
    @Override
    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("======AreaController");
        PrintWriter writer = response.getWriter();
        writer.println("<h1>==========Jack</h1>");
        writer.flush();
        writer.close();
    }
}
