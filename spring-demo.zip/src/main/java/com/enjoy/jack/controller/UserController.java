package com.enjoy.jack.controller;

import com.alibaba.fastjson.JSONObject;
import com.enjoy.jack.controller.ex.ResponseStatusEx;
import com.enjoy.jack.pojo.ConsultConfigArea;
import com.enjoy.jack.service.AreaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private AreaService areaService;

    @RequestMapping("/ok")
    public String queryUser(@RequestParam(required = false) String language, HttpSession session) {
        return "ok";
    }

    @RequestMapping("/exceptionTest")
    public @ResponseBody
    String exceptionTest(String param) {
        if(!param.equalsIgnoreCase("ok")) {
            throw new ResponseStatusEx("xs");
        }
        return "ok";
    }

//    @ExceptionHandler(Exception.class)
    public String exceptionHandler() {
        return "error";
    }

//    @CrossOrigin(origins = "*"
//            ,allowedHeaders = "x-requested-with"
//            ,allowCredentials = "true"
//            ,maxAge = 3600
//            ,methods = {RequestMethod.GET,RequestMethod.POST,RequestMethod.OPTIONS,RequestMethod.DELETE})
    @RequestMapping("/queryArea")
    public @ResponseBody
    List<ConsultConfigArea> queryArea(@RequestParam(required = false) String areaCode) {
        Map map = new HashMap<>();
        map.put("areaCode",areaCode);
        return areaService.queryAreaFromDB(map);
    }


    @RequestMapping("/queryAreaJs")
    public @ResponseBody
    String queryAreaJs(@RequestParam(required = false) String areaCode, @RequestParam String callback) {
        Map map = new HashMap<>();
        map.put("areaCode",areaCode);

        List<ConsultConfigArea> areas = areaService.queryAreaFromDB(map);
        return callback + "(" + JSONObject.toJSONString(areas) + ");";
    }
}
