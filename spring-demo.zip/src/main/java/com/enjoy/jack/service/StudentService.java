package com.enjoy.jack.service;

import java.util.List;

public interface StudentService {
    void eat(String a);

    String sleep(List b);
}
