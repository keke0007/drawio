package com.enjoy.jack.service.goods;


import com.enjoy.jack.pojo.ZgGoods;
import com.enjoy.jack.transaction.JamesException;

import java.util.List;

public interface GoodsService {

    void addGoods(ZgGoods zgGoods) throws JamesException;

    List<ZgGoods> queryAll();
}
