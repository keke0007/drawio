package com.enjoy.jack.service.transaction;


import com.enjoy.jack.pojo.ConsultConfigArea;
import com.enjoy.jack.pojo.ZgGoods;
import com.enjoy.jack.transaction.JamesException;

public interface TransationService {

    void transation(ConsultConfigArea area, ZgGoods zgGoods) throws JamesException;

    int getTicket();

    int getTicketModeOne();
}
