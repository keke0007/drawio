package com.enjoy.jack.service.transaction;

import com.enjoy.jack.dao.CommonMapper;
import com.enjoy.jack.pojo.ConsultConfigArea;
import com.enjoy.jack.pojo.ZgGoods;
import com.enjoy.jack.pojo.ZgTicket;
import com.enjoy.jack.service.AreaService;
import com.enjoy.jack.service.goods.GoodsService;
import com.enjoy.jack.transaction.JamesException;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.ConnectionHolder;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("transationServiceImpl")
public class TransationServiceImpl implements TransationService {

    @Autowired
    AreaService areaService;

    @Autowired
    GoodsService goodsService;

    @Autowired
    CommonMapper commonMapper;

    @Autowired
    TransationService transationService;

    @Autowired
    private DataSource dataSource;

    @Transactional
    @Async
    @Override
    public void transation(ConsultConfigArea area, ZgGoods zgGoods) throws JamesException {
        areaService.addArea(area);
        goodsService.addGoods(zgGoods);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public int addArea(ConsultConfigArea area) {
        ConnectionHolder resource = (ConnectionHolder) TransactionSynchronizationManager.getResource(dataSource);
        System.out.println(resource.getConnection());
        int i = commonMapper.addArea(area);
        return i;
    }

    @Transactional
    public void addGoods(ZgGoods zgGoods) {
        ConnectionHolder resource = (ConnectionHolder) TransactionSynchronizationManager.getResource(dataSource);
        System.out.println(resource.getConnection());
        int i = commonMapper.addGood(zgGoods);
//        if (true) throw new RuntimeException("ssf");
    }


    @Transactional
    @Override
    public int getTicket() {
        //1、获取锁
        List<ZgTicket> zgTickets = commonMapper.queryTicketById("12306");
        Map lockmap = new HashMap();
        lockmap.put("ticketId", "12306");
        lockmap.put("version", zgTickets.get(0).getVersion());
        int i = commonMapper.updateLock(lockmap);

        if (i > 0) {
            //抢票
            ZgTicket zgTicket = zgTickets.get(0);
            zgTicket.setTicketCount(2);
            int i1 = commonMapper.updateTicket(zgTicket);
        } else {
            //继续抢
            ((TransationService) AopContext.currentProxy()).getTicket();
        }
        return 0;
    }

    @Autowired
    PlatformTransactionManager platformTransactionManager;

    public void xxx() {
        DefaultTransactionDefinition defaultTransactionDefinition = new DefaultTransactionDefinition();
        defaultTransactionDefinition.setPropagationBehavior(0);
        TransactionStatus transaction = platformTransactionManager.getTransaction(defaultTransactionDefinition);

        try {
            System.out.println("业务代码");
        } catch (Exception e) {
            platformTransactionManager.rollback(transaction);
        }

        platformTransactionManager.commit(transaction);
    }


    @Autowired
    private TransactionTemplate transactionTemplate;

    @Override
    public int getTicketModeOne() {
        Integer execute = transactionTemplate.execute(status -> {
            //1、获取锁
            List<ZgTicket> zgTickets = commonMapper.queryTicketById("12306");
            Map lockmap = new HashMap();
            lockmap.put("ticketId", "12306");
            lockmap.put("version", zgTickets.get(0).getVersion());
            int i = commonMapper.updateLock(lockmap);

            if (i > 0) {
                //抢票
                ZgTicket zgTicket = zgTickets.get(0);
                zgTicket.setTicketCount(2);
                int i1 = commonMapper.updateTicket(zgTicket);
            }
            return i;
        });

        if (execute == 0) {
            //继续抢
            getTicketModeOne();
        }
        return 0;
    }
}
