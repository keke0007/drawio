package com.enjoy.jack.service.goods;

import com.enjoy.jack.dao.CommonMapper;
import com.enjoy.jack.pojo.ZgGoods;
import com.enjoy.jack.transaction.JackException;
import com.enjoy.jack.transaction.JamesException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.util.List;

@Service
public class GoodsServiceImpl implements GoodsService {

    @Autowired
    CommonMapper commonMapper;

    @Autowired
    private DataSource dataSource;

    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = JackException.class)
    @Override
    public void addGoods(ZgGoods zgGoods) throws JamesException {
        int i = commonMapper.addGood(zgGoods);
    }

    @Transactional(readOnly = true)
    @Override
    public List<ZgGoods> queryAll() {
        return commonMapper.queryAll();
    }
}
