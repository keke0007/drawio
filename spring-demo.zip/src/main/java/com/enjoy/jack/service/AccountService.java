package com.enjoy.jack.service;

/**
 * @Classname AccountService
 * @Description TODO
 * @Author Jack
 * Date 2020/12/3 17:20
 * Version 1.0
 */
public interface AccountService {
    String queryAccount();
}
