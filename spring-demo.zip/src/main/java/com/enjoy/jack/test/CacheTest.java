package com.enjoy.jack.test;

import com.enjoy.jack.bean.scanBean.ScanBean;
import com.enjoy.jack.service.cache.CacheService;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * @Classname CacheTest
 * @Description TODO
 * @Author Jack
 * Date 2021/1/26 15:02
 * Version 1.0
 */
public class CacheTest {
    @Test
    public void test1() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        CacheService bean = applicationContext.getBean(CacheService.class);
        bean.queryData("29843921");
    }
}
