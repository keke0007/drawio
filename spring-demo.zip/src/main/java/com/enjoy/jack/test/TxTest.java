package com.enjoy.jack.test;

import com.alibaba.fastjson.JSONObject;
import com.enjoy.jack.bean.scanBean.ScanBean;
import com.enjoy.jack.pojo.ConsultConfigArea;
import com.enjoy.jack.pojo.ZgGoods;
import com.enjoy.jack.service.AreaService;
import com.enjoy.jack.service.transaction.TransationService;
import com.enjoy.jack.transaction.JamesException;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Classname TxTest
 * @Description TODO
 * @Author Jack
 * Date 2021/1/21 13:58
 * Version 1.0
 */
public class TxTest {

    @Test
    public void test1() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        AreaService bean = applicationContext.getBean(AreaService.class);
        Map param = new HashMap();
        param.put("areaCode","HB1");
        List<ConsultConfigArea> consultConfigAreas = bean.queryAreaFromDB(param);
        System.out.println(JSONObject.toJSONString(consultConfigAreas));
    }

    @Test
    public void propagationTest() throws JamesException {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        String areaStr = "HN36";
        String goodsStr = "iphone 36";
        TransationService transationService = applicationContext.getBean(TransationService.class);
        ConsultConfigArea area = new ConsultConfigArea();
        area.setAreaCode(areaStr);
        area.setAreaName(areaStr);
        area.setState("1");

        ZgGoods zgGoods = new ZgGoods();
        zgGoods.setGoodCode(goodsStr);
        zgGoods.setGoodName(goodsStr);
        zgGoods.setCount(100);
        transationService.transation(area,zgGoods);
    }
}
