package com.enjoy.jack.test;

import cn.enjoy.bean.Lisa;
import com.enjoy.jack.bean.DeferredImportSelector.LisonSelectImport;
import com.enjoy.jack.bean.DeferredImportSelector.SelectImportBean;
import com.enjoy.jack.bean.annoBean.Docker;
import com.enjoy.jack.bean.annoBean.Lison;
import com.enjoy.jack.bean.annoBean.LisonFactory;
import com.enjoy.jack.bean.innerClass.InnerClassDemo;
import com.enjoy.jack.bean.scanBean.ScanBean;
import com.enjoy.jack.service.AreaService;
import com.xiangxue.jack.beans.Tearcher;
import org.junit.Test;
import org.springframework.aop.support.AopUtils;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


/**
 * @Classname AnnoTest
 * @Description TODO
 * @Author Jack
 * Date 2020/12/29 21:32
 * Version 1.0
 */
public class AnnoTest {

    @Test
    public void test1() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        Lison lison = applicationContext.getBean("lison",Lison.class);
        System.out.println(lison.hashCode());
        LisonFactory lisonFactory = applicationContext.getBean(LisonFactory.class);
        System.out.println(lisonFactory.getLison().hashCode());
    }

    @Test
    public void test2() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        InnerClassDemo.SpringSource s = applicationContext.getBean(InnerClassDemo.SpringSource.class);
        System.out.println(s);
    }

    @Test
    public void test3() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        SelectImportBean bean = applicationContext.getBean(SelectImportBean.class);
        System.out.println(bean);
    }

    @Test
    public void test4() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        LisonSelectImport bean = applicationContext.getBean(LisonSelectImport.class);
        System.out.println(bean);
    }

    @Test
    public void test5() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        Docker bean = applicationContext.getBean(Docker.class);
        System.out.println(bean.hashCode());
    }

    @Test
    public void test6() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        Lisa bean = applicationContext.getBean(Lisa.class);
        System.out.println(bean);
    }

    @Test
    public void test7() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        Tearcher bean = applicationContext.getBean(Tearcher.class);
        System.out.println(bean);
    }

    @Test
    public void test8() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        AreaService bean = applicationContext.getBean(AreaService.class);
        System.out.println(bean);
//        bean.queryAreaFromDB("ss");
        AopUtils.isAopProxy(bean);
    }
}
