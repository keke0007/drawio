package com.enjoy.jack.test;

import com.enjoy.jack.aop.scopedproxy.MyBean;
import com.enjoy.jack.bean.scanBean.ScanBean;
import com.enjoy.jack.service.StudentService;
import org.junit.Test;
import org.springframework.aop.TargetSource;
import org.springframework.aop.framework.AdvisedSupport;
import org.springframework.aop.support.AopUtils;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.util.ReflectionUtils;
import sun.misc.ProxyGenerator;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;

/**
 * @Classname AopTest
 * @Description TODO
 * @Author Jack
 * Date 2021/1/11 21:57
 * Version 1.0
 */
public class AopTest {
    @Test
    public void test1() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        StudentService bean = applicationContext.getBean(StudentService.class);
        if (AopUtils.isAopProxy(bean)) {
            System.out.println(bean);
            try {
                Field h = bean.getClass().getSuperclass().getDeclaredField("h");
                ReflectionUtils.makeAccessible(h);
                Object jdkDync = ReflectionUtils.getField(h, bean);
                System.out.println(jdkDync);

                Field advised = jdkDync.getClass().getDeclaredField("advised");
                ReflectionUtils.makeAccessible(advised);
                AdvisedSupport proxyFactory = (AdvisedSupport) ReflectionUtils.getField(advised, jdkDync);
                System.out.println(proxyFactory);
                TargetSource targetSource = proxyFactory.getTargetSource();
                System.out.println(targetSource.getTarget());
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Test
    public void test2() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        StudentService bean = applicationContext.getBean(StudentService.class);
        System.out.println(bean);
//        bean.sleep(new ArrayList());
        bean.eat("Jack1");
    }

    @Test
    public void test3() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(ScanBean.class);
        MyBean bean = applicationContext.getBean(MyBean.class);
        for (int i = 0; i < 10; i++) {
            bean.tet();
        }
    }

    @Test
    public void test4() {
        byte[] $Proxy0s = ProxyGenerator.generateProxyClass("$Proxy0", new Class[]{StudentService.class});

        try {
            FileOutputStream fileOutputStream = new FileOutputStream("$Proxy0.class");
            fileOutputStream.write($Proxy0s);
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
