package com.enjoy.jack.SmartInstantiationAwareBeanPostProcessor;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;

/**
 * @Classname SmartInstantiationAwareBeanPostProcessorDemo
 * @Description TODO
 * @Author Jack
 * Date 2020/12/24 21:00
 * Version 1.0
 */
//@Component
public class SmartInstantiationAwareBeanPostProcessorDemo implements SmartInstantiationAwareBeanPostProcessor {
    @Override
    public Object getEarlyBeanReference(Object bean, String beanName) throws BeansException {
        return bean;
    }
}
