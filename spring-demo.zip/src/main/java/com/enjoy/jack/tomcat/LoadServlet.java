package com.enjoy.jack.tomcat;

import javax.servlet.ServletContext;

public interface LoadServlet {

    void loadOnstarp(ServletContext servletContext);
}