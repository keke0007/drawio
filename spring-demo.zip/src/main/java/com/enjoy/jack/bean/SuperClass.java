package com.enjoy.jack.bean;

/**
 * @Classname SuperClass
 * @Description TODO
 * @Author Jack
 * Date 2020/12/21 22:16
 * Version 1.0
 */
public interface SuperClass<T> {
    T method(T param);
}
