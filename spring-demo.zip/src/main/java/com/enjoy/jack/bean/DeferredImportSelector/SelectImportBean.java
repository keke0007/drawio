package com.enjoy.jack.bean.DeferredImportSelector;

/**
 * @Classname SelectImportBean
 * @Description TODO
 * @Author Jack
 * Date 2021/1/4 16:24
 * Version 1.0
 */
public class SelectImportBean {
}
