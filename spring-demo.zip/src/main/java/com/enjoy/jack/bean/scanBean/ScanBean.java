package com.enjoy.jack.bean.scanBean;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 * @Classname ScanBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/29 21:33
 * Version 1.0
 */

@ComponentScans({@ComponentScan("xx"), @ComponentScan("aa")})
@Component
@ComponentScan(value = "com.enjoy.jack"/*,includeFilters = ,basePackages = */)
//<context:property-placeholder location="classpath:application.properties"/>
@PropertySource(name = "jack", value = "classpath:application.properties")
public class ScanBean {
}
