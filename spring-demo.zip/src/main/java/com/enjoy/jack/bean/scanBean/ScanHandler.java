package com.enjoy.jack.bean.scanBean;

import cn.enjoy.config.AutoConfig;
import cn.enjoy.config.ImportScanBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * @Classname ScanHandler
 * @Description TODO
 * @Author Jack
 * Date 2021/1/10 20:27
 * Version 1.0
 */
@Configuration
//扫描不带注解的包的功能
//@BeansScaner("com.xiangxue.jack")
@Import({ImportScanBean.class, AutoConfig.class})
public class ScanHandler {
}
