package com.enjoy.jack.bean;

import lombok.Data;

@Data
public class PropertyBean {

    private String username;

    private String password;
}
