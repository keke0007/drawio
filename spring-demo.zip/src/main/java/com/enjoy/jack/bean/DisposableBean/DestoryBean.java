package com.enjoy.jack.bean.DisposableBean;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.stereotype.Component;

/**
 * @Classname DestoryBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/27 20:19
 * Version 1.0
 */
@Component
public class DestoryBean implements DisposableBean {
    @Override
    public void destroy() throws Exception {
        System.out.println("==DestoryBean.destroy");
    }
}
