package com.enjoy.jack.bean;

/**
 * @Classname SubClass
 * @Description TODO
 * @Author Jack
 * Date 2020/12/21 22:17
 * Version 1.0
 */
public class SubClass implements SuperClass<String> {
    @Override
    public String method(String param) {
        return param;
    }
}
