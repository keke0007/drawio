package com.enjoy.jack.bean.ImportBeanDefinitionRegistrar;

import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.stereotype.Component;

/**
 * @Classname ImportBeanDefinitionRegistrarDemo
 * @Description TODO
 * @Author Jack
 * Date 2020/12/29 14:03
 * Version 1.0
 */
@Component
public class ImportBeanDefinitionRegistrarDemo implements ImportBeanDefinitionRegistrar {
    @Override
    public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry) {

    }
}
