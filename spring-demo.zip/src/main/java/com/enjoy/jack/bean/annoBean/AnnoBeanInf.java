package com.enjoy.jack.bean.annoBean;

import org.springframework.context.annotation.Bean;

public interface AnnoBeanInf {
    @Bean
    void xx();
    @Bean
    void aa();
}
