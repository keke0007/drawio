package com.enjoy.jack.bean.annoBean;

import org.springframework.beans.factory.FactoryBean;

/**
 * @Classname LiLi
 * @Description TODO
 * @Author Jack
 * Date 2021/1/7 15:42
 * Version 1.0
 */
public class LiLi implements FactoryBean {
    @Override
    public Object getObject() throws Exception {
        return new Docker();
    }

    @Override
    public Class<?> getObjectType() {
        return Docker.class;
    }

    public void xae() {
        System.out.println("xae");
    }
}
