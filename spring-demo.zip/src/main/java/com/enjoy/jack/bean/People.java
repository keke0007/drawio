package com.enjoy.jack.bean;

public interface People {

    public void showsix();
}
