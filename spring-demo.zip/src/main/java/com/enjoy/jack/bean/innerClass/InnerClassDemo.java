package com.enjoy.jack.bean.innerClass;

import com.enjoy.jack.bean.Student;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * @Classname InnerClassDemo
 * @Description TODO
 * @Author Jack
 * Date 2021/1/4 14:46
 * Version 1.0
 */
@Component
public class InnerClassDemo {

    @Component
    public class SpringSource {

        @Bean
        public Student student() {
            return new Student();
        }

    }

    @Component
    public class Mybatis {

    }
}
