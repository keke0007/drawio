package com.enjoy.jack.bean.annoBean;

import com.enjoy.jack.conditional.CustomCondition;
import com.enjoy.jack.conditional.CustomCondition1;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

/**
 * @Classname AnnoBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/31 15:03
 * Version 1.0
 */
//@Component
@Configuration
public class AnnoBean implements AnnoBeanInf {

    /**
     MethodMetadata
     BeanDefinition对象
     factoryBeanName = AnnoBean
     factoryMethodName = lison
    */
    @Conditional(value = {CustomCondition.class, CustomCondition1.class})
    @Primary
    @Bean
    public Lison lison() {
        return new Lison();
    }

    /**
     BeanDefinition对象
     factoryBeanName = AnnoBean
     factoryMethodName = lison
    */
    @Bean
    public LisonFactory lisonFactory() throws Exception {
        LisonFactory lisonFactory = new LisonFactory();
        //lison() beanFactory.getBean(id)  缓存里面
        lisonFactory.setLison(this.lison());
//        LiLi liLi = this.liLi();
        // beanFactory.getBean()
//        Object object = liLi.getObject();
//        System.out.println("lili getObject : " + object.hashCode());
//        liLi.xae();
        return lisonFactory;
    }

    @Bean
    public LiLi liLi() {
        return new LiLi();
    }

    @Override
    public void xx() {

    }

    @Override
    public void aa() {

    }
}
