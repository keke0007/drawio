package com.enjoy.jack.bean.annoBean;

import lombok.Data;

/**
 * @Classname LisonFactory
 * @Description TODO
 * @Author Jack
 * Date 2020/12/31 15:04
 * Version 1.0
 */
@Data
public class LisonFactory {
    private Lison lison;
}
