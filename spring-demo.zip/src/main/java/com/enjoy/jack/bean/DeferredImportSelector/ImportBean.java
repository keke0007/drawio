package com.enjoy.jack.bean.DeferredImportSelector;

import com.enjoy.jack.aware.AwareBean;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

/**
 * @Classname ImportBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/29 14:18
 * Version 1.0
 */
@Component
//Import虽然是实例化一个类，Import进来的类可以实现一些接口
@Import({DeferredImportSelectorDemo.class,/*LisonSelectImport.class,*/ AwareBean.class})
//@ImportResource("classpath:spring.xml")
public class ImportBean {
}
