package com.enjoy.jack.bean.propertiesbean;


import lombok.Data;
import org.springframework.stereotype.Component;

/**
 * @Classname PropertiesBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/27 20:34
 * Version 1.0
 */
@Data
@Component
public class PropertiesBean {

    private String name;

    private String password;
}
