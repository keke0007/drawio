package com.enjoy.jack.bean;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/**
 * @Classname ValueBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/27 16:24
 * Version 1.0
 */
@Configuration
@Data
public class ValueBean implements EnvironmentAware {

    /**
        从environment里面
        从本地配置中拿值
    */
    @Value("${enjoy.name}")
    private String name;


    @Override
    public void setEnvironment(Environment environment) {
        System.out.println("ValueBean.setEnvironment");
        System.out.println(name);
        System.out.println(environment.getProperty("enjoy.name"));
    }
}
