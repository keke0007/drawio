package com.enjoy.jack.aop.aspectj;

import com.enjoy.jack.annotation.EasyCache;
import org.aopalliance.intercept.MethodInvocation;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.aop.interceptor.ExposeInvocationInterceptor;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.List;

@Component
@Aspect
public class AspectAnnotation {

    @Pointcut(value = "execution(public * com.enjoy.jack.service.*.*(..)) && args(a)",argNames = "a")
    public void pc2(List a){}

    @Pointcut(value = "execution(public * com.enjoy.jack.service.*.*(..))")
    public void pc1(){}

    @Before("pc1()")
    public void Abefore13() {
        MethodInvocation methodInvocation = ExposeInvocationInterceptor.currentInvocation();
        Method method = methodInvocation.getMethod();
        boolean annotationPresent = method.isAnnotationPresent(EasyCache.class);
        System.out.println("==============AspectAnnotation Abefore13=========" + annotationPresent);
    }

    @Before("pc1()")
    public void before13() {
        MethodInvocation methodInvocation = ExposeInvocationInterceptor.currentInvocation();
        System.out.println("==============AspectAnnotation before13=========");

    }

    @Before("pc1()")
    public void before132() {
        System.out.println("==============AspectAnnotation before132=========");

    }

    @Before("pc1()")
    public void before1() {
        System.out.println("==============AspectAnnotation before1=========");

    }

    @Before(value = "pc1()",argNames = "joinPoint")
    public void before2(JoinPoint joinPoint) {
        System.out.println("==============AspectAnnotation before2=========");

    }

    @After(value = "pc1()")
    public void AAfter() {
        System.out.println("==============AspectAnnotation AAfter=========");

    }

    @Around(value = "pc2(a)",argNames = "a")
    public Object around(ProceedingJoinPoint joinPoint, List a) throws Throwable {
        System.out.println("==============AspectAnnotation around前置通知=========");
        Object result = joinPoint.proceed();
        System.out.println("==============AspectAnnotation around后置通知=========");

        return result;
    }

    @Around(value = "pc1()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        System.out.println("==============AspectAnnotation around前置通知=========");
        Object result = joinPoint.proceed();
        System.out.println("==============AspectAnnotation around后置通知=========");

        return result;
    }

    @AfterReturning(value = "pc1()",returning = "retVal")
    public void afterReturning(JoinPoint joinPoint, Object retVal) {
        System.out.println("==============AspectAnnotation 后置通知  拿返回值=========" + retVal);
    }

    @AfterThrowing(value = "pc1()",throwing = "e")
    public void afterThrowing(JoinPoint joinPoint, Throwable e) {
        System.out.println("AspectAnnotation 异常通知  拿异常=========" + e);
    }
}
