package com.enjoy.jack.aop.cglib;

public interface UserService {
    public String doSomething0(String param);

    public String doSomething1(String param);

    public String doSomething2(String param);

    public String myMethod(String param);
}
