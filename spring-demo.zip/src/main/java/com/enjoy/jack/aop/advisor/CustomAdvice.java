package com.enjoy.jack.aop.advisor;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

/**
 * @Classname CustomAdvice
 * @Description TODO
 * @Author Jack
 * Date 2021/1/13 15:13
 * Version 1.0
 */
public class CustomAdvice implements MethodInterceptor {
    @Override
    public Object invoke(MethodInvocation invocation) throws Throwable {
        return invocation.proceed();
    }
}
