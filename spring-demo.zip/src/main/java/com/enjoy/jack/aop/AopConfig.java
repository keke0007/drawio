package com.enjoy.jack.aop;

import org.springframework.stereotype.Component;

/**
 * @Classname AopConfig
 * @Description TODO
 * @Author Jack
 * Date 2021/1/12 14:09
 * Version 1.0
 */
@Component
//@EnableAspectJAutoProxy(proxyTargetClass = false,exposeProxy = true)
public class AopConfig {
}
