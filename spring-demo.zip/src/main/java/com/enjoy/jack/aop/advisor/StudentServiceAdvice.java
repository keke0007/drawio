package com.enjoy.jack.aop.advisor;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.stereotype.Component;

/**
 * @Classname StudentServiceAdvice
 * @Description TODO
 * @Author Jack
 * Date 2021/1/19 14:59
 * Version 1.0
 */
@Component
public class StudentServiceAdvice implements MethodInterceptor {
    @Override
    public Object invoke(MethodInvocation invocation) throws Throwable {
        System.out.println("========StudentServiceAdvice.invoke========");
        return invocation.proceed();
    }
}
