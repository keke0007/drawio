package com.enjoy.jack2021.scope;

import lombok.Data;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @Classname CustomScopeBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/29 21:18
 * Version 1.0
 */
@Component
@Scope("refreshScope")
@Data
public class CustomScopeBean {
    private String username;
}
