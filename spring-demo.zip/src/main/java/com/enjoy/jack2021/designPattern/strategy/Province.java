package com.enjoy.jack2021.designPattern.strategy;

public interface Province {

    public boolean support(String flag);

    public String handler();
}
