package com.enjoy.jack2021.test;

import com.enjoy.jack2021.bean.*;
import com.enjoy.jack2021.bean.circular.CircularRefConA2;
import com.enjoy.jack2021.bean.circular.CircularRefConB2;
import com.enjoy.jack2021.bean.circular.CircularRefPrototypeA;
import com.enjoy.jack2021.bean.circular.CircularRefPrototypeB;
import com.enjoy.jack2021.bean.factoryBean.FactoryBeanDemo;
import com.enjoy.jack2021.bean.propertiesbean.PropertiesBean;
import com.enjoy.jack2021.beanDefinitionPostProcessor.PlaceHolderBean1;
import com.enjoy.jack2021.event.EnjoyApplicationListener;
import com.enjoy.jack2021.event.EnjoyEvent;
import com.enjoy.jack2021.customBean.James13;
import com.enjoy.jack2021.designPattern.strategy.CQ;
import com.enjoy.jack2021.scope.CustomScopeBean;
import org.junit.Test;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.env.Environment;

public class MyTest {


    @Test
    public void test1() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day1-test1.xml");
        applicationContext.refresh();
        Student bean = applicationContext.getBean(Student.class);
        System.out.println(bean.getUsername());
//        applicationContext.getBeanFactory().getSingletonCount();
//        applicationContext.getBeanFactory().getSingletonNames();
    }

    @Test
    public void test2() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day2-test1.xml");
        ShowSixClass bean = (ShowSixClass) applicationContext.getBean("people");
        bean.showsix();
    }

    @Test
    public void test3() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day2-test1.xml");
        OriginClass bean = (OriginClass) applicationContext.getBean("originClass");
        bean.method("Jack");
    }

    @Test
    public void test4() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day2-test1.xml");
        Jack bean = applicationContext.getBean(Jack.class);
        System.out.println(bean);
    }

    @Test
    public void test5() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day3-test1.xml");
        CQ bean = applicationContext.getBean(CQ.class);
        System.out.println(bean);
    }

    @Test
    public void test6() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day3-test1.xml");
        BeanDefinitionBean bean = applicationContext.getBean(BeanDefinitionBean.class);
        System.out.println(bean.getName());
    }

    @Test
    public void test7() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day3-test1.xml");
        James13 bean = applicationContext.getBean(James13.class);
        System.out.println(bean);
    }

    @Test
    public void test8() {
        /**
         * 事件管理者通知所有的观察者
         */
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day3-test1.xml");
//        applicationContext.publishEvent(new EnjoyEvent("Jack","enjoyEvent"));
        //为什么要add？因为启动后把事件监听加入
        applicationContext.addApplicationListener(new EnjoyApplicationListener());
//        applicationContext.addApplicationListener(new EnjoyApplicationListener2());

        //发布事件
        applicationContext.publishEvent(new EnjoyEvent("Jack", "enjoyEvent"));

        applicationContext.start();
        applicationContext.stop();

//        SimpleApplicationEventMulticaster bean = applicationContext.getBean(SimpleApplicationEventMulticaster.class);
//        bean.setTaskExecutor(null);
    }

    @Test
    public void test9() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day5-test1.xml");
        //手动创建了对象，并且交给spring管理了
        applicationContext.getBeanFactory().registerSingleton("jack", new com.enjoy.jack.bean.Jack());

        ((DefaultListableBeanFactory) applicationContext.getBeanFactory()).destroySingleton("jack");
        com.enjoy.jack2021.bean.Jack bean = applicationContext.getBean(com.enjoy.jack2021.bean.Jack.class);
        System.out.println(bean.getName());
    }

    @Test
    public void test10() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day5-test1.xml");
        com.enjoy.jack2021.bean.Jack bean = applicationContext.getBean(com.enjoy.jack2021.bean.Jack.class);
        System.out.println(bean.getName());
    }

    @Test
    public void test11() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day6-test1.xml");
        com.enjoy.jack2021.bean.Jack bean = applicationContext.getBean(com.enjoy.jack2021.bean.Jack.class);
        System.out.println(bean.getCq());
    }


    @Test
    public void test12() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day6-test1.xml");
        applicationContext.getBeanFactory().destroyBean("jack");

        applicationContext.getBeanFactory().destroySingletons();
    }

    @Test
    public void test13() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day6-test1.xml");
        applicationContext.getBean(CircularRefConA2.class);
        applicationContext.getBean(CircularRefConB2.class);
    }

    @Test
    public void test14() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day6-test1.xml");
        applicationContext.getBean(CircularRefPrototypeA.class);
        applicationContext.getBean(CircularRefPrototypeB.class);
    }

//    @Test
//    public void test15() {
//        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext("com.enjoy");
//        CircularRefConA bean = applicationContext.getBean(CircularRefConA.class);
//        bean.getCircularRefConB().getB();
//    }

    @Test
    public void test16() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day7-test1.xml");
        System.out.println(applicationContext.getBean(PlaceHolderBean1.class));
    }

    @Test
    public void test17() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext("com.enjoy.jack2021");
//        ValueBean bean = applicationContext.getBean(ValueBean.class);
        ValueBean1 bean = applicationContext.getBean(ValueBean1.class);
        System.out.println("test17--" + bean.getName());
    }

    @Test
    public void test18() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day7-test1.xml");
        PropertiesBean bean = applicationContext.getBean(PropertiesBean.class);
        System.out.println(bean.getName() + "--" + bean.getPassword());
    }

    @Test
    public void test19() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day7-test1.xml");
        Environment bean = applicationContext.getBean(Environment.class);
        System.out.println(bean);
    }

    @Test
    public void test20() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day8-test1.xml");
        com.enjoy.jack2021.bean.Student student = (com.enjoy.jack2021.bean.Student)applicationContext.getBean("factoryBeanDemo");
        System.out.println(student);

        FactoryBeanDemo factoryBeanDemo = (FactoryBeanDemo)applicationContext.getBean("&factoryBeanDemo");
        System.out.println(factoryBeanDemo);
    }

    @Test
    public void test21() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day8-test1.xml");
        com.enjoy.jack2021.bean.Student bean = applicationContext.getBean(com.enjoy.jack2021.bean.Student.class);
    }

    @Test
    public void test22() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("wt-spring-day8-test1.xml");
        CustomScopeBean bean = applicationContext.getBean(CustomScopeBean.class);
        System.out.println(bean);
    }
}
