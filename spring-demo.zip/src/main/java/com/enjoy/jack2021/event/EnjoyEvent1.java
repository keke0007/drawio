package com.enjoy.jack2021.event;

import lombok.Data;
import org.springframework.context.ApplicationEvent;

/**
 * @Classname EnjoyEvent
 * @Description TODO
 * @Author Jack
 * Date 2020/12/17 14:00
 * Version 1.0
 */
@Data
public class EnjoyEvent1 extends ApplicationEvent {

    private String name;

    public EnjoyEvent1(Object source, String name) {
        super(source);
        this.name = name;
    }
}
