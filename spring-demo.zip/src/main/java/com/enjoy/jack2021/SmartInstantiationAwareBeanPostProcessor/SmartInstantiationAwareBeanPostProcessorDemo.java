package com.enjoy.jack2021.SmartInstantiationAwareBeanPostProcessor;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.SmartInstantiationAwareBeanPostProcessor;

/**
 * @Classname SmartInstantiationAwareBeanPostProcessorDemo
 * @Description TODO
 * @Author Jack
 * Date 2020/12/24 21:00
 * Version 1.0
 */
//@Component
public class SmartInstantiationAwareBeanPostProcessorDemo implements SmartInstantiationAwareBeanPostProcessor {
    @Override
    public Object getEarlyBeanReference(Object bean, String beanName) throws BeansException {
        /**
         * 可以修改bean的属性等一些信息
         */
        return bean;
    }
}
