package com.enjoy.jack2021.beanDefinitionPostProcessor;

import com.enjoy.jack2021.annotation.MyService;
import com.enjoy.jack2021.bean.BeanDefinitionBean;
import org.springframework.beans.BeansException;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
import org.springframework.core.Ordered;
import org.springframework.core.PriorityOrdered;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.springframework.stereotype.Component;

/**
 * @Classname BeanPro
 * @Description TODO
 * @Author Jack
 * Date 2020/12/8 21:17
 * Version 1.0
 */
//@Import(ImportAwareClass.class)
//扫描哪些注解
@Component
//@Service
//@Controller
//@Repository
//@Configuration
public class BeanPro implements BeanDefinitionRegistryPostProcessor, PriorityOrdered, Ordered {

    /**
     * BeanDefinition相关的一系列操作
     * @param registry
     * @throws BeansException
     */
    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
        //查询BeanDefinition
//        final String[] beanDefinitionNames = registry.getBeanDefinitionNames();
//        for (String beanDefinitionName : beanDefinitionNames) {
//            BeanDefinition beanDefinition = registry.getBeanDefinition(beanDefinitionName);
//            System.out.println(beanDefinition);
//        }

        //新增BeanDefinition
        GenericBeanDefinition genericBeanDefinition = new GenericBeanDefinition();
        genericBeanDefinition.setBeanClass(BeanDefinitionBean.class);
        //设置属性
        MutablePropertyValues propertyValues = genericBeanDefinition.getPropertyValues();
        //里面new PropertyValue
        propertyValues.add("name", "Jack");
        registry.registerBeanDefinition("beanDefinitionBean", genericBeanDefinition);


        ClassPathBeanDefinitionScanner scanner = new ClassPathBeanDefinitionScanner(registry);
        //需要过滤的注解
        scanner.addIncludeFilter(new AnnotationTypeFilter(MyService.class));
        scanner.scan("com.enjoy.jack2021.customBean");
    }

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
//        BeanDefinitionRegistry registry = (BeanDefinitionRegistry) beanFactory;
//        String[] beanDefinitionNames = registry.getBeanDefinitionNames();

        //对BeanFactory参数修改
        DefaultListableBeanFactory beanFactory1 = (DefaultListableBeanFactory) beanFactory;
        //BeanDefinition重复
        beanFactory1.setAllowBeanDefinitionOverriding(true);
        //允许循环依赖
        beanFactory1.setAllowCircularReferences(true);

        beanFactory1.setAllowRawInjectionDespiteWrapping(true);
    }

    @Override
    public int getOrder() {
        return 0;
    }
}
