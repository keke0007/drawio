package com.enjoy.jack2021.beanDefinitionPostProcessor;

/**
 * @Classname PlaceHolderBean1
 * @Description TODO
 * @Author Jack
 * Date 2020/12/25 22:12
 * Version 1.0
 */
public class PlaceHolderBean1 {
}
