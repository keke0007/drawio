package com.enjoy.jack2021.bean.circular;

import lombok.Data;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Data
//@Component
public class CircularRefConB1 {

    @Lazy
    //会触发入参对象的getBean
    public CircularRefConB1(CircularRefConA1 circularRefConA1) {
        System.out.println("============CircularRefConB1()===========");
    }
}
