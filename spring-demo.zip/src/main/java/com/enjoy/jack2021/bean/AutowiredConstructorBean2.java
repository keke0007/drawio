package com.enjoy.jack2021.bean;

import com.enjoy.jack2021.designPattern.strategy.CQ;
import com.enjoy.jack2021.designPattern.strategy.SC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Classname AutowiredConstructorBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/20 14:35
 * Version 1.0
 */
//@Component
public class AutowiredConstructorBean2 {


//    @Autowired
//    public AutowiredConstructorBean2(SC sc, CQ cq) {
//        System.out.println(sc);
//        System.out.println(cq);
//    }
//
//    @Autowired
//    public AutowiredConstructorBean2(SC sc) {
//        System.out.println(sc);
//    }

    /**
     * n个排序 找最长
     * @param sc
     * @param cq
     */
    @Autowired(required = false)
    public AutowiredConstructorBean2(SC sc, CQ cq) {
        System.out.println(sc);
        System.out.println(cq);
    }

    @Autowired(required = false)
    public AutowiredConstructorBean2(SC sc) {
        System.out.println(sc);
    }
}
