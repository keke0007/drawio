package com.enjoy.jack2021.bean;

public interface People {

    public void showsix();
}
