package com.enjoy.jack2021.bean;

import com.enjoy.jack.bean.SubClass;
import lombok.Data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Classname Student
 * @Description TODO
 * @Author Jack
 * Date 2020/12/7 15:41
 * Version 1.0
 */
@Data
public class Student {
    private String username = "jack";

//    private Map<String, SubClass> map;
//
//    private List<Map<String,SubClass>> list;
//
//    private Map<String,Long> getMap(List<String> list) {
//        return new HashMap<>();
//    }
}
