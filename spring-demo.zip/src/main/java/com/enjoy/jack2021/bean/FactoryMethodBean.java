package com.enjoy.jack2021.bean;

import com.enjoy.jack2021.bean.Jack;

/**
 * @Classname FactoryMethodBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/20 13:55
 * Version 1.0
 */
public class FactoryMethodBean {

    public Object factoryMethod() {
        return new Jack();
    }

    public Object factoryMethod(String param) {
        return new Jack();
    }
}
