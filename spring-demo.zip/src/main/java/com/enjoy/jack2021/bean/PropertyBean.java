package com.enjoy.jack2021.bean;

import lombok.Data;

@Data
public class PropertyBean {

    private String username;

    private String password;
}
