package com.enjoy.jack2021.bean.circular;

import lombok.Data;
import org.springframework.stereotype.Component;

@Data
//@Component
public class CircularRefConB {

    //会触发入参对象的getBean
    public CircularRefConB(CircularRefConA circularRefConA) {
        System.out.println("============CircularRefConB()===========");
    }
}
