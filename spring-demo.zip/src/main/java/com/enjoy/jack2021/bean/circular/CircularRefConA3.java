package com.enjoy.jack2021.bean.circular;

import lombok.Data;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Data
@Component
//@Lazy
public class CircularRefConA3 {

    private CircularRefConB3 circularRefConB3;
    @Lazy
    //会触发入参对象的getBean
    public CircularRefConA3(CircularRefConB3 circularRefConB3) {
//        circularRefConB3.getA(); 报错
        this.circularRefConB3 = circularRefConB3;
        System.out.println("============CircularRefConA3()===========");
    }

    public void getA(){

    }
}
