package com.enjoy.jack2021.bean;

import lombok.Data;

/**
 * @Classname BeanDefinitionBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/13 21:40
 * Version 1.0
 */
@Data
public class BeanDefinitionBean {
    private String name = "test";
}
