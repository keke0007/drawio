package com.enjoy.jack2021.bean;

import com.enjoy.jack2021.designPattern.strategy.CQ;
import com.enjoy.jack2021.designPattern.strategy.SC;
import org.springframework.stereotype.Component;

/**
 * @Classname AutowiredConstructorBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/20 14:35
 * Version 1.0
 */

/**
 * 走无参 报错
 * 加无参不报错
 */
//@Component
public class AutowiredConstructorBean4 {

    public AutowiredConstructorBean4() {
    }

    public AutowiredConstructorBean4(SC sc, CQ cq) {
        System.out.println(sc);
        System.out.println(cq);
    }

    public AutowiredConstructorBean4(SC sc) {
        System.out.println(sc);
    }

}
