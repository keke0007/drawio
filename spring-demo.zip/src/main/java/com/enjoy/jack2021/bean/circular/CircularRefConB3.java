package com.enjoy.jack2021.bean.circular;

import lombok.Data;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Data
@Component
public class CircularRefConB3 {

    private CircularRefConA3 circularRefConA3;

    @Lazy
    //会触发入参对象的getBean
    public CircularRefConB3(CircularRefConA3 circularRefConA3) {
        //        circularRefConA3.getB(); 报错
        this.circularRefConA3 = circularRefConA3;
        System.out.println("============CircularRefConB3()===========");
    }

    public void getB(){

    }
}
