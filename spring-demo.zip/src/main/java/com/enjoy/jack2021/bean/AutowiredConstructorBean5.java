package com.enjoy.jack2021.bean;

import com.enjoy.jack2021.designPattern.strategy.CQ;
import com.enjoy.jack2021.designPattern.strategy.SC;

/**
 * @Classname AutowiredConstructorBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/20 14:35
 * Version 1.0
 */

/**
 * 走无参 报错
 * 加无参不报错
 */
//@Component
public class AutowiredConstructorBean5 {



    public AutowiredConstructorBean5(SC sc, CQ cq) {
        System.out.println(sc);
        System.out.println(cq);
    }


}
