package com.enjoy.jack2021.bean.circular;

import lombok.Data;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Data
//@Component
//@Lazy
public class CircularRefConA2 {

    //会触发入参对象的getBean
    public CircularRefConA2(CircularRefConB2 circularRefConB2) {
        System.out.println("============CircularRefConA2()===========");
    }
}
