package com.enjoy.jack2021.bean.circular;

import lombok.Data;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Data
//@Component
//@Lazy
public class CircularRefConB2 {


    //会触发入参对象的getBean
    public CircularRefConB2(CircularRefConA2 circularRefConA2) {
        System.out.println("============CircularRefConB2()===========");
    }
}
