package com.enjoy.jack2021.customBean;

import com.enjoy.jack2021.annotation.MyService;

/**
 * @Classname James13
 * @Description TODO
 * @Author Jack
 * Date 2020/12/13 21:50
 * Version 1.0
 */
@MyService
public class James13 {
}
