package com.enjoy.jack2021.service;

import java.util.List;

public interface StudentService {
    void eat(String a);

    String sleep(List b);
}
