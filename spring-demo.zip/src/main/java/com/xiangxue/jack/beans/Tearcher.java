package com.xiangxue.jack.beans;

/**
 * @Classname Tearcher
 * @Description TODO
 * @Author Jack
 * Date 2021/1/10 20:28
 * Version 1.0
 */
public class Tearcher {
}
