<html>
<head><title>Freemarker</title>
    <meta charset="utf-8"></meta>
</head>
<body>
<table border="1" align="center" width="50%">
    <tr>
        <th>username</th>
        <th>useraccount</th>
        <th>userage</th>
    </tr>
    <#list list as user >
        <tr border="1" align="center" width="50%">
            <td>${user.id}</td>
            <td>${user.username}</td>
            <td>${user.age}</td>
        </tr>
    </#list>
</table>

</body>
</html>