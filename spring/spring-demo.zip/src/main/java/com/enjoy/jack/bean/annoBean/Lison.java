package com.enjoy.jack.bean.annoBean;

/**
 * @Classname Lison
 * @Description TODO
 * @Author Jack
 * Date 2020/12/31 15:03
 * Version 1.0
 */
public class Lison {
}
