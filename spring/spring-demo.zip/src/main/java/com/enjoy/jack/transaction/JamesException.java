package com.enjoy.jack.transaction;

import java.io.IOException;

/**
 * @Classname JamesException
 * @Description TODO
 * @Author Jack
 * Date 2021/1/26 14:26
 * Version 1.0
 */
public class JamesException extends IOException {
}
