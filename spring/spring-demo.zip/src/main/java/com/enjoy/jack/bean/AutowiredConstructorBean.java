package com.enjoy.jack.bean;

import com.enjoy.jack.designPattern.strategy.CQ;
import com.enjoy.jack.designPattern.strategy.SC;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;

/**
 * @Classname AutowiredConstructorBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/20 14:35
 * Version 1.0
 */
//@Component
//@Import(AwareBean.class)
public class AutowiredConstructorBean {

    @Autowired
    private SC sc;

    @Resource
    private CQ cq;

/*    @Autowired(required = false)
    public AutowiredConstructorBean(SC sc,CQ cq) {
        System.out.println(sc);
        System.out.println(cq);
    }

    @Autowired(required = false)
    public AutowiredConstructorBean(SC sc) {
        System.out.println(sc);
    }*/
/*
    @Autowired(required = false)
    public AutowiredConstructorBean(SC sc,CQ cq) {
        System.out.println(sc);
        System.out.println(cq);
    }
    @Autowired(required = false)
    public AutowiredConstructorBean(SC sc,CQ cq) {
        System.out.println(sc);
        System.out.println(cq);
    }
    @Autowired(required = false)
    public AutowiredConstructorBean(SC sc,CQ cq) {
        System.out.println(sc);
        System.out.println(cq);
    }
    @Autowired(required = false)
    public AutowiredConstructorBean(SC sc,CQ cq) {
        System.out.println(sc);
        System.out.println(cq);
    }
    @Autowired(required = false)
    public AutowiredConstructorBean(SC sc,CQ cq) {
        System.out.println(sc);
        System.out.println(cq);
    }*/

    @Autowired
    public void methodxx(SC sc) {

    }

    public void methodxx1(CQ sc) {

    }

/*    public AutowiredConstructorBean(SC sc,CQ cq) {
        System.out.println(sc);
        System.out.println(cq);
    }*/
}
