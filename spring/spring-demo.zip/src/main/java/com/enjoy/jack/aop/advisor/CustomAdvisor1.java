package com.enjoy.jack.aop.advisor;

import org.aopalliance.aop.Advice;
import org.springframework.aop.Pointcut;
import org.springframework.aop.PointcutAdvisor;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * @Classname CustomAdvisor1
 * @Description TODO
 * @Author Jack
 * Date 2021/1/13 15:07
 * Version 1.0
 */
@Component
@Order(1)
public class CustomAdvisor1 implements PointcutAdvisor {
    @Override
    public Pointcut getPointcut() {
        return Pointcut.TRUE;
    }

    @Override
    public Advice getAdvice() {
        return new CustomAdvice();
    }

    @Override
    public boolean isPerInstance() {
        return false;
    }
}
