package com.enjoy.jack.test;

import com.enjoy.jack.bean.*;
import com.enjoy.jack.bean.circular.CircularRefConA;
import com.enjoy.jack.bean.circular.CircularRefConB;
import com.enjoy.jack.bean.circular.CircularRefPrototypeA;
import com.enjoy.jack.bean.circular.CircularRefPrototypeB;
import com.enjoy.jack.bean.factoryBean.FactoryBeanDemo;
import com.enjoy.jack.bean.propertiesbean.PropertiesBean;
import com.enjoy.jack.beanDefinitionPostProcessor.PlaceHolderBean1;
import com.enjoy.jack.customBean.James13;
import com.enjoy.jack.designPattern.strategy.CQ;
import com.enjoy.jack.event.EnjoyApplicationListener;
import com.enjoy.jack.event.EnjoyApplicationListener2;
import com.enjoy.jack.event.EnjoyEvent;
import com.enjoy.jack.scope.CustomScopeBean;
import org.junit.Test;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.event.SimpleApplicationEventMulticaster;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.env.Environment;

/**
 * @Classname MyTest
 * @Description TODO
 * @Author Jack
 * Date 2020/12/7 15:42
 * Version 1.0
 */
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = {"classpath:spring.xml"})
public class MyTest {

//    @Autowired
//    private Student student;

    @Test
    public void test1() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        applicationContext.refresh();
        Student bean = applicationContext.getBean(Student.class);
//        System.out.println(bean.getUsername());
//        applicationContext.getBeanFactory().getSingletonCount();
//        applicationContext.getBeanFactory().getSingletonNames();
    }

    @Test
    public void test2() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        ShowSixClass bean = (ShowSixClass) applicationContext.getBean("people");
        bean.showsix();
    }

    @Test
    public void test3() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        OriginClass bean = (OriginClass) applicationContext.getBean("originClass");
        bean.method("Jack");
    }

    @Test
    public void test4() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        Jack bean = applicationContext.getBean(Jack.class);
        System.out.println(bean);
    }

    @Test
    public void test5() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        CQ bean = applicationContext.getBean(CQ.class);
        System.out.println(bean);
    }

    @Test
    public void test6() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        BeanDefinitionBean bean = applicationContext.getBean(BeanDefinitionBean.class);
        System.out.println(bean.getName());
    }

    @Test
    public void test7() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        James13 bean = applicationContext.getBean(James13.class);
        System.out.println(bean);
    }

    @Test
    public void test8() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
//        applicationContext.publishEvent(new EnjoyEvent("Jack","enjoyEvent"));
        applicationContext.addApplicationListener(new EnjoyApplicationListener());
        applicationContext.addApplicationListener(new EnjoyApplicationListener2());
        applicationContext.publishEvent(new EnjoyEvent("Jack", "enjoyEvent"));

        applicationContext.start();
        applicationContext.stop();

        SimpleApplicationEventMulticaster bean = applicationContext.getBean(SimpleApplicationEventMulticaster.class);
        bean.setTaskExecutor(null);
    }

    @Test
    public void test9() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        //手动创建了对象，并且交给spring管理了
        applicationContext.getBeanFactory().registerSingleton("jack", new Jack());

        ((DefaultListableBeanFactory) applicationContext.getBeanFactory()).destroySingleton("jack");
        Jack bean = applicationContext.getBean(Jack.class);
        System.out.println(bean.getName());
    }

    @Test
    public void test10() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        Jack bean = applicationContext.getBean(Jack.class);
        System.out.println(bean.getName());
    }

    @Test
    public void test11() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        Jack bean = applicationContext.getBean(Jack.class);
        System.out.println(bean.getCq());
    }

    @Test
    public void test12() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        applicationContext.getBeanFactory().destroyBean("jack");

        applicationContext.getBeanFactory().destroySingletons();
    }

    @Test
    public void test13() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        applicationContext.getBean(CircularRefConA.class);
        applicationContext.getBean(CircularRefConB.class);
    }

    @Test
    public void test14() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        applicationContext.getBean(CircularRefPrototypeA.class);
        applicationContext.getBean(CircularRefPrototypeB.class);
    }

    @Test
    public void test15() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext("com.enjoy");
        CircularRefConA bean = applicationContext.getBean(CircularRefConA.class);
        bean.getCircularRefConB().getB();
    }

    @Test
    public void test16() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        System.out.println(applicationContext.getBean(PlaceHolderBean1.class));
    }

    @Test
    public void test17() {
        AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext("com.enjoy");
        ValueBean bean = applicationContext.getBean(ValueBean.class);
        System.out.println("test17--" + bean.getName());
    }

    @Test
    public void test18() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        PropertiesBean bean = applicationContext.getBean(PropertiesBean.class);
        System.out.println(bean.getName() + "--" + bean.getPassword());
    }

    @Test
    public void test19() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        Environment bean = applicationContext.getBean(Environment.class);
        System.out.println(bean);
    }

    @Test
    public void test20() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        Student student = (Student)applicationContext.getBean("factoryBeanDemo");
        System.out.println(student);

        FactoryBeanDemo factoryBeanDemo = (FactoryBeanDemo)applicationContext.getBean("&factoryBeanDemo");
        System.out.println(factoryBeanDemo);
    }

    @Test
    public void test21() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        Student bean = applicationContext.getBean(Student.class);
    }

    @Test
    public void test22() {
        ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        CustomScopeBean bean = applicationContext.getBean(CustomScopeBean.class);
        System.out.println(bean);
    }
}
