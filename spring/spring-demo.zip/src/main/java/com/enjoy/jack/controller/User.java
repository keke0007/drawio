package com.enjoy.jack.controller;

/**
 * @Classname User
 * @Description TODO
 * @Author Jack
 * Date 2021/2/22 15:19
 * Version 1.0
 */
public class User {
    private int id;
    private String username;
    private int age;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public User(int id, String username, int age) {
        this.id = id;
        this.username = username;
        this.age = age;
    }
}
