package com.enjoy.jack.service;

import cn.enjoy.annotation.DI;
import com.enjoy.jack.dao.CommonMapper;
import com.enjoy.jack.pojo.ConsultConfigArea;
import com.enjoy.jack.service.goods.GoodsService;
import com.enjoy.jack.transaction.DoOnAfterCommit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
public class AreaServiceImpl implements AreaService {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @DI(value = "Jack", serviceIds = {"accountServiceImpl1"})
    private AccountService accountService;

    @Autowired
    private CommonMapper commonMapper;

    @Autowired
    private GoodsService goodsService;

    @Autowired
    AreaService areaService;

    @Autowired
    private DataSource dataSource;

    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, readOnly = true, rollbackFor = RuntimeException.class)
    @Override
    public List<ConsultConfigArea> queryAreaFromDB(Map param) {
        TransactionSynchronizationManager.registerSynchronization(new DoOnAfterCommit());
        logger.info("================从mysql里面查询数据 事务1========================");
        List<ConsultConfigArea> areas = commonMapper.queryAreaByAreaCode(param);
        return areas;
    }

    @Transactional
    @Override
    public String queryAreaFromRedisOne(Map param) {
        try {
            TimeUnit.SECONDS.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        logger.info("================从mysql里面查询数据 事务2========================");
        return "OK";
    }

    @Transactional
    @Override
    public String queryAreaFromRedisTow(Map param) {
        return "OK";
    }


    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @Override
    public int addArea(ConsultConfigArea area) {

        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = servletRequestAttributes.getRequest();
        area.setAreaCode(area.getAreaCode() + 1);
        int i = commonMapper.addArea(area);
        return i;
    }
}
