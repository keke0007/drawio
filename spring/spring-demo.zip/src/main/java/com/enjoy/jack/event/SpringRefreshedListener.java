package com.enjoy.jack.event;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

/**
 * @Classname SpringRefreshedListener
 * @Description TODO
 * @Author Jack
 * Date 2020/12/17 21:18
 * Version 1.0
 */
@Component
public class SpringRefreshedListener implements ApplicationListener<ContextRefreshedEvent> {
    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        System.out.println("========容器加载完成了=========");
    }
}
