package com.enjoy.jack2021.bean.circular;

import lombok.Data;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Data
//@Component
public class CircularRefConA1 {

    @Lazy
    //会触发入参对象的getBean
    public CircularRefConA1(CircularRefConB1 circularRefConB1) {
        System.out.println("============CircularRefConA1()===========");
    }
}
