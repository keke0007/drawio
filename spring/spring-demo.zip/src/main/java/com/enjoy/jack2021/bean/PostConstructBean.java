package com.enjoy.jack2021.bean;

import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * @Classname PostConstructBean
 * @Description TODO
 * @Author Jack
 * Date 2020/12/22 20:18
 * Version 1.0
 */
@Component
public class PostConstructBean {

    @PostConstruct
    public void init() {
        System.out.println("----init");
    }

    @PreDestroy
    public void desy() {
        System.out.println("----desy");
    }
}
