package com.enjoy.jack2021.bean.factoryBean;

import com.enjoy.jack2021.bean.Student;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.stereotype.Component;

/**
 * @Classname FactoryBeanDemo
 * @Description TODO
 * @Author Jack
 * Date 2020/12/29 16:12
 * Version 1.0
 *
 * 灵活定义需要我们自己创建的实例的时候，我们可以实现factoryBean接口
 * 在getObject方法里面定义实例化过程
 *
 */
@Component
public class FactoryBeanDemo implements FactoryBean {

    /**
     * 只有要用才会调用到
     */
    @Override
    public Object getObject() throws Exception {
        return new Student();
    }

    @Override
    public Class<?> getObjectType() {
        return Student.class;
    }
}
