package com.enjoy.jack2021.bean;

import com.enjoy.jack2021.designPattern.strategy.CQ;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @Classname Jack
 * @Description TODO
 * @Author Jack
 * Date 2020/12/11 21:16
 * Version 1.0
 */
@Data
public class Jack {

    @Autowired
    private CQ cq;

    public String name = "jack";

    public static Jack factoryMethod() {
        return new Jack();
    }

    public static Jack factoryMethod(String param) {
        return new Jack();
    }
}
