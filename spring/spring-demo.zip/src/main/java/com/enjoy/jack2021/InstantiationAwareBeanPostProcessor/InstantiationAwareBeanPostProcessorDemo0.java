package com.enjoy.jack2021.InstantiationAwareBeanPostProcessor;

import com.enjoy.jack.bean.Jack;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * @Classname InstantiationAwareBeanPostProcessorDemo
 * @Description TODO
 * @Author Jack
 * Date 2020/12/22 20:27
 * Version 1.0
 */
//@Component
public class InstantiationAwareBeanPostProcessorDemo0 implements InstantiationAwareBeanPostProcessor {

    @Override
    public boolean postProcessAfterInstantiation(Object bean, String beanName) throws BeansException {
        return false;
    }
}
