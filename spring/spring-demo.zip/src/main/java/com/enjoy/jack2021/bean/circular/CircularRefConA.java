package com.enjoy.jack2021.bean.circular;

import lombok.Data;
import org.springframework.stereotype.Component;

@Data
//@Component
public class CircularRefConA {

    //会触发入参对象的getBean
    public CircularRefConA(CircularRefConB circularRefConB) {
        System.out.println("============CircularRefConA()===========");
    }
}
