package com.enjoy.jack2021.bean;


public abstract class ShowSixClass<T> {

    public void showsix() {
        getPeople().showsix();
    }

    public T getT() {
        return null;
    }

    //不一定是抽象的
    public abstract People getPeople();
}
