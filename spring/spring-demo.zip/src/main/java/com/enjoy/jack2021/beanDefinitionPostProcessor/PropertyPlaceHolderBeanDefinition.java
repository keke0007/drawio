package com.enjoy.jack2021.beanDefinitionPostProcessor;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.ClassUtils;

import java.io.IOException;
import java.util.Properties;
import java.util.UUID;

/**
 * @Classname PropertyPlaceHolderBeanDefinition
 * @Description TODO
 * @Author Jack
 * Date 2020/12/25 22:11
 * Version 1.0
 */
//@Component
public class PropertyPlaceHolderBeanDefinition implements BeanDefinitionRegistryPostProcessor {
    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
        try {
            Properties properties = PropertiesLoaderUtils.loadAllProperties("application-1.properties", ClassUtils.getDefaultClassLoader());
            String property = properties.getProperty("enjoy.beanClass");
            String[] beanClasss = property.split(",");
            for (String classs : beanClasss) {
                BeanDefinition beanDefinition = new GenericBeanDefinition();
                beanDefinition.setBeanClassName(classs);
//                String beanName = BeanDefinitionReaderUtils.generateBeanName(beanDefinition,registry);
                registry.registerBeanDefinition(UUID.randomUUID().toString(),beanDefinition);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {

    }
}
