package com.baizhiedu;

public class User /*implements BeanNameAware, BeanFactoryAware , InitializingBean, DisposableBean*/ {
    private Address address;

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    /*private Integer id;
    private String name;
    private String password;*/
/*    private String userFactoryName;
    private BeanFactory myBeanFactory;*/

    //销毁方法
    //释放资源的工作
    //io.close()
    //Object = null;
   /* public void myDestory() {
        System.out.println("User.myDestory");
    }

    @Override
    public void destroy() throws Exception {
        System.out.println("User.destroy");
    }*/

    //初始化方法
    //初始化方法 ---> Spring容器（工厂）
    /*public void myInit() {
        // InputStream --
        System.out.println("User.myInit");
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        System.out.println("User.afterPropertiesSet");
    }

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        System.out.println("User.setBeanFactory");
        this.myBeanFactory = beanFactory;
    }

    @Override
    public void setBeanName(String name) {
        System.out.println("User.setBeanName");
        this.userFactoryName = name;
    }*/

    /*public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        System.out.println("User.setId");
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        System.out.println("User.setName");
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        System.out.println("User.setPassword");
        this.password = password;
    }

    public void showBeanName() {
        System.out.println("bean id is "+this.userFactoryName);
    }

    public void userBeanFactory() {
        //使用当前的BeanFactory 怎么办？
        // 不可以 BeanFactory beanFactory = new XmlBeanFactory(new ClassPathResource("applicationContext_tx.xml"));
        System.out.println(this.myBeanFactory);
    }*/
}
