package com.baizhiedu;

public interface UserService {
    public void register();
}
