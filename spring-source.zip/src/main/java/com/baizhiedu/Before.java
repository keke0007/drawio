package com.baizhiedu;

import org.springframework.aop.MethodBeforeAdvice;

import java.lang.reflect.Method;

//@Before
public class Before implements MethodBeforeAdvice {
    @Override
    public void before(Method method, Object[] args, Object target) throws Throwable {
        System.out.println("-----before log----");
    }
}
