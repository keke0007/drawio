package com.baizhiedu;

import org.springframework.beans.factory.BeanFactory;


public class UserServiceImpl implements UserService/*, BeanFactoryAware*/ {
    private BeanFactory beanFactory;

    public UserServiceImpl() {
        System.out.println("UserServiceImpl.UserServiceImpl");
    }


    /*@Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }*/
    /*private UserDAO userDAO;


    public UserDAO getUserDAO() {
        return userDAO;
    }

    public void setUserDAO(UserDAO userDAO) {
        this.userDAO = userDAO;
    }*/

    @Override
    public void register() {
      /*  UserDAO userDAO = (UserDAO) beanFactory.getBean("userDAO");
        System.out.println("userDAO = " + userDAO);
        userDAO.save();*/
        System.out.println("UserServiceImpl.register");
    }
}
