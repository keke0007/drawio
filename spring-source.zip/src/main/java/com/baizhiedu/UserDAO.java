package com.baizhiedu;

public interface UserDAO {
    public void save();
}
