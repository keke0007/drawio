package com.baizhiedu;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.xml.XmlBeanFactory;

public class Account implements BeanNameAware, BeanFactoryAware {
    private String name;
    private String password;

    private String beanName;
    private BeanFactory beanFactory;

    @Override
    public void setBeanName(String name) {
        System.out.println("Account.setBeanName");
        this.beanName = name;
    }

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        System.out.println("Account.setBeanFactory");
        this.beanFactory = beanFactory;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        System.out.println("Account.setName");
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        System.out.println("Account.setPassword");
        this.password = password;
    }

    public void showBeaName() {
        //记录日志 log4j 输出bean id
        System.out.println("log4j xxxx bean name "+beanName);
        System.out.println("beanName = " + beanName);
    }
}
