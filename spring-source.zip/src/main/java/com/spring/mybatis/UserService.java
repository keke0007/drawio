package com.spring.mybatis;

public interface UserService {
    public void register(User user);
}
