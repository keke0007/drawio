package com.spring.mybatis;

import java.io.Serializable;

public class User implements Serializable {
    private Integer id;
    private String name;
    private Integer vers;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getVers() {
        return vers;
    }

    public void setVers(Integer vers) {
        this.vers = vers;
    }
}
