package com.spring.mybatis;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestSSM {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        UserService userService = (UserService) ctx.getBean("userServiceImpl");


        User user = new User();
        user.setName("1111");
        user.setVers(1);

        userService.register(user);
    }
}
