package com.spring.dao;

import com.spring.mybatis.User;

public interface UserDAO {
    public void save(User user);
}
