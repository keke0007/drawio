package com.configuration;

import com.baizhiedu.User;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestConfiguration {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        //AppConfig appConfig = (AppConfig) ctx.getBean("appConfig");

        User user = (User) ctx.getBean("user");
        User user1 = (User) ctx.getBean("user");

        System.out.println("user = " + user);
        System.out.println("user1 = " + user1);


    }
}
