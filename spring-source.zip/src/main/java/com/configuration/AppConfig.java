package com.configuration;

import com.baizhiedu.User;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.context.annotation.*;
import org.springframework.core.type.AnnotationMetadata;

@Configuration
@Import(A.class)
public class AppConfig {//implements ImportAware , BeanFactoryAware {
    //@Override
    //public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
    //
    //}
    //
    //@Override
    //public void setImportMetadata(AnnotationMetadata importMetadata) {
    //    importMetadata.getClass();
    //}

    @Bean
    public User user() {
        return new User();
    }

}
