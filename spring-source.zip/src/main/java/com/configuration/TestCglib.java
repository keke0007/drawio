package com.configuration;

import com.bean.E;
import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.InvocationHandler;

import java.lang.reflect.Method;

public class TestCglib {
    public static void main(String[] args) {
        /*
          1 .原始对象
          2 .基于接口 还是 基于继承父类？
          3 .类加载器
          4 .额外功能
         */
        Enhancer enhancer = new Enhancer();
        A a = new A();
        enhancer.setSuperclass(A.class);
        enhancer.setClassLoader(TestCglib.class.getClassLoader());


        enhancer.setCallback(new InvocationHandler() {
            @Override
            public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
                System.out.println("增加对于@Scope注解的支持");
                return method.invoke(a, args);
            }
        });




        A aproxy = (A) enhancer.create();

        aproxy.m1();
    }
}
