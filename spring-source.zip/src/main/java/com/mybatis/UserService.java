package com.mybatis;

public interface UserService {
    public void register();
}
