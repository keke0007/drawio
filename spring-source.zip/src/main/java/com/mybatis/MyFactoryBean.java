package com.mybatis;

import org.springframework.beans.factory.FactoryBean;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;


public class MyFactoryBean implements FactoryBean<UserDAO> {
    @Override
    public UserDAO getObject() throws Exception {

        UserDAO userDAO = (UserDAO) Proxy.newProxyInstance(MyFactoryBean.class.getClassLoader(),new Class[]{UserDAO.class},(Object proxy, Method method, Object[] args)->{
            System.out.println("这是DAO接口的实现类");
            return null;
        });

        return userDAO;
    }

    @Override
    public Class<?> getObjectType() {
        return UserDAO.class;
    }
}
