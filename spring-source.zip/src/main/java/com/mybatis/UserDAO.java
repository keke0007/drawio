package com.mybatis;

public interface UserDAO {
    public void save();
}
