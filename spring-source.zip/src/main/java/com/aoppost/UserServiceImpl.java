package com.aoppost;

import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements IUserService {
    @Override
    public void showName() {
        System.out.println("UserServiceImpl.showName");
    }

    @Override
    public void showAge() {
        System.out.println("UserServiceImpl.showAge");
    }
}
