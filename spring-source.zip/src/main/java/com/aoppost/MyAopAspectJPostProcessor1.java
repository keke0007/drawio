package com.aoppost;

import org.springframework.aop.PointcutAdvisor;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.config.BeanPostProcessor;

import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;

//@Component
public class MyAopAspectJPostProcessor1 implements BeanPostProcessor, BeanFactoryAware {

  /*
    AutowiredAnnotationBeanPostProcessor
    针对于 BeanPostProcessor如果需要获取Spring创建的一个对象，不建议使用@Autowired
    @Autowired
    private MyPointCut myPointCut;

    ApplicationContextAwareProcessor
    ApplicationContextAware
  */

    private BeanFactory beanFactory;

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        //切入点+额外功能 切面 （Advisor)
        //Pointcut pointcut = beanFactory.getBean(Pointcut.class);
        //MethodBeforeAdvice before = beanFactory.getBean(MethodBeforeAdvice.class);

        //PointcutAdvisor pointcutAdvisor = beanFactory.getBean(PointcutAdvisor.class);

        if (PointcutAdvisor.class.isAssignableFrom(bean.getClass())) {
            return bean;
        }


        ListableBeanFactory listableBeanFactory = (ListableBeanFactory) beanFactory;
        String[] beanNamesForType = listableBeanFactory.getBeanNamesForType(PointcutAdvisor.class);
        List<PointcutAdvisor> pointcutAdvisors = new ArrayList<>();

        for (String beanNameItem : beanNamesForType) {
            PointcutAdvisor pointcutAdvisor = beanFactory.getBean(beanNameItem, PointcutAdvisor.class);
            pointcutAdvisors.add(pointcutAdvisor);
        }

        return Proxy.newProxyInstance(MyAopAspectJPostProcessor1.class.getClassLoader(), bean.getClass().getInterfaces(), new MyInvocationHandler(bean, pointcutAdvisors));

    }
}
