package com.aoppost;

public interface IUserService {
    public void showName();

    public void showAge();
}
