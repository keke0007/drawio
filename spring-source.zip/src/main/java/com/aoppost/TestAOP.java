package com.aoppost;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestAOP {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        IUserService userService = (IUserService) ctx.getBean("userServiceImpl");

        userService.showName();

        userService.showAge();

    /*    String[] beanNamesForType = ctx.getBeanNamesForType(Advice.class);
        for (String s : beanNamesForType) {
            Advice bean = ctx.getBean(s, Advice.class);
            System.out.println("bean = " + bean);
        }
    }*/
    }
}
