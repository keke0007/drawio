package com.aoppost;

import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.PointcutAdvisor;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.config.BeanPostProcessor;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;

//@Component
public class MyAopAspectJPostProcessor implements BeanPostProcessor, BeanFactoryAware {

  /*
    AutowiredAnnotationBeanPostProcessor
    针对于 BeanPostProcessor如果需要获取Spring创建的一个对象，不建议使用@Autowired
    @Autowired
    private MyPointCut myPointCut;

    ApplicationContextAwareProcessor
    ApplicationContextAware
  */

    private BeanFactory beanFactory;

    @Override
    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        //切入点+额外功能 切面 （Advisor)
        //Pointcut pointcut = beanFactory.getBean(Pointcut.class);
        //MethodBeforeAdvice before = beanFactory.getBean(MethodBeforeAdvice.class);

        //PointcutAdvisor pointcutAdvisor = beanFactory.getBean(PointcutAdvisor.class);

        //1. 放置Advisor 被代理
        if (PointcutAdvisor.class.isAssignableFrom(bean.getClass())) {
            return bean;
        }

        //2. 获得当前容器中 所有的Advisor对象
        ListableBeanFactory listableBeanFactory = (ListableBeanFactory) beanFactory;
        String[] beanNamesForType = listableBeanFactory.getBeanNamesForType(PointcutAdvisor.class);
        List<PointcutAdvisor> pointcutAdvisors = new ArrayList<>();

        for (String beanNameItem : beanNamesForType) {
            PointcutAdvisor pointcutAdvisor = beanFactory.getBean(beanNameItem, PointcutAdvisor.class);
            pointcutAdvisors.add(pointcutAdvisor);
        }

        return Proxy.newProxyInstance(MyAopAspectJPostProcessor.class.getClassLoader(), bean.getClass().getInterfaces(), new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

                for (PointcutAdvisor pointcutAdvisor : pointcutAdvisors) {
                    if (pointcutAdvisor.getPointcut().getClassFilter().matches(bean.getClass())) {
                        if (pointcutAdvisor.getPointcut().getMethodMatcher().matches(method, bean.getClass())) {
                            //写死代码
                            //1 位置 2 代码写死了 接口隔离原则 @Before
                            if (pointcutAdvisor.getAdvice() instanceof MethodBeforeAdvice) {
                                ((MethodBeforeAdvice) pointcutAdvisor.getAdvice()).before(method, args, bean);
                            }
                            Object ret = method.invoke(bean, args);
                            if (pointcutAdvisor.getAdvice() instanceof AfterReturningAdvice) {
                                ((AfterReturningAdvice) pointcutAdvisor.getAdvice()).afterReturning(ret, method, args, bean);
                            }
                            //return ret;
                        }
                    } else {
                        return method.invoke(bean, args);
                    }
                }

                return method.invoke(bean, args);
            }
        });

    }
}
