package com.beanfactoryprocessor;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test1 {
    public static void main(String[] args){
        //this() register()  refersh()
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        ctx.register(AppConfig.class);
        ctx.register(A.class);
        //ctx.addBeanFactoryPostProcessor(new MyBeanDefinitionRegistryPostProcessor());// ---> --class  new BeanDefinition()

        ctx.refresh();

        // A类 Scope=singleton 被Spring存储在了那里？BD
      /*  A a = (A) ctx.getBean("a");
        A a1 = (A) ctx.getBean("a");

        System.out.println(a);
        System.out.println(a1);*/
    }
}
