package com.beanfactoryprocessor;

//@Component
//@Scope()
public class A {
}
