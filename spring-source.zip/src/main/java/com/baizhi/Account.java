package com.baizhi;

import org.springframework.stereotype.Component;

@Component
//@PropertySource()
public class Account {

}
