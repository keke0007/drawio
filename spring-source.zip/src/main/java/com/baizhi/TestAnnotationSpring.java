package com.baizhi;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestAnnotationSpring {
    public static void main(String[] args) {
        ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        Product product = (Product) ctx.getBean("product");
        System.out.println("product = " + product);
        System.out.println("product.getAccount() = " + product.getAccount());
    }

    public static void showName() {
        String name = "sunshuai";
        if ("xiaohei".equals(name)) {

        } else {

        }
    }
}
