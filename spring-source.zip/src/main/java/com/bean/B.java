package com.bean;

public class B {
}
