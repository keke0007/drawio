package com.bean;

import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

@Component
@Import(MyImportSelector.class)
public class C {

}
