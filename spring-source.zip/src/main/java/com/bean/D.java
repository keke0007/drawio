package com.bean;

public class D {
}
