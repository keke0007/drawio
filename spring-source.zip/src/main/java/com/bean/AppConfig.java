package com.bean;

import org.springframework.context.annotation.*;

@Configuration
@ComponentScan("com.bean")
//@PropertySource("classpath:app.properties")
//@ImportSource
//@Import({B.class})
@ImportResource("classpath:applicationContext.xml")
@Import(MyBeanDefinitionRegistry.class)
public class AppConfig {
}


