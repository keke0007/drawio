package com.bean;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestBean {
    public static void main(String[] args){
          AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);

/*        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        ctx.register(AppConfig.class);

        ctx.addBeanFactoryPostProcessor(new MyBeanDefinitionRegistryPostProcessor());

        ctx.refresh();*/
    }

}
