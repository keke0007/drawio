package com.bean;

import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

//@Import()
//@PropertySource()
@Component
@Import(B.class)
public class A {
    //@Value("${product.id}")
    private String name;
}
