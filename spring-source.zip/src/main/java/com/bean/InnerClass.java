package com.bean;

//@Component
public class InnerClass {

    //@Component
    class InnerConfiugration {

    }

}
