package com.application;

import org.springframework.stereotype.Component;

/**
 * see @Service
 * see @Repository
 * ses @Controller
 *
 * 统一用总接口  @Component
 */
@Component
public class Test1 {
}
