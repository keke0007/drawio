package com.application;

import org.springframework.context.annotation.Import;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
//@Import(MyImportSelector.class)
@Import(MyImportBeanDefinitionRegister.class)
public @interface SpringApplication {

}
