package com.application;

import org.springframework.context.annotation.Configuration;

@Configuration
/*@ComponentScan("com.application")
//@Import(User.class)
@SpringApplication*/
public class AppConfig {
}

