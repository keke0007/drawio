package com.application;

import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
import org.springframework.beans.factory.config.ConstructorArgumentValues;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestApplication {

    public static void main(String[] args) {
        //AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext("com.application");
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
    }


    public static void test2() {
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(Test1.class);
        GenericBeanDefinition beanDefinition = (GenericBeanDefinition) builder.getBeanDefinition();

        MutablePropertyValues propertyValues = beanDefinition.getPropertyValues();
        propertyValues.add("password", "99999");

        ConstructorArgumentValues values = beanDefinition.getConstructorArgumentValues();
        values.addArgumentValues(null);

    }


    public static void test1() {
        AnnotatedGenericBeanDefinition beanDefinition = new AnnotatedGenericBeanDefinition(Test1.class);
    }


    public static void test(String[] args) {
     /*   DefaultListableBeanFactory beanFactory = new DefaultListableBeanFactory();

        XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(beanFactory);
        reader.loadBeanDefinitions(new ClassPathResource("applicationContext_tx.xml"));
        beanFactory.getBean("u");*/

        // ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext_tx.xml");

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        //获取对应的对象
        context.getBean("test1");

    }

}
