package com.proxy;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestProxy {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        A a = ctx.getBean(A.class);
        a.showB();
    }
}
