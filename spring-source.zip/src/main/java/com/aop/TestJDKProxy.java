package com.aop;

import java.lang.reflect.Proxy;

public class TestJDKProxy {
    public static void main(String[] args) {
        UserService userService = new UserService();

        //IUserService userService1 = (IUserService) Proxy.newProxyInstance(TestJDKProxy.class.getClassLoader(), new Class[]{IUserService.class}, new InvocationHandler() {
        //    @Override
        //    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        //        System.out.println("---before----");
        //        //Object ret = method.invoke(userService, args);
        //        return false;
        //    }
        //});
        IUserService userService1 = (IUserService) Proxy.newProxyInstance(TestJDKProxy.class.getClassLoader(), new Class[]{IUserService.class}, (proxy, method, arg) -> {
            System.out.println("----before---");
            Object invoke = method.invoke(userService, arg);
            return invoke;
        });

        boolean result = userService1.showName();
        System.out.println(result);
    }
}
