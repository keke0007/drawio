package com.aop;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestAOP {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        IUserService userService = (IUserService) ctx.getBean("userService");
        /*
            输出结果是什么？
            "MyAspect.myBefore"
            "UserService.showName"
            "MyAspect.myBefore"
            "UserService.showAge"

         */
        userService.showName();


        //userService.showAge();
    }
}
