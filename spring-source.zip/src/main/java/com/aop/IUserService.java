package com.aop;

public interface IUserService {
    public boolean showName();

    public void showAge();
}
