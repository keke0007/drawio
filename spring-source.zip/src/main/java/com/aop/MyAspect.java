package com.aop;

import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class MyAspect {

    @Before("execution(* com.aop.UserService.*(..))")
    @AfterReturning
    public void myBefore() {
        System.out.println("MyAspect.myBefore");
    }

    @After("execution(* com.aop.UserService.showAge(..))")
    public void myAfter() {
        System.out.println("MyAspect.myAfter");
    }
}
