package com.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

@Service
//这个ApplicationContextAware初始化话 对调的
// 1 2 3
public class UserService implements IUserService {//ApplicationContextAware {
    private ApplicationContext applicationContext;
  /*  @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
            this.applicationContext = applicationContext;
    }*/

    /*public boolean showName(){
        System.out.println("UserService.showName");

        //代理对象 调用showAge()
        //问题 如何在这里获得代理对象。
        // applicationContext.getBean("")---Proxy
        // 如何在这里类中 获得ApplicationContext?
        // new AnnotationConfigApplicationContext()?
        //this.showAge();
        IUserService userService = (IUserService) applicationContext.getBean("userService");
        userService.showAge();
        return true;
    }*/


 /*   @Override
    public boolean showName() {
        System.out.println("UserService.showName");

        //获得代理对象 调用代理对象的showAge() 可以达到我们的预期
        //TheadLocal中 获得代理对象 并进行调用
        IUserService userService = (IUserService) AopContext.currentProxy();
        userService.showAge();

        return true;
    }
*/

    @Override
    public boolean showName() {
        System.out.println("UserService.showName");
        return false;
    }

    @Override
    public void showAge() {
        System.out.println("UserService.showAge");
    }

}
