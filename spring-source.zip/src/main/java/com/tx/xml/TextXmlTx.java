package com.tx.xml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TextXmlTx {
    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext_tx.xml");
        UserService userService = (UserService) ctx.getBean("userServiceImpl");

        User user = new User();
        user.setName("xiaohei");
        user.setVers(1);

        userService.register(user);
    }
}
