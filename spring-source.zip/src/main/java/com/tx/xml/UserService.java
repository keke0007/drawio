package com.tx.xml;

public interface UserService {
    public void register(User user);
}
