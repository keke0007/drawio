package com.tx.xml;

public interface UserDAO {
    public void save(User user);
}
