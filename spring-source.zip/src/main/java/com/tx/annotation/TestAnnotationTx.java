package com.tx.annotation;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestAnnotationTx {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        UserService userService = (UserService) ctx.getBean("userServiceImpl");

        User user = new User();
        user.setName("sunshuai");
        user.setVers(1);

        userService.register(user);

        /*User user = new User();
        user.setId(1);
        user.setName("xiaojr");
        user.setVers(10);

        userService.modify(user);*/
    }
}
