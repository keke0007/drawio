package com.tx.annotation;



public interface UserService {
    public void register(User user);

    public void modify(User user);
}
