package com.tx.annotation;

import java.sql.Connection;
import java.sql.SQLException;

public class TestJDBC {
    public static void main(String[] args) throws SQLException {
        Connection conn = null;


        conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);

        //隔离属性 隔离级别
       /* conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
        conn.setReadOnly(true);
        conn.setNetworkTimeout();*/

      //public class xxService(){
        //
        //   xxxx(){
        //        System.out.println("11111");
        //        System.out.println("22222");
        //        conn.setSavepoint();
        //        System.out.println("333333");
        //        System.out.println("44444");
        //   }
        //
        // }

    }

}
