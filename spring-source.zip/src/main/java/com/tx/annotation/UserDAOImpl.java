package com.tx.annotation;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserDAOImpl implements UserDAO {

    //封装了Connection
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void save(User user) {
           //insert update delete
        jdbcTemplate.update("insert into t_user (name,vers) values (?,?)", user.getName(), user.getVers());
    }

    @Override
    public void update(User user) {
        jdbcTemplate.update("update t_user set name = ?,vers=? where id = ?", user.getName(), user.getVers(),user.getId());
    }
}
