package com.tx.annotation;


import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserServiceImpl implements UserService, ApplicationContextAware {
    @Autowired
    private UserDAO userDAO;

    private ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED,isolation = Isolation.DEFAULT  )
    public void register(User user) { // Connection
        System.out.println("----register invoke -----");
        UserService userService = (UserService) applicationContext.getBean("userServiceImpl");
        userService.modify(user); // Connection
        userDAO.save(user);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void modify(User user) {
        user.setId(1);
        user.setName("xiaohaha");
        user.setVers(10);
        userDAO.update(user);
    }
}
