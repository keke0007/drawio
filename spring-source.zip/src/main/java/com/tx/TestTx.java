package com.tx;

public class TestTx {
    public static void main(String[] args) {
     /*
        TransactionTemplate transactionTemplate = new TransactionTemplate();

        transactionTemplate.execute(new TransactionCallback<Object>() {
            @Override
            public Object doInTransaction(TransactionStatus status) {
                //service操作 操作返回值 作为doInTransaction方法的返回值
                return null;
            }
        });*/
    }
}
