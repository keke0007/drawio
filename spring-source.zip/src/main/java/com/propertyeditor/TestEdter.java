package com.propertyeditor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TestEdter {
    public static void main(String[] args) throws ParseException {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("/applicationContext1.xml");
        Customer c = (Customer) ctx.getBean("c");
        System.out.println("c = " + c);

        //stringToDate();
    }

    public static void stringToDate() throws ParseException {
        //Spring完成
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date result = simpleDateFormat.parse("2021-03-31");

        System.out.println("result = " + result);
    }
}
