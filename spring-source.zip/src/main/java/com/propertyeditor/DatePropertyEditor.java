package com.propertyeditor;

import java.beans.PropertyEditorSupport;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DatePropertyEditor extends PropertyEditorSupport {
    /**
     *
     * @param text
     * @throws IllegalArgumentException
     * 工作：Spring配置文件中的字符串（日期） 转换成 Date
     */
    @Override
    public void setAsText(String text) throws IllegalArgumentException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date d = format.parse(text);
            super.setValue(d);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
