package com.baizhiedu;

import org.junit.Test;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;


public class SpringTest {

    /**
     * 用于测试:AOP编程
     */
    @Test
    public void test6() {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        UserService userService = (UserService) context.getBean("userService");
        UserService userService1 = (UserService) context.getBean("userService");

        userService.register();
    }

    /**
     * 用于测试:
     */
    @Test
    public void test5() throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class<?> clazz = Class.forName("com.baizhiedu.User");
        Constructor<?> ctor = clazz.getDeclaredConstructor();
        User user = (User) ctor.newInstance();
        System.out.println("user = " + user);
    }


    /**
     * 用于测试:父子Bean
     */
    @Test
    public void test4() {
        DefaultListableBeanFactory child = new DefaultListableBeanFactory();
        XmlBeanDefinitionReader xmlBeanDefinitionReader1 = new XmlBeanDefinitionReader(child);
        xmlBeanDefinitionReader1.loadBeanDefinitions(new ClassPathResource("applicationContext.xml"));

        User u = (User) child.getBean("u");
        System.out.println("u = " + u);
    }

    /**
     * 用于测试:父子容器的问题
     * 实战中的父子容器 SpringMVC DispatcherServlet child
     * ContextLoaderListener root
     */
    @Test
    public void test3() {

        DefaultListableBeanFactory parent = new DefaultListableBeanFactory();
        XmlBeanDefinitionReader xmlBeanDefinitionReader = new XmlBeanDefinitionReader(parent);
        xmlBeanDefinitionReader.loadBeanDefinitions(new ClassPathResource("applicationContext-parents.xml"));

        DefaultListableBeanFactory child = new DefaultListableBeanFactory(parent);
        XmlBeanDefinitionReader xmlBeanDefinitionReader1 = new XmlBeanDefinitionReader(child);
        xmlBeanDefinitionReader1.loadBeanDefinitions(new ClassPathResource("applicationContext.xml"));

        //一旦使用父子容器 最终父子容器的配置信息 融合
        // 如果遇到同名的配置内容 使用子容器
        User u = (User) child.getBean("u");
        System.out.println("u = " + u);

        Product p = child.getBean("p", Product.class);
        System.out.println("p = " + p);

    }


    /**
     * 用于测试:BeanFactoryAware
     */
    @Test
    public void test2() {
        BeanFactory beanFactory = new XmlBeanFactory(new ClassPathResource("applicationContext.xml"));
        UserService userService = (UserService) beanFactory.getBean("userService");
        UserService userService1 = (UserService) beanFactory.getBean("userService");

        userService.register();
        userService1.register();

        /*UserDAO userDAO = (UserDAO) beanFactory.getBean("userDAO");
        UserDAO userDAO1 = (UserDAO) beanFactory.getBean("userDAO");
        System.out.println("userDAO = " + userDAO);
        System.out.println("userDAO1 = " + userDAO1);*/
    }


    /**
     * 用于测试:对象的创建
     */
    @Test
    public void test1() {
        XmlBeanFactory beanFactory = new XmlBeanFactory(new ClassPathResource("applicationContext.xml"));
        User u = (User) beanFactory.getBean("&u");

        System.out.println("u = " + u);

      /*  ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext_tx.xml");
        User u = (User) applicationContext.getBean("u");

        System.out.println("u.getId() = " + u.getId());
*/
    }


    @Test
    public void test() {
        BeanFactory beanFactory = new XmlBeanFactory(new ClassPathResource("applicationContext_tx.xml"));
        Product product = (Product) beanFactory.getBean("p");

        //DefaultlistableBeanFactory 替换 XmlBeanFactory
        //DefaultListableBeanFactory + XmlBeanDefinitionReader

  /*      DefaultListableBeanFactory beanFactory1 = new DefaultListableBeanFactory();
        Resource resource = new ClassPathResource("applicationContext_tx.xml");
        XmlBeanDefinitionReader xmlBeanDefinitionReader = new XmlBeanDefinitionReader(beanFactory1);
        xmlBeanDefinitionReader.loadBeanDefinitions(resource);

        Object product1 = beanFactory1.getBean("product"); 
        System.out.println("product1 = " + product1);*/

        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
        User user = (User) applicationContext.getBean("u");
/*
        System.out.println("user.getName() = " + user.getName());
        System.out.println("user.getPassword() = " + user.getPassword());*/
    }


}
