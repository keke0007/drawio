package grammar

import scala.collection.mutable.{ArrayBuffer, ListBuffer}

object Basic_Grammar_01   {

  def main(args: Array[String]): Unit = {

    // 变量

    val const = 1;
    //    val  不能被重新复制
    var name: String = "zhanshan"
    var age: Int = 18
    // 使用插值表达式定义变量
    var info = s"我叫${name},我今年${age}"
    // 比较两个变量的值  使用 ==  比较两个变量的地址是否相等 使用 eq()

//    println(info)

    var var11 = 1.to(10);
//    list.foreach(e => println(e));
    /*for (elem <- var11) {
      println(elem)
    }*/

    //嵌套循环的   语法 有点 骚

    // for 循环 的 守卫  语法与嵌套for循环类似

    // break   continue   与 java的不一样

    // 方法 的   返回值类型可以省略  但是递归调用的时候  不能省略   返回值 的return可以省略 最后一行就是返回值

    // 方法中可以传 变长参数   var*   在变量后面加*

    // scala 中  运算符 是 方法

    // 方法中只有一个参数 可以使用 { } 调用法  {} 中的 最后一行 表示返回值

    // 方法没有参数,可以使用无括号的  方式 调用 方法

    // scala中  函数是 对象  方法是 方法
    // 方法转换成函数  可以使用  val m1 = add_  在方法名的后面加下划线 将 方法转换为函数

    // scala中 数组 分为 定长数组   非定长数组   java中数组是固定长度的
    // scala中 通过[]定义泛型,()获取元素
    // val arr = new Array[Int](100)
    // arr(0) = 110
    // 定义不可变数组
    val arr = new Array[Int](100)
    arr(0) = 100
//    println(arr(0))

    val arr2 = Array("java","scala","python")
//    println(arr2.length)

    // 可变数组
    var arr3 = ArrayBuffer("java","scala")
    println(arr3.length)
    // 可以直接使用 += 添加元素
    arr3 += "linux"
    arr3.insert(1,"python")
//    println(arr3.length)

    /*for (elem <- arr3) {
      println(elem)
    }*/

    /*for (i <- 0 to arr3.length -1){
      println(arr3(i))
    }*/

    // to 会包含最后一个值,until 不会包含最后一个值
   /* for (i <- 0 until arr3.length){
      println(arr3(i))
    }*/


    // 数组放相同类型 的值  元组 放 不同类型的值   元组的值不能修改
    var t1=(1,"zhangshan",18,"beijing")
//    println(t1)

    val t2 = "lisi" -> 18 -> "hebei" // 这种写法变成嵌套了
//    println(t2)

    //不可变列表 定义方式1
    var list = List("java", "scala")

    for (e <- list) println(e)
    // 定义空列表2
    val nil = Nil;
//    println(nil)
    // 定义列表方式3
    val var1 = 1 :: 2 :: Nil
//    println(var1)

    // 可变列表   可以修改长度  与 值
    val buffer = ListBuffer("hadoop", "hive", "sqoop")
//    println(buffer)
    // 定义空的可变列表
    var lb: ListBuffer[String] = ListBuffer()
//    println(lb)

    // CRUD
    // +=  添加元素
    // ++= 添加列表
    // -=  删除元素
    // 可变类别转换成不可变列表  toList
    // 可变列表转换成数组  toArray


    // 不可变集   Set   不能修改  不能重复
    val ss = Set("1","2")
   ss.foreach(println(_))
    val sss = Set[String]()
//    println(sss)

    // Set 集 可以 使用 + 添加一个元素  -  删除一个元素    ++ 拼接 列表  与 另一个集
    // scala 中 的void 使用 Unit表示


    // 映射 Map  分为 不可变Mao  可变Map   不可变Map 不能修改 key 与 value
    // 定义方式1
    val map1 = Map("k1"->"v1","k2"->"v2")
//    map1.foreach(e => println(e._1))

    // 定义方式2
    val map2 = Map(("k1","v1"),("k2","v2"))
    map2.foreach(println(_))
    // 通过key 获取值
   /* println(map2("k1"))
    map2("k1") = "ssss"*/

    // 使用下划线来简化函数定义
    // 当函数参数,只在函数体中出现一次,而且函数体没有嵌套调用时,可以使用下划线来简化函数定义


    // scala中创建类和对象

    // class 是类   object是对象   object可以执行main方法
  }

}
