package grammar

object Oop_Grammar_02 {

  class Person{
    var name:String = _
    var age:Int = _
  }

  class Customer {
    var name:String = _
    var sex:String = _

    def sayHello(msg:String) = println(msg)
  }

  class Goods {
    private var name = ""

    private var price = 10

    def setName(name:String) = this.name = name

    def getName() = this.name

    def getNameAndAge() = (this.name,this,price)
  }
  def main(args: Array[String]): Unit = {

    // scala中创建对象的简写方式
    // 如果类是空的,没有任何成员,可以省略 {}
    // 如果构造器的参数为空,可以 省略 ()
    val person = new Person
    println(person)

    // 在scala中定义和访问成员变量

    // scala 中 对于var 类型的成员变量 初始值可以使用 _
    // val 修饰的成员变量 不能使用 _ ,需要自己手动赋初始值
    val person1 = new Person
//    println(person1.name)
//    println(person1.age)

    val customer = new Customer

//    customer.sayHello("hello")


    // scala 中的访问控制  没有 public关键字  任何没有被标为 private 或 protected的成员都是公共的

    val goods = new Goods
    goods.setName("apple")
    println(goods.getName())
    println(goods.getNameAndAge())
//    goods.
// scala 中 被 private 修饰的变量 不能被 访问
  }
}
