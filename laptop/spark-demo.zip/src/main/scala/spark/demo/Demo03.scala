package spark.demo

import org.apache.spark.{SparkConf, SparkContext}

object Demo03 {

  def main(args: Array[String]): Unit = {
    // 1. 初始化 Spark 配置与上下文
    val conf = new SparkConf()
      .setAppName("SparkMapCollectExample")
      .setMaster("local[*]") // 本地模式运行，可改成 Yarn 或 Standalone

    val sc = new SparkContext(conf)

    val sourceRdd = sc.textFile("dataset/access_log_sample.txt")

    val mapRdd = sourceRdd.map(e => (e.split(" ")(0), 1))

    val filterRdd = mapRdd.filter(e => !e.equals(" "))

    val reduceRdd = filterRdd.reduceByKey((cur, agg) => cur + agg)

    val rdd = reduceRdd.sortBy(e => e._2, ascending = true)

    rdd.collect().take(10).foreach(println)

    sc.stop()
  }

}
