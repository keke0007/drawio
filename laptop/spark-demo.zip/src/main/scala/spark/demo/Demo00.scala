package spark.demo

import org.apache.spark.{SparkConf, SparkContext}

object Demo00 {

  def main(args: Array[String]): Unit = {

    // 1. 初始化 Spark 配置与上下文
    val conf = new SparkConf()
      .setAppName("SparkMapCollectExample")
      .setMaster("local[*]") // 本地模式运行，可改成 Yarn 或 Standalone

    val sc = new SparkContext(conf)

    // 2. 创建一个集合数据源 (Source)
    val data = Seq(1, 2, 3, 4, 5)
    val rdd = sc.parallelize(data) // 将集合转换为 RDD

    // 3. 使用 map 算子进行转换操作
    val mappedRDD = rdd.map(x => x * x) // 将每个数字平方

    // 4. 使用 collect 将结果收集回 Driver 端
    val result = mappedRDD.collect()

    // 5. 打印结果
    println("原始数据: " + data.mkString(", "))
    println("平方结果: " + result.mkString(", "))

    // 6. 停止 SparkContext
    sc.stop()
  }

}
