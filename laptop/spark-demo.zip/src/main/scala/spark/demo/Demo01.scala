package spark.demo

import org.apache.spark.{SparkConf, SparkContext}

object Demo01 {

  def main(args: Array[String]): Unit = {
    // 1. 初始化 Spark 配置与上下文
    val conf = new SparkConf()
      .setAppName("SparkMapCollectExample")
      .setMaster("local[*]") // 本地模式运行，可改成 Yarn 或 Standalone

    val sc = new SparkContext(conf)

    // 2. 创建一个集合数据源 (Source)
    val data = Seq("hadoop,sqoop,hive", "scala,hadoop,spark,python", "redis,hbase,presto", "flink,clickhouse,doris")
    val rdd1 = sc.parallelize(data) // 将集合转换为 RDD

    // 创建RDD的方式
    // 1.通过本地集合创建   Seq(1,2,3).makeRDD()
    // 2.通过textFile 读取文件创建
    // 3.从RDD 衍生

    // 3. 使用 map 算子进行转换操作
    val rdd2 = rdd1.flatMap(e => e.split(","))

    val rdd3 = rdd2.map(e => (e, 1))

    val rdd4 = rdd3.reduceByKey((cur, agg) => cur + agg)

    val result = rdd4.collect()

    result.foreach(println)

    sc.stop()
  }

}
