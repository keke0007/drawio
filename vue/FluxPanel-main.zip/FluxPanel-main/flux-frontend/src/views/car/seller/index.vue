<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryRef" :inline="true" v-show="showSearch" label-width="68px">

            <el-form-item label="年龄" prop="age">
              <el-input
                v-model="queryParams.age"
                placeholder="请输入年龄"
                clearable
                @keyup.enter="handleQuery"
              />
            </el-form-item>

            <el-form-item label="车辆类型" prop="carType">
              <el-select
                  v-model="queryParams.carType"
                  placeholder="请选择车辆类型"
                  style="width: 180px"
                  clearable>
                <el-option
                  v-for="dict in car_type"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                />
              </el-select>
            </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
        <el-button icon="Refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-card class="base-table" ref="fullTable">
            <TableSetup
                ref="tSetup"
                @onStripe="onStripe"
                @onRefresh="onRefresh"
                @onChange="onChange"
                @onfullTable="onfullTable"
                @onSearchChange="onSearchChange"
                :columns="columns"
                :isTable="isTable"
            >
                <template v-slot:operate>
                    <el-button
                      type="primary"
                      plain
                      icon="Plus"
                      @click="handleAdd"
                      v-hasPermi="['car:seller:add']"
                    >新增</el-button>
                    <el-button
                      type="success"
                      plain
                      icon="Edit"
                      :disabled="single"
                      @click="handleUpdate"
                      v-hasPermi="['car:seller:edit']"
                    >修改</el-button>
                    <el-button
                      type="danger"
                      plain
                      icon="Delete"
                      :disabled="multiple"
                      @click="handleDelete"
                      v-hasPermi="['car:seller:remove']"
                    >删除</el-button>
                    <el-button
                      type="warning"
                      plain
                      icon="Download"
                      @click="handleExport"
                      v-hasPermi="['car:seller:export']"
                    >导出</el-button>
                </template>
            </TableSetup>
            <auto-table
                ref="multipleTable"
                class="mytable"
                :tableData="sellerList"
                :columns="columns"
                :loading="loading"
                :stripe="stripe"
                :tableHeight="tableHeight"
                @onColumnWidthChange="onColumnWidthChange"
                @onSelectionChange="handleSelectionChange"
            >


                    <template #carType="{ row }">
                        <dict-tag :options="car_type" :value="row.carType"/>
                    </template>









                    <template #updateTime="{ row }">
                      <span>{{ parseTime(row.updateTime, '{y}-{m}-{d}') }}</span>
                    </template>
                <template #operate="{ row }">
                  <el-button link type="primary" icon="Edit" @click="handleUpdate(row)" v-hasPermi="['car:seller:edit']">修改</el-button>
                  <el-button link type="primary" icon="Delete" @click="handleDelete(row)" v-hasPermi="['car:seller:remove']">删除</el-button>
                </template>
            </auto-table>
            <div class="table-pagination">
                <pagination
                    v-show="total > 0"
                    :total="total"
                    v-model:page="queryParams.pageNum"
                    v-model:limit="queryParams.pageSize"
                    @pagination="getList"
                />
            </div>
        </el-card>

    <!-- 添加或修改汽车销售对话框 -->
    <el-dialog :title="title" v-model="open" width="800px" append-to-body>
      <el-form ref="sellerRef" :model="form" :rules="rules" label-width="80px">

                <el-form-item label="年龄" prop="age">
                  <el-input v-model="form.age" placeholder="请输入年龄" />
                </el-form-item>

                <el-form-item label="车辆类型" prop="carType">
                  <el-select v-model="form.carType" placeholder="请选择车辆类型">
                    <el-option
                      v-for="dict in car_type"
                      :key="dict.value"
                      :label="dict.label"
                        :value="parseInt(dict.value)"
                    ></el-option>
                  </el-select>
                </el-form-item>

                <el-form-item label="驾龄" prop="driverYears">
                  <el-input v-model="form.driverYears" placeholder="请输入驾龄" />
                </el-form-item>

                <el-form-item label="图片" prop="image">
                  <el-input v-model="form.image" placeholder="请输入图片" />
                </el-form-item>

                <el-form-item label="所在位置" prop="location">
                  <el-input v-model="form.location" placeholder="请输入所在位置" />
                </el-form-item>

                <el-form-item label="销售名字" prop="name">
                  <el-input v-model="form.name" placeholder="请输入销售名字" />
                </el-form-item>

                <el-form-item label="价格" prop="price">
                  <el-input v-model="form.price" placeholder="请输入价格" />
                </el-form-item>

      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">确 定</el-button>
          <el-button @click="cancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Seller">
import { listSeller, getSeller, delSeller, addSeller, updateSeller } from "@/api/car/seller";
import { listAllTable } from '@/api/system/table'
import TableSetup from '@/components/TableSetup'
import AutoTable from '@/components/AutoTable'
const { proxy } = getCurrentInstance();
const { car_type } = proxy.useDict('car_type');

const sellerList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const columns = ref([])
const stripe = ref(true)
const isTable = ref(true)
const tableHeight = ref(500)

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    age: null,
    carType: null,
  },
  rules: {
        age: [
          { required: true, message: "年龄不能为空", trigger: "blur" }
        ],        carType: [
          { required: true, message: "车辆类型不能为空", trigger: "change" }
        ],        driverYears: [
          { required: true, message: "驾龄不能为空", trigger: "blur" }
        ],        name: [
          { required: true, message: "销售名字不能为空", trigger: "blur" }
        ],        price: [
          { required: true, message: "价格不能为空", trigger: "blur" }
        ],  }
});

const { queryParams, form, rules } = toRefs(data);

/** 查询汽车销售列表 */
function getList() {
  loading.value = true;
  listSeller(queryParams.value).then(response => {
    sellerList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

function getColumns() {
    listAllTable({ tableName: 'car_seller' })
        .then((response) => {
            columns.value = response.data
        })
        .then(() => {
            getList()
        })
}

// 取消按钮
function cancel() {
  open.value = false;
  reset();
}

// 表单重置
function reset() {
  form.value = {
        age: null,        carType: null,        createTime: null,        delFlag: null,        driverYears: null,        id: null,        image: null,        location: null,        name: null,        price: null,        updateTime: null  };
  proxy.resetForm("sellerRef");
}

/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 新增按钮操作 */
function handleAdd() {
  reset();
  open.value = true;
  title.value = "添加汽车销售";
}

/** 修改按钮操作 */
function handleUpdate(row) {
  reset();
  const carSellerId = row.id || ids.value
  getSeller(carSellerId).then(response => {
    form.value = response.data;
    open.value = true;
    title.value = "修改汽车销售";
  });
}

/** 提交按钮 */
function submitForm() {
  proxy.$refs["sellerRef"].validate(valid => {
    if (valid) {
      if (form.value.id != null) {
        updateSeller(form.value).then(response => {
          proxy.$modal.msgSuccess("修改成功");
          open.value = false;
          getList();
        });
      } else {
        addSeller(form.value).then(response => {
          proxy.$modal.msgSuccess("新增成功");
          open.value = false;
          getList();
        });
      }
    }
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.id || ids.value;
  proxy.$modal.confirm('是否确认删除汽车销售编号为"' + _ids + '"的数据项？').then(function() {
    return delSeller(_ids);
  }).then(() => {
    getList();
    proxy.$modal.msgSuccess("删除成功");
  }).catch(() => {});
}


/** 导出按钮操作 */
function handleExport() {
  proxy.download('car/seller/export', {
    ...queryParams.value
  }, `seller_${new Date().getTime()}.xlsx`)
}

//表格全屏
function onfullTable() {
    proxy.$refs.tSetup.onFull(proxy.$refs.fullTable.$el)
}
//表格刷新
function onRefresh() {
    getList()
}
//搜索框显示隐藏
function onSearchChange() {
    showSearch.value = !showSearch.value
}

function onStripe(val) {
    stripe.value = val
}
//改变表头数据
function onChange(val) {
    columns.value = val
}

//改变表格宽度
function onColumnWidthChange(column) {
    proxy.$refs.tSetup.tableWidth(column)
}

getColumns()

</script>