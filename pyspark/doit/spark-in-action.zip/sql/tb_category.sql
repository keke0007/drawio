/*
 Navicat Premium Data Transfer

 Source Server         : node-1
 Source Server Type    : MySQL
 Source Server Version : 50731
 Source Host           : node-1.51doit.cn:3306
 Source Schema         : doit35

 Target Server Type    : MySQL
 Target Server Version : 50731
 File Encoding         : 65001

 Date: 23/12/2022 15:04:28
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_category
-- ----------------------------
DROP TABLE IF EXISTS `tb_category`;
CREATE TABLE `tb_category` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_category
-- ----------------------------
BEGIN;
INSERT INTO `tb_category` VALUES (10, '手机');
INSERT INTO `tb_category` VALUES (11, '电脑');
INSERT INTO `tb_category` VALUES (12, '化妆品');
INSERT INTO `tb_category` VALUES (13, '厨具');
INSERT INTO `tb_category` VALUES (14, '图书');
INSERT INTO `tb_category` VALUES (15, '服装');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
