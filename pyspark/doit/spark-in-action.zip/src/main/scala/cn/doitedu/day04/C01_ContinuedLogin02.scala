package cn.doitedu.day04

import java.text.SimpleDateFormat
import java.util.Calendar

import cn.doitedu.utils.SparkUtil
import org.apache.spark.Partitioner
import org.apache.spark.rdd.RDD

import scala.collection.mutable

/**
 * 统计连续登录3天以上的用户有哪些，并且计算出连续登录的起始日期结束日期
 */
object C01_ContinuedLogin02 {

  def main(args: Array[String]): Unit = {

    val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, isLocal)

    //指定以后从哪里读取数据创建RDD
    val lines: RDD[String] = sc.textFile(args(1))

    //对RDD调用Transformation 进行整理
    val uidAndDt: RDD[(String, String)] = lines.map(line => {
      val fields = line.split(",")
      val uid = fields(0)
      val dt = fields(1)
      (uid, dt)
    }).distinct()

    //触发Action，将用户ID计算出来，返回客户端
    val uids: Array[String] = uidAndDt.map(_._1).distinct().collect()

    //将同一个用户的数据搞到一起
    //为了避免属性分组toList内存溢出的情况
    //分区，然后再分区内排序（内存+磁盘）
    val partitioner = new UidPartitioner(uids)
    //按照用户ID进行分区，并且一个分区内有且仅有一个用户的数据
    val uidDtAndNull: RDD[((String, String), Null)] = uidAndDt.map(t => (t, null))

    val partitionedAndSorted: RDD[((String, String), Null)] = uidDtAndNull.repartitionAndSortWithinPartitions(partitioner)

    val res = partitionedAndSorted.mapPartitions(it => {
      var index = 0
      val sdf = new SimpleDateFormat("yyyy-MM-dd")
      val calendar = Calendar.getInstance()
      it.map { case ((uid, dt), _) => {
        index += 1
        calendar.setTime(sdf.parse(dt))
        calendar.add(Calendar.DATE, -index)
        val dateDif = sdf.format(calendar.getTime)
        ((uid, dateDif), (dt, dt, 1))
      }
      }
    }).reduceByKey((a, b) => {
      (Ordering[String].min(a._1, b._1), Ordering[String].max(a._2, b._2), a._3 + b._3)
    }).map { case ((uid, _), (startDt, endDt, count)) => {
      (uid, startDt, endDt, count)
    }
    }.filter(_._4 >= 3)

    res.saveAsTextFile("out/07")
  }

}

class UidPartitioner(val uids: Array[String]) extends Partitioner {

  val idToIndex = new mutable.HashMap[String, Int]
  var index = 0
  for (uid <- uids) {
    idToIndex(uid) = index
    index += 1
  }

  override def numPartitions: Int = uids.length

  override def getPartition(key: Any): Int = {
    val uid = key.asInstanceOf[(String, String)]._1
    idToIndex(uid)
  }
}
