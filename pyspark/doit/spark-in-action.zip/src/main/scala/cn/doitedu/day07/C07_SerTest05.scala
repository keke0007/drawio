package cn.doitedu.day07

import java.net.InetAddress

import cn.doitedu.utils.SparkUtil
import org.apache.spark.TaskContext

object C07_SerTest05 {


  def main(args: Array[String]): Unit = {

    val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, isLocal)

    //从HDFS中读取数据，创建RDD
    //HDFS指定的目录中有4个小文件,内容如下：
    //1,ln
    val lines = sc.textFile(args(1))
    //不再Driver端初始化RuleObjectSer或RuleClassSer
    //函数实在Driver定义的
    val func = (line: String) => {
      val fields = line.split(",")
      val id = fields(0).toInt
      val code = fields(1)
      //在函数内部初始化没有实现序列化接口的RuleObjectNotSer
      val name = RuleObjectNotSer.rulesMap.getOrElse(code, "未知")
      //获取当前线程ID
      val treadId = Thread.currentThread().getId
      //获取当前Task对应的分区编号
      val partitiondId = TaskContext.getPartitionId()
      //获取当前Task运行时的所在机器的主机名
      val host = InetAddress.getLocalHost.getHostName
      (id, code, name, treadId, partitiondId, host, RuleObjectNotSer.toString)
    }

    //处理数据，关联维度
    val res = lines.map(func)
    res.saveAsTextFile(args(2))
    sc.stop()

  }

}
