package cn.doitedu.day03

import org.apache.spark.rdd.{PairRDDFunctions, RDD, ShuffledRDD}
import org.apache.spark.{Aggregator, HashPartitioner, SparkConf, SparkContext, TaskContext}

/**
 * 使用底层的ShuffledRDD实现类似reduceByKey的功能
 */
object C03_ShuffledRDDDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)


    val lst: Seq[(String, Int)] = List(
      ("spark", 5), ("hadoop", 1), ("hive", 1), ("spark", 1),
      ("spark", 7), ("flink", 1), ("hbase", 1), ("spark", 3),
      ("kafka", 1), ("kafka", 1), ("kafka", 1), ("kafka", 1),
      ("hadoop", 1), ("flink", 4), ("hive", 1), ("flink", 1)
    )
    //通过并行化的方式创建RDD，分区数量为4
    val wordAndOne: RDD[(String, Int)] = sc.parallelize(lst, 4)

    //隐式转换
    //val reduced = wordAndOne.reduceByKey(_ + _)

    //显式的包装
    //val pairRDDFunc = new PairRDDFunctions[String, Int](wordAndOne)
    //pairRDDFunc.reduceByKey(_+_)


    //使用底层的ShuffledRDD，实现类似ReduceByKey的功能
    //指定分区器（根据计算分区编号的）
    val partitioner = new HashPartitioner(wordAndOne.partitions.length)
    //如果shuffleRDD传入了分区器，仅是完成了分区的功能
    val shuffledRDD = new ShuffledRDD[String, Int, Int](wordAndOne, partitioner)

    //实现聚合的功能
    val f1 = (x: Int) => {
      val stage = TaskContext.get().stageId()
      val partition = TaskContext.getPartitionId()
      println(s"f1 function invoked in state: $stage, partition: $partition")
      x
    }
    val f2 = (a: Int, b: Int) => {
      val stage = TaskContext.get().stageId()
      val partition = TaskContext.getPartitionId()
      println(s"f2 function invoked in state: $stage, partition: $partition")
      a + b
    }
    val f3 = (m: Int, n: Int) => {
      val stage = TaskContext.get().stageId()
      val partition = TaskContext.getPartitionId()
      println(s"f3 function invoked in state: $stage, partition: $partition")
      m + n
    }
    val aggregator = new Aggregator[String, Int, Int](f1, f2, f3)
    shuffledRDD.setAggregator(aggregator)
    //设置mapSideCombine = true，三个函数都会执行，前两个函数在上游执行，第三个函数在下游执行
    //shuffledRDD.setMapSideCombine(true) //


    shuffledRDD.setMapSideCombine(false)



    shuffledRDD.saveAsTextFile("out/08")

  }
}
