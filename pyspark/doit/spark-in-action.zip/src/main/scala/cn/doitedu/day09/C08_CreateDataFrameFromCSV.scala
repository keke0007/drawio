package cn.doitedu.day09

import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * 读取CSV文件，直接创建DataFrame
 *
 */
object C08_CreateDataFrameFromCSV {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("SQLContinuedLogin")
      .master("local[*]")
      .getOrCreate()


    //有Schema信息
    //csv方法也触发Action，默认只读取一行，按照指定的分隔符","进行切分
    val df: DataFrame = spark.read.csv("data/data.txt")

    df.printSchema()
    df.show()

    Thread.sleep(100000000)


  }


}
