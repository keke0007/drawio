package cn.doitedu.day10

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object C14_DataFrameAndDataSetAndRDD {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("SQLContinuedLogin")
      .master("local[*]")
      .getOrCreate()

    import org.apache.spark.sql.functions._
    import spark.implicits._

    val df = spark.read.csv("data/stu.txt").toDF("name", "age", "gender")

    val ds: Dataset[(String, Int, String)] = df.map(row => {
      val name = row.get(0).asInstanceOf[String]
      val age = row.getString(1).toInt
      val gender = row.getString(2)
      (name, age, gender)
    })

    val df2: DataFrame = ds.toDF("name", "age", "gender")
    df2.printSchema()

    df2.show()

  }
}
