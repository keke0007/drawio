package cn.doitedu.day05

import cn.doitedu.utils.SparkUtil

/**
 * sum方法是Action，实现的逻辑只能是相加
 */
object C07_MaxDemo {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    val rdd1 = sc.parallelize(List(5,7 ,9,6,1 ,8,2, 4,3,10), 4)
    //没有shuffle
    val r: Int = rdd1.max()

  }
}
