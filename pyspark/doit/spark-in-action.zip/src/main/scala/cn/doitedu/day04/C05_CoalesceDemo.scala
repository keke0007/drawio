package cn.doitedu.day04

import cn.doitedu.utils.SparkUtil
import org.apache.spark.rdd.RDD

/**
 *
 */
object C05_CoalesceDemo {

  def main(args: Array[String]): Unit = {

    val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, isLocal)

    //指定以后从哪里读取数据创建RDD
    val rdd1: RDD[Int] = sc.parallelize(List(1, 2, 3, 4, 5, 6, 7, 8, 9, 10), 4)

    //一定shuffle
    val rdd2: RDD[Int] = rdd1.coalesce(4, true)

    //不shuffle，将多个分区合并到一起（窄依赖）
    val rdd3: RDD[Int] = rdd1.coalesce(2, false)

    rdd3.saveAsTextFile("out/08")
  }
}
