package cn.doitedu.day03

import java.text.SimpleDateFormat
import java.util.Calendar

import cn.doitedu.utils.SparkUtil
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD

/**
 * 统计连续登录3天以上的用户有哪些，并且计算出连续登录的起始日期结束日期
 */
object C09_ContinuedLogin {

  def main(args: Array[String]): Unit = {

    val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, isLocal)

    //指定以后从哪里读取数据创建RDD
    val lines: RDD[String] = sc.textFile(args(1))

    //对RDD调用Transformation 进行整理
    val uidAndDt = lines.map(line => {
      val fields = line.split(",")
      val uid = fields(0)
      val dt = fields(1)
      (uid, dt)
    }).distinct()

    //将同一个用户的数据搞到一起
    //使用分组的方式，同一个用户的数据被分到了一个组内
    val grouped: RDD[(String, Iterable[String])] = uidAndDt.groupByKey()

    //将同一个用户的数据在组内排序
    val uidDifAndDt: RDD[((String, String), (String, String, Int))] = grouped.flatMapValues(it => {
      //将数据toList放到内存并排序
      val sorted = it.toList.sorted
      val sdf = new SimpleDateFormat("yyyy-MM-dd")
      val calendar = Calendar.getInstance()
      var index = 0
      sorted.map(dt => {
        //每map一次，行号自增
        index += 1
        //日期减行号
        calendar.setTime(sdf.parse(dt))
        calendar.add(Calendar.DATE, -index)
        val dateDif = sdf.format(calendar.getTime)
        (dt, dateDif)
      })
    }) //.map(t => ((t._1, t._2._2), t._2._1))
      .map { case (uid, (dt, dateDif)) => {
        ((uid, dateDif), (dt, dt, 1))
      }}

    val res = uidDifAndDt.reduceByKey((a, b) => {
      (Ordering[String].min(a._1, b._1), Ordering[String].max(a._2, b._2), a._3 + b._3)
    }).map { case ((uid, _), (startDt, endDt, count)) => {
      (uid, startDt, endDt, count)
    }}.filter(_._4 >= 3)


    res.saveAsTextFile("out23")
  }

}
