package cn.doitedu.day06

import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}

object C02_PersistDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //设置spark的序列化方式为KryoSerializer
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")

    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //创建RDD，并没有立即读取数据，而是触发Action才会读取数据
    val rdd1 = sc.textFile("hdfs://node-1.51doit.cn:9000/cache")

    //最好对数据过滤、整理后再进行cache
    val rdd2 = rdd1.filter(_.contains("bigdata"))

    //对rdd2进行cache(放到内存中)
    //cache并么有生成新的RDD，只是标记当前的RDD中对应的分区要被cache
    //rdd2.persist() //StorageLevel.MEMORY_ONLY, 以java对象的形式，放入到内存中 等价于cache

    //将数据放入内存中，并且用指定的序列化方式进行序列化
    //java对象占用的空间大，序列化反序列化效率低，spark默认的序列化方式为java对象的方式
    //spark推荐使用Kryo序列方式，更快，更紧凑
    rdd2.persist(StorageLevel.MEMORY_ONLY_SER)

    //第一次触发Action，速度不会很快，甚至要更慢一些
    val c1 = rdd2.count()

    //再次触发Action，会比以前快几十倍，因为数据不是从HDFS中读取的，而是内存中读取的
    val c2 = rdd2.count()

  }
}
