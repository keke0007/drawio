package cn.doitedu.day03

import org.apache.spark._
import org.apache.spark.rdd.{RDD, ShuffledRDD}

import scala.collection.mutable.ArrayBuffer

/**
 * groupByKey、groupBy都是用来分组的
 */
object C05_GroupByDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)


    val lst: Seq[(String, Int)] = List(
      ("spark", 5), ("hadoop", 1), ("hive", 1), ("spark", 1),
      ("spark", 7), ("flink", 1), ("hbase", 1), ("spark", 3),
      ("kafka", 1), ("kafka", 1), ("kafka", 1), ("kafka", 1),
      ("hadoop", 1), ("flink", 4), ("hive", 1), ("flink", 1)
    )
    //通过并行化的方式创建RDD，分区数量为4
    val wordAndOne: RDD[(String, Int)] = sc.parallelize(lst, 4)

    val grouped: RDD[(String, Iterable[(String, Int)])] = wordAndOne.groupBy(t => t._1)

    //grouped.saveAsTextFile("out/11")



    val lst2 = List(
      ("山东省", "滨州市", 3000),
      ("山东省", "烟台市", 2000),
      ("辽宁省", "大连市", 4000),
      ("辽宁省", "沈阳市", 5000)
    )

    val rdd1: RDD[(String, String, Int)] = sc.parallelize(lst2)

    val grouped2: RDD[(String, Iterable[(String, String, Int)])] = rdd1.groupBy(_._1)
    //grouped2.saveAsTextFile("out/12")
    val rdd2: RDD[(String, (String, Int))] = rdd1.map(t => (t._1, (t._2, t._3)))
    val grouped3: RDD[(String, Iterable[(String, Int)])] = rdd2.groupByKey()

  }
}
