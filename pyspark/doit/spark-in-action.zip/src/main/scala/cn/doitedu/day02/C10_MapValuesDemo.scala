package cn.doitedu.day02

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object C10_MapValuesDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)


    val lst = List(("spark", 5), ("hive", 3), ("hbase", 4), ("flink", 8))
    val rdd1: RDD[(String, Int)] = sc.parallelize(lst, 2)

    //将每一个元素的次数(value)乘以10再可跟key组合在一起
    //val rdd2: RDD[(String, Int)] = rdd1.map(t => (t._1, t._2 * 10))

    val rdd3: RDD[(String, Int)] = rdd1.mapValues(v => v * 10)


    println(rdd3.collect().toBuffer)

  }
}
