package cn.doitedu.day10

import java.util.Properties

import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

/**
 * 读取Parquet文件中的数据，经过处理，写入到MySQL
 *
 */
object C05_WriteToMySQL {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("SQLContinuedLogin")
      .master("local[*]")
      .getOrCreate()

    //有Schema信息
    val df: DataFrame = spark.read.parquet("data/data.snappy.parquet")

    df.printSchema()

    val props = new Properties()
    //指定连接驱动类型
    props.setProperty("driver", "com.mysql.cj.jdbc.Driver")
    //mysql用户名
    props.setProperty("user", "root")
    //密码
    props.setProperty("password", "123456")

    val url = "jdbc:mysql://node-1.51doit.cn:3306/doit?characterEncoding=utf-8"

    //对数据进行处理
    df.write
      .mode(SaveMode.Append)
      .jdbc(url, "tb_user_flow", props)


  }


}
