package cn.doitedu.day02

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object C04_FilterDemo {

  def main(args: Array[String]): Unit = {



    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //scala集合，在Driver端的JVM的普通集合
    val lst = List(1,2,3,4,5,6,7,8,9)

    val rdd1 = sc.parallelize(lst, 2)

    val filtered: RDD[Int] = rdd1.filter(_ * 2 == 0)

    filtered.saveAsTextFile("out2")

    sc.stop()
  }

}
