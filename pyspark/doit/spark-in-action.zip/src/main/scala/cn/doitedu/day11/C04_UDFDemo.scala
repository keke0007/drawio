package cn.doitedu.day11

import org.apache.spark.sql.SparkSession

/**
 * Spark SQL 的自定义函数
 *
 * User Defined Function
 *
 * 自定义函数分为3中
 * UDF  输入一行，返回一行
 * UDAF 输入多行，返回一行（一个组返回一行）
 * UDTF 输入一行，返回多行
 *
 */
object C04_UDFDemo {

  def main(args: Array[String]): Unit = {

    val spark: SparkSession = SparkSession.builder()
      .appName("SQLDemo1")
      .master("local[*]")
      .getOrCreate() //创建一个SparkSession或使用已有的SparkSession

    val df = spark.read
      .option("header", "true")
      .csv("data/location.csv")

    df.createTempView("v_user_info")

    //自定义函数(先注册一个函数)
    spark.udf.register("my_concat_ws", (split: String, province: String, city: String) => {
      province + split + city
    })


    //concat_ws 是 sparksql内置的udf
    val res = spark.sql(
      """
        |select name, my_concat_ws('-', province, city) location from v_user_info
        |""".stripMargin)

    res.show()

  }
}
