package cn.doitedu.day05

import cn.doitedu.utils.SparkUtil

/**
 * top方法是Action，返回RDD中最大的前n个元素
 */
object C12_foreachDemo {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    val rdd1 = sc.parallelize(List(
      5, 7, 6, 4,
      9, 6, 1, 7,
      8, 2, 8, 5,
      4, 3, 10, 9
    ), 4)

    rdd1.foreach(e => {
      println(e * 10)
    })
  }
}
