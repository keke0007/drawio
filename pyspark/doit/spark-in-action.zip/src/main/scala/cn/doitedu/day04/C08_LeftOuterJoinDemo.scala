package cn.doitedu.day04

import cn.doitedu.utils.SparkUtil
import org.apache.spark.rdd.RDD

/**
 * 为什么要join
 * 想要的数据来自多个RDD，并且数据之间存在着关联关系，那么就要多个RDD中的数据关联到一起
 *
 * 左外连接，即左面RDD（第一个RDD）的数据即使没有join上，也输出
 *
 *
 *
 */
object C08_LeftOuterJoinDemo {

  def main(args: Array[String]): Unit = {

    val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, isLocal)

    //通过并行化的方式创建一个RDD
    val rdd1 = sc.parallelize(List(("tom", 1), ("tom", 2), ("jerry", 3), ("kitty", 2)), 2)
    //通过并行化的方式再创建一个RDD
    val rdd2 = sc.parallelize(List(("jerry", 2), ("tom", 1), ("shuke", 2), ("jerry", 4)), 2)

    val rdd33: RDD[(String, (Int, Option[Int]))] = rdd1.leftOuterJoin(rdd2)

    //使用cogroup实现类似leftOuterJoin的功能
    val rdd3: RDD[(String, (Iterable[Int], Iterable[Int]))] = rdd1.cogroup(rdd2)

    val rdd4: RDD[(String, (Int, Option[Int]))] = rdd3.flatMapValues(t => {
      if (t._1.nonEmpty && t._2.isEmpty) {
        t._1.map((_, None))
      } else {
        for (e1 <- t._1; e2 <- t._2) yield (e1, Some(e2))
      }
    })

    rdd4.saveAsTextFile("out/13")
  }
}
