package cn.doitedu.day02

import java.sql.DriverManager

import org.apache.spark.{SparkConf, SparkContext}

/**
 * 将RDD中的数据，以分区为单位，进行相应的处理
 *
 * 即mapPartitions方法函数的输入是一个迭代器，函数的返回值也必须是迭代器
 *
 * mapPartitionsWithIndex可以将RDD的分区编号作为参数传入
 *
 */
object C07_MapPartitionsWithIndexDemo {


  def main(args: Array[String]): Unit = {


    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    val lst = Array(1,2,3,4,5,6,7,8,9)

    val rdd1 = sc.parallelize(lst, 2)

    val rdd2 = rdd1.mapPartitionsWithIndex((index, it) => {
      it.map(e => {
        s"partition: $index, element: $e"
      })
    })

    rdd2.saveAsTextFile("out/03")

    sc.stop()

  }

}
