package cn.doitedu.day04

import cn.doitedu.utils.SparkUtil
import org.apache.spark.rdd.RDD

/**
 * 取笛卡尔积
 *
 *
 */
object C13_CartesianDemo {

  def main(args: Array[String]): Unit = {

    //val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, true)
    val rdd1 = sc.parallelize(List("tom", "jerry"), 2)
    val rdd2 = sc.parallelize(List("tom", "kitty", "shuke"), 3)
    val rdd3 = rdd1.cartesian(rdd2)

    println(rdd3.collect.toBuffer)
  }
}
