package cn.doitedu.day04

import cn.doitedu.utils.SparkUtil
import org.apache.spark.rdd.RDD

/**
 * 为什么要join
 * 想要的数据来自多个RDD，并且数据之间存在着关联关系，那么就要多个RDD中的数据关联到一起
 *
 * join，类似SQL中的InnerJoin
 *
 *
 *
 */
object C07_JoinDemo {

  def main(args: Array[String]): Unit = {

    val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, isLocal)

    //通过并行化的方式创建一个RDD
    val rdd1 = sc.parallelize(List(("tom", 1), ("tom", 2), ("jerry", 3), ("kitty", 2)), 2)
    //通过并行化的方式再创建一个RDD
    val rdd2 = sc.parallelize(List(("jerry", 2), ("tom", 1), ("shuke", 2), ("jerry", 4)), 2)

    val rdd33: RDD[(String, (Int, Int))] = rdd1.join(rdd2)

    //不适应join，而是使用底层的cogroup，实现类似join的功能
    val rdd3: RDD[(String, (Iterable[Int], Iterable[Int]))] = rdd1.cogroup(rdd2)

    //(tom,1), (tom,2) 第一个RDD
    //(tom,1), (tom,3) 第二个RDD
    //(tom, (1,1)), (tom, (1, 3)), (tom, (2, 1), (tom, (2, 3)))
    val rdd4: RDD[(String, (Int, Int))] = rdd3.flatMapValues { case (it1, it2) => {
      for (e1 <- it1; e2 <- it2) yield (e1, e2)
    }}

    rdd4.saveAsTextFile("out/11")
  }
}
