package cn.doitedu.day09

import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * 读取CSV文件，直接创建DataFrame
 *
 */
object C13_CreateDataFrameFromOrc {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("SQLContinuedLogin")
      .master("local[*]")
      .getOrCreate()


    //有Schema信息

    val df: DataFrame = spark.read.orc("data/data.snappy.orc")

    df.printSchema()

    df.show()

    Thread.sleep(100000000)
  }


}
