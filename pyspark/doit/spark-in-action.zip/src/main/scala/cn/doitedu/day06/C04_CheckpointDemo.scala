package cn.doitedu.day06

import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}

/**
 * 可以将checkpoint对应RDD的数据保存到HDFS中
 *
 * 特点：比保存的内存或磁盘更安全，缺点是比放入到内存中稍微慢一些
 *
 * checkpoint的使用场景：
 *   1.机器学习训练的中间结果
 *   2.经过复杂运算计算出的中间结果
 */
object C04_CheckpointDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程

    //1.创建SparkContext
    val sc = new SparkContext(conf)

    sc.setCheckpointDir("hdfs://node-1.51doit.cn:9000/chk36")

    //创建RDD，并没有立即读取数据，而是触发Action才会读取数据
    val rdd1 = sc.textFile("hdfs://node-1.51doit.cn:9000/cache")

    //经过复杂运算得到的中间结果（很宝贵）
    val rdd2 = rdd1.filter(_.contains("bigdata"))

    //如果persist到内存或磁盘，有可能会丢失数据
    //为了保证中间结果更加安全,可以调用RDD的checkpoint方法
    rdd2.checkpoint()

    //第一次触发Action，才会将数据保存到HDFS中
    rdd2.count()

    //再次触发Action，才会从HDFS中读取数据
    rdd2.count()

    rdd2.unpersist() //不会移除checkpoint的数据



  }
}
