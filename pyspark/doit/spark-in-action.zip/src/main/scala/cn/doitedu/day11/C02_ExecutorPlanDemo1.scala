package cn.doitedu.day11

import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

/**
 * 演示一下执行计划
 */
object C02_ExecutorPlanDemo1 {

  def main(args: Array[String]): Unit = {

    val spark: SparkSession = SparkSession.builder()
      .appName("SQLDemo1")
      .master("local[*]")
      .getOrCreate() //创建一个SparkSession或使用已有的SparkSession

    import spark.implicits._
    val df: Dataset[Row] = spark.read.parquet("data/data.snappy.parquet")

    df.printSchema()


    /**
     * select uid, flow * 1.1 as flow where flow >= 100
     */
    val df2: DataFrame = df.select("flow", "end_time", "start_time", "uid")

    val res: Dataset[Row] = df2.select($"flow" * 1.1 as "flow", $"uid")
      .where($"flow" >= 100)
      .select("uid", "flow")

    //SparkSql、Hive的执行计划
    //1. Parsed Logical Plan (语法解析，生成SQL语法数据)
    //2. Analyzed Logical Plan (分析字段的类型等)
    //3. Optimized Logical Plan (对逻辑集合进行优化)
    //4. Physical Plan(根据读取数据的格式，生成最终的Task)
    res.explain(true) //查看完整的执行计划


    res.show()
  }

}
