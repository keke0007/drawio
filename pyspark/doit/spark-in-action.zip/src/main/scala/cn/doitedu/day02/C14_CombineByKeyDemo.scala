package cn.doitedu.day02

import org.apache.spark.rdd.{RDD, ShuffledRDD}
import org.apache.spark.{Aggregator, HashPartitioner, SparkConf, SparkContext, TaskContext}

/**
 * ReduceByKey底层调用的是CombineByKeyWithClassTag
 */
object C14_CombineByKeyDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)


    val lst: Seq[(String, Int)] = List(
      ("spark", 1), ("hadoop", 1), ("hive", 1), ("spark", 1),
      ("spark", 1), ("flink", 1), ("hbase", 1), ("spark", 1),
      ("kafka", 1), ("kafka", 1), ("kafka", 1), ("kafka", 1),
      ("hadoop", 1), ("flink", 1), ("hive", 1), ("flink", 1)
    )
    val wordAndOne = sc.parallelize(lst)

    //调用combineByKey实现与reduceByKey同样的功能
    //前两个函数是在上游执行的
    //在每个分区中，key第一次出现，将value进行相应的操作
    val f1 = (x: Int) => {
      val stage = TaskContext.get().stageId()
      val partition = TaskContext.getPartitionId()
      println(s"f1 function invoked in state: $stage, partition: $partition")
      x
    }
    //在每个分区内，将key相同的value进行局部聚合操作
    val f2 = (a: Int, b: Int) => {
      val stage = TaskContext.get().stageId()
      val partition = TaskContext.getPartitionId()
      println(s"f2 function invoked in state: $stage, partition: $partition")
      a + b
    }
    //第三个函数是在下游完成的
    val f3 = (m: Int, n: Int) => {
      val stage = TaskContext.get().stageId()
      val partition = TaskContext.getPartitionId()
      println(s"f3 function invoked in state: $stage, partition: $partition")
      m + n
    }

    val reduced: RDD[(String, Int)] = wordAndOne.combineByKey(f1, f2, f3)


    println(reduced.collect().toBuffer)

  }
}
