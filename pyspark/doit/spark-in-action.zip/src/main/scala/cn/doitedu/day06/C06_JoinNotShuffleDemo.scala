package cn.doitedu.day06

import org.apache.spark.rdd.RDD
import org.apache.spark.{HashPartitioner, SparkConf, SparkContext}


/**
 * ReduceByKey一般情况下都Shuffle，在特殊情况下可以不Shuffle
 */
object C06_JoinNotShuffleDemo {

  def main(args: Array[String]): Unit = {


    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)


    //通过并行化的方式创建一个RDD
    val rdd1 = sc.parallelize(List(("tom", 1), ("tom", 2), ("jerry", 3), ("kitty", 2)), 2)
    //通过并行化的方式再创建一个RDD
    val rdd2 = sc.parallelize(List(("jerry", 2), ("tom", 1), ("shuke", 2), ("jerry", 4)), 2)
    val rdd3: RDD[(String, (Int, Int))] = rdd1.join(rdd2)


    val rdd11 = rdd1.groupByKey()

    val rdd22 = rdd2.groupByKey()

    val rdd33 = rdd11.join(rdd22)

    rdd33.saveAsTextFile("hdfs://node-1.51doit.cn:9000/out-36-86")
  }

}
