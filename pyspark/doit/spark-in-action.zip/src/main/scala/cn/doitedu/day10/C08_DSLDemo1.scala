package cn.doitedu.day10

import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * DSL风格的语法，就是直接调用DataFrame或Dataset上的方法（传入的不是函数，而是一种特殊的表达式），而不是写SQL
 *
 * select filter 属于逐行运算
 */
object C08_DSLDemo1 {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("SQLContinuedLogin")
      .master("local[*]")
      .getOrCreate()

    //有Schema信息
    val df: DataFrame = spark.read.parquet("data/data.snappy.parquet")

    //df.printSchema()

    //df.show()
    //直接调用DataFrame的方法
    val df2: DataFrame = df.select("uid", "flow")

    import spark.implicits._
    val df3: DataFrame = df.select($"uid", $"flow")

    //一个单引号
    val df4: DataFrame = df.select('uid, 'flow).where($"flow" >= 20)

    val df5: DataFrame = df.select($"uid", 'flow)


    df4.show()

  }


}
