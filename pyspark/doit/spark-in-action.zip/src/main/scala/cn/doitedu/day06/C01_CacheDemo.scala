package cn.doitedu.day06

import org.apache.spark.{SparkConf, SparkContext}

object C01_CacheDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //创建RDD，并没有立即读取数据，而是触发Action才会读取数据
    val rdd1 = sc.textFile("hdfs://node-1.51doit.cn:9000/cache")

    //最好对数据过滤、整理后再进行cache
    val rdd2 = rdd1.filter(_.contains("bigdata"))

    //对rdd2进行cache(放到内存中)
    //cache并么有生成新的RDD，只是标记当前的RDD中对应的分区要被cache
    rdd2.cache()

    //第一次触发Action，速度不会很快，甚至要更慢一些
    val c1 = rdd2.count()

    //再次触发Action，会比以前快几十倍，因为数据不是从HDFS中读取的，而是内存中读取的
    val c2 = rdd2.count()

  }
}
