package cn.doitedu.day07

import cn.doitedu.utils.{DateUtilClass, DateUtilObj}
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

/**
 * 演示一个Executor中多个Task，访问一个共享对象（工具类），同时有读写操作，会出现线程不安全的问题
 */
object C11_TaskThreadNotSafe2 {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    val lines = sc.textFile("data/date.txt")

    val timeRDD = lines.mapPartitions(it => {
      //一个Task使用自己单独的DateUtilClass实例，缺点是浪费内存资源
      val dataUtil = new DateUtilClass
      it.map(e => {
        dataUtil.parse(e)
      })
    })

    val res = timeRDD.collect()
    println(res.toBuffer)
  }

}
