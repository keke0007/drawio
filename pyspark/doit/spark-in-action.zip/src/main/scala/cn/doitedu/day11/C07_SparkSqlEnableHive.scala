package cn.doitedu.day11

import cn.doitedu.day07.Boy
import cn.doitedu.utils.IpUtils
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.{DataFrame, Encoder, Encoders, SparkSession}
import org.apache.spark.sql.expressions.Aggregator

/**
 *
 * sparksqk开启hive的支持
 */
object C07_SparkSqlEnableHive {

  def main(args: Array[String]): Unit = {

    val spark: SparkSession = SparkSession.builder()
      .appName("SQLDemo1")
      .master("local[*]")
      .enableHiveSupport() //开启对hive的支持
      .getOrCreate() //创建一个SparkSession或使用已有的SparkSession

    //spark.sql("create table tb_users_v2 (id bigint, name string) row format delimited fields terminated by ',' ")
    //spark.sql("use doit");
    val df: DataFrame = spark.sql("select * from doit.tb_users_v2 order by id desc")

    df.show()

  }
}

