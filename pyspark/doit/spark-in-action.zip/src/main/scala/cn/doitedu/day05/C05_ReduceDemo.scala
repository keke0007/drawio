package cn.doitedu.day05

import cn.doitedu.utils.SparkUtil

/**
 * reduce方法是Action
 */
object C05_ReduceDemo {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    val rdd1 = sc.parallelize(List(1,2,3,4,5,6,7,8,9,10), 4)
    val f1 = (a: Int, b: Int) => {
      println("f1 function invoked ~~~~")
      a + b
    }
    //f1这个函数即在Executor中执行，又在Driver端执行
    //reduce方法局部聚合的逻辑和全局聚合的逻辑是一样的
    //局部聚合是在每个分区内完成（Executor）
    //全局聚合实在Driver完成的
    val r = rdd1.reduce(f1)

  }
}
