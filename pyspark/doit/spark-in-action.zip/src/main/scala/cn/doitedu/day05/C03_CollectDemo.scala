package cn.doitedu.day05

import java.text.SimpleDateFormat

import cn.doitedu.utils.SparkUtil
import org.apache.spark.rdd.RDD

object C03_CollectDemo {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    val rdd1 = sc.parallelize(List(1,2,3,4,5,6,7,8,9,10), 4)
    val rdd2 = rdd1.map(_ * 10)
    //调用collect方法，是一个Action
    val res: Array[Int] = rdd2.collect()
    println(res.toBuffer)
  }
}
