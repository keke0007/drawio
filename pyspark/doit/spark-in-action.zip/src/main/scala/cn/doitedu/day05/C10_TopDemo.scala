package cn.doitedu.day05

import cn.doitedu.utils.SparkUtil

/**
 * top方法是Action，返回RDD中最大的前n个元素
 */
object C10_TopDemo {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    val rdd1 = sc.parallelize(List(
      5, 7, 6, 4,
      9, 6, 1, 7,
      8, 2, 8, 5,
      4, 3, 10, 9
    ), 4)

    val res1: Array[Int] = rdd1.top(2)
    //指定排序规则，如果没有指定，使用默认的排序规则
    implicit val ord = Ordering[Int].reverse
    val res2: Array[Int] = rdd1.top(2)
    val res3: Array[Int] = rdd1.top(2)(Ordering[Int].reverse)

  }
}
