package cn.doitedu.day02

import java.sql.DriverManager

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

/**
 * 将RDD中的数据，以分区为单位，进行相应的处理
 *
 * 即mapPartitions方法函数的输入是一个迭代器，函数的返回值也必须是迭代器
 *
 */
object C06_MapPartitionsDemo {


  def main(args: Array[String]): Unit = {


    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //商品ID,商品分类ID,商品的金额
    //测试数据，以后生成环境会有非常多的数据，比如每天有几千万的订单数据
    val orders = List(
      ("o01", 11, 88.88),
      ("o02", 12, 78.88),
      ("o03", 13, 98.88),
      ("o04", 18, 198.88)
    )

    //经过运算，关联MySQL中的商品分类名称，返回入如下的数据
    //("o01", 11, "图书", 88.88),
    val rdd1 = sc.parallelize(orders)

    //在Driver创建(会报序列化的问题)
    //val connection = DriverManager.getConnection("jdbc:mysql://node-1.51doit.cn:3306/doit35?characterEncoding=utf-8", "root", "123456")

    //查询MySQL，关联维度数据，然后一个新的RDD
    //    val rdd2: RDD[(String, Int, String, Double)] = rdd1.map(e => {
    //      val cid = e._2
    //      //根据ID查找MySQL中维度的名称
    //      val connection = DriverManager.getConnection("jdbc:mysql://node-1.51doit.cn:3306/doit35?characterEncoding=utf-8", "root", "123456")
    //      val preparedStatement = connection.prepareStatement("SELECT name from tb_category where id = ?")
    //      preparedStatement.setInt(1, cid)
    //      val resultSet = preparedStatement.executeQuery()
    //      var name = "未知"
    //      if (resultSet.next()) {
    //        name = resultSet.getString(1)
    //      }
    //      (e._1, e._2, name, e._3)
    //    })

    //改进后，使用MapPartitions方法
    val rdd2 = rdd1.mapPartitions(it => {
      //val list = it.toList
      //事先窗口好连接
      val connection = DriverManager.getConnection("jdbc:mysql://node-1.51doit.cn:3306/doit35?characterEncoding=utf-8", "root", "123456")
      val preparedStatement = connection.prepareStatement("SELECT name from tb_category where id = ?")
      //一个分区中的多条数据用同一个连接对象
      it.map(e => {
        preparedStatement.setInt(1, e._2)
        val resultSet = preparedStatement.executeQuery()
        var name = "未知"
        if (resultSet.next()) {
          name = resultSet.getString(1)
        }
        (e._1, e._2, name, e._3)
      })
    })


    rdd2.saveAsTextFile("out/02")

    sc.stop()

  }

}
