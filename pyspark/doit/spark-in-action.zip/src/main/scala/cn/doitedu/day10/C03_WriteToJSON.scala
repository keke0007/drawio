package cn.doitedu.day10

import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * 读取Parquet文件中的数据，经过处理，写成JSON格式
 *
 */
object C03_WriteToJSON {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("SQLContinuedLogin")
      .master("local[*]")
      .getOrCreate()

    //有Schema信息
    val df: DataFrame = spark.read.parquet("data/data.snappy.parquet")

    df.printSchema()

    //对数据进行处理
    df.write.json("out/json")


  }


}
