package cn.doitedu.day05

import cn.doitedu.utils.SparkUtil

/**
 * Aggregate方法是Action
 */
object C04_AggregateDemo {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    val rdd1 = sc.parallelize(List(1,2,3,4,5,6,7,8,9,10), 4)

    val f1 = (a: Int, b: Int) => {
      println("f1 function invoked ~~~~")
      a + b
    }
    val f2 = (m: Int, n: Int) => {
      println("f2 function invoked !!!!")
      m + n
    }

    val r: Int = rdd1.aggregate(0)(f1, f2)


    //每个分区求最大值，返回将每个分区返回的结果再进行聚合
    rdd1.aggregate(0)((a,b) => if(a > b) a else b, (m, n) => m + n)


  }
}
