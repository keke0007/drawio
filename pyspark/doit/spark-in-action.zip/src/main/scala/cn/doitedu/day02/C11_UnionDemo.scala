package cn.doitedu.day02

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object C11_UnionDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)


    val rdd1 = sc.parallelize(List(1,2, 3,4), 2)

    val rdd2 = sc.parallelize(List(4,5, 6,7, 8,9), 3)

    //将两个类型一致的RDD Union到一起
    val rdd3: RDD[Int] = rdd1.union(rdd2)

    println(rdd3.partitions.length)
    println(rdd3.collect().toBuffer)

  }
}
