package cn.doitedu.day02

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object C10_FlatMapValuesDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    val lst = List(("spark", "1,2,3"), ("hive", "4,5"), ("hbase", "6"), ("flink", "7,8"))
    val rdd1: RDD[(String, String)] = sc.parallelize(lst, 2)
    //将value打平，再将打平后的每一个元素与key组合("spark", "1,2,3") =>（"spark",1）,（"spark",2）,（"spark",3）

//    val rdd2: RDD[(String, Int)] = rdd1.flatMap(t => {
//      val nums: Array[Int] = t._2.split(",").map(_.toInt)
//      nums.map((t._1, _))
//    })

    val rdd3: RDD[(String, Int)] = rdd1.flatMapValues(t => t.split(",").map(_.toInt))

    println(rdd3.collect().toBuffer)


  }
}
