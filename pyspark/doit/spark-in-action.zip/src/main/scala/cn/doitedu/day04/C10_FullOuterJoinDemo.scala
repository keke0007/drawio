package cn.doitedu.day04

import cn.doitedu.utils.SparkUtil
import org.apache.spark.rdd.RDD

/**
 * 为什么要join
 * 想要的数据来自多个RDD，并且数据之间存在着关联关系，那么就要多个RDD中的数据关联到一起
 *
 * 全连接，左面RDD（第一个RDD）或右面的RDD（第二个RDD）的数据只要出现就输出
 *
 *
 *
 */
object C10_FullOuterJoinDemo {

  def main(args: Array[String]): Unit = {

    val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, isLocal)

    //通过并行化的方式创建一个RDD
    val rdd1 = sc.parallelize(List(("tom", 1), ("tom", 2), ("jerry", 3), ("kitty", 2)), 2)
    //通过并行化的方式再创建一个RDD
    val rdd2 = sc.parallelize(List(("jerry", 2), ("tom", 1), ("shuke", 2), ("jerry", 4)), 2)

    val rdd3: RDD[(String, (Option[Int], Option[Int]))] = rdd1.fullOuterJoin(rdd2)

    rdd3.saveAsTextFile("out/09")
  }
}
