package cn.doitedu.day05

import java.sql.DriverManager

import cn.doitedu.utils.SparkUtil

/**
 * foreachPartition也是Action，传入的函数是以分区为单位进行处理
 */
object C14_ForeachPartitionsDemo {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    //假设RDD中有大量的数据，要将大量的数据写入到HBase、Redis、MySQL
    val rdd1 = sc.parallelize(List(
      5, 7, 6, 4,
      9, 6, 1, 7,
      8, 2, 8, 5,
      4, 3, 10, 9
    ), 4)

//    rdd1.foreach(e => {
//      //但是不好，为什么？
//      //每写一条数据用一个连接对象，效率太低了
//      val connection = DriverManager.getConnection("jdbc:mysql://node-1.51doit.cn:3306/doit35?characterEncoding=utf-8", "root", "123456")
//      val preparedStatement = connection.prepareStatement("Insert into tb_res values (?)")
//      preparedStatement.setInt(1, e)
//      preparedStatement.executeUpdate()
//    })


    rdd1.foreachPartition(it => {
      //先创建好一个连接对象
      val connection = DriverManager.getConnection("jdbc:mysql://node-1.51doit.cn:3306/doit35?characterEncoding=utf-8", "root", "123456")
      val preparedStatement = connection.prepareStatement("Insert into tb_res values (?)")
      //一个分区中的多条数据用一个连接进行处理
      it.foreach(e => {
        preparedStatement.setInt(1, e)
        preparedStatement.executeUpdate()
      })
      //用完后关闭连接
      preparedStatement.close()
      connection.close()
    })
  }
}
