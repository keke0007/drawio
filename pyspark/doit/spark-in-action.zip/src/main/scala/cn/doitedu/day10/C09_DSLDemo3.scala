package cn.doitedu.day10

import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * DSL风格的语法，就是直接调用DataFrame或Dataset上的方法（传入的不是函数，而是一种特殊的表达式），而不是写SQL
 *
 * 分组聚合运算， 分完组后，对多个字段进行聚合运算
 */
object C09_DSLDemo3 {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("SQLContinuedLogin")
      .master("local[*]")
      .getOrCreate()

    val df = spark.read.csv("data/stu.txt").toDF("name", "age", "gender")

    //    df.createTempView("v_user")
    //
    //    spark.sql(
    //      """
    //        |select
    //        |  gender,
    //        |  count(*) counts,
    //        |  avg(age) avg_age
    //        |from
    //        |  v_user
    //        |group by gender
    //        |""".stripMargin).show()

    import spark.implicits._
    import org.apache.spark.sql.functions._
    //分完组后，只能对age求平均数据，count是整个DataFrame的条数
    //val res = df.select($"gender", $"age".cast("int")).groupBy("gender").avg("age")


    val res: DataFrame = df.select($"gender", $"age".cast("int"))
      .groupBy("gender")
      .agg(
        count("*") as "counts",
        avg("age") as "avg_age"
      )

    res.show()


  }


}
