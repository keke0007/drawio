package cn.doitedu.day02

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

import scala.reflect.ClassTag

object C03_MapDemo {

  def main(args: Array[String]): Unit = {



    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //scala集合，在Driver端的JVM的普通集合
    val lst = List(1,2,3,4,5,6,7,8,9)

    //map是scala集合的方法，是一个单机集合，调用完map方法后，立即返回一个新的集合
    //val list2 = lst.map(_ * 10)


    val rdd1 = sc.parallelize(lst, 2)


    //调用Rdd的map方法，返回一个新的RDD，该方法是lazy（因为RDD的Transformation 是 lazy的）
    val rdd2: RDD[Int] = rdd1.map(x => x * 10)

    //有一个大胆的想法，不使用RDD的map方法，而是使用底层的MapPartitionsRDD，实现类似的功能

    //是一个比较底层RDD，只能在spark包，即子包中使用
    //private[spark] class MapPartitionsRDD[U: ClassTag, T: ClassTag](
    //new MapPartitionsRDD



  }

}
