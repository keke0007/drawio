package cn.doitedu.day03

import org.apache.spark._
import org.apache.spark.rdd.{RDD, ShuffledRDD}

/**
 * RepartitionAndSortWithInPartition
 * 按照指定的分区器重新分区，并且按照指定的排序规则，将数据在分区内排序（不是全局排序，仅是在分区内排序）
 */
object C08_RepartitionAndSortWithInPartition2Demo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    val lst: Seq[(String, Int)] = List(
      ("spark", 5), ("hadoop", 1), ("hive", 1), ("spark", 6),
      ("spark", 7), ("flink", 1), ("hbase", 1), ("spark", 3),
      ("kafka", 3), ("kafka", 1), ("kafka", 4), ("kafka", 1),
      ("hadoop", 3), ("flink", 4), ("hive", 1), ("flink", 3)
    )
    //通过并行化的方式创建RDD，分区数量为4
    val wordAndOne: RDD[(String, Int)] = sc.parallelize(lst, 4)

    //val partitioner = new HashPartitioner(4)


    //先按照单词的升序排序，然后再按照次数
    //参与排序的字段必须都作为key
    val tpRdd: RDD[((String, Int), Null)] = wordAndOne.map(t => (t, null))
    val partitioner = new MyHashPartitioner(4)
    implicit val ordering = new Ordering[(String, Int)] {
      override def compare(x: (String, Int), y: (String, Int)): Int = {
        if (x._1 != y._1) {
          Ordering[String].compare(x._1, y._1)
        } else {
          y._2 - x._2
        }
      }
    }
    //val partitioned = tpRdd.repartitionAndSortWithinPartitions(partitioner)

    val partitioned = new ShuffledRDD[(String, Int), Null, Null](tpRdd, partitioner)
    partitioned.setKeyOrdering(ordering)

    partitioned.saveAsTextFile("out/18")
  }


}


/**
 * 自定义的分区，按照单词的hashCode计算分区编号
 * @param partitiones
 */
class MyHashPartitioner(val partitiones: Int) extends Partitioner {
  override def numPartitions: Int = partitiones

  override def getPartition(key: Any): Int = {
    val word = key.asInstanceOf[(String, Int)]._1
    val rawMod = word.hashCode % partitiones
    rawMod + (if (rawMod < 0) partitiones else 0)

  }
}