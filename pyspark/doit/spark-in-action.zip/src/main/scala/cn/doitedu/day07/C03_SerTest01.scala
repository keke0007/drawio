package cn.doitedu.day07



import java.net.InetAddress

import cn.doitedu.utils.SparkUtil
import org.apache.spark.TaskContext

object C03_SerTest01 {


  def main(args: Array[String]): Unit = {

    val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, isLocal)

    //从HDFS中读取数据，创建RDD
    //HDFS指定的目录中有4个小文件,内容如下：
    //1,ln
    val lines = sc.textFile(args(1))

    //函数外部定义的一个引用类型（变量）
    //RuleObjectNotSer是一个静态对象，实在第一次使用的时候被初始化了（实在Driver被初始化的）
    val rulesObj = RuleObjectNotSer

    //处理数据，关联维度
    val res = lines.map(e => {
      val fields = e.split(",")
      val id = fields(0).toInt
      val code = fields(1)
      val name = rulesObj.rulesMap.getOrElse(code, "未知") //闭包
      //获取当前线程ID
      val treadId = Thread.currentThread().getId
      //获取当前Task对应的分区编号
      val partitiondId = TaskContext.getPartitionId()
      //获取当前Task运行时的所在机器的主机名
      val host = InetAddress.getLocalHost.getHostName
      (id, code, name, treadId, partitiondId, host, rulesObj.toString)
    })

    res.saveAsTextFile(args(2))
    sc.stop()

  }

}
