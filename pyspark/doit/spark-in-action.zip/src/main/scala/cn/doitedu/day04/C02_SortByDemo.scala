package cn.doitedu.day04

import cn.doitedu.utils.SparkUtil
import org.apache.spark.rdd.RDD

object C02_SortByDemo {

  def main(args: Array[String]): Unit = {

    val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, isLocal)

    //指定以后从哪里读取数据创建RDD
    val rdd1 = sc.parallelize(List(5, 3, 1, 9, 10, 11, 23, 4, 88, 55, 22, 5, 7, 8, 10), 4)

    //sortBy会触发Action，因为在sortBy方法内部，会对每个分区进行采样，构建分区规则（RangePartitioner）
    val sorted: RDD[Int] = rdd1.sortBy(x => x)

  }
}
