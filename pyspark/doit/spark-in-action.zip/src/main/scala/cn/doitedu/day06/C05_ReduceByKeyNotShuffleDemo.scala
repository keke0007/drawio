package cn.doitedu.day06

import org.apache.spark.rdd.RDD
import org.apache.spark.{HashPartitioner, SparkConf, SparkContext}


/**
 * ReduceByKey一般情况下都Shuffle，在特殊情况下可以不Shuffle
 */
object C05_ReduceByKeyNotShuffleDemo {

  def main(args: Array[String]): Unit = {


    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //创建RDD，并没有立即读取数据，而是触发Action才会读取数据
    val lines = sc.textFile("hdfs://node-1.51doit.cn:9000/words")

    val wordAndOne = lines.flatMap(_.split(" ")).map((_, 1))

    val partitioner = new HashPartitioner(2) //两个分区
    val partitioned = wordAndOne.partitionBy(partitioner)

    val reduced: RDD[(String, Int)] = partitioned.reduceByKey(new HashPartitioner(2), _ + _) //三个分区

    reduced.saveAsTextFile("hdfs://node-1.51doit.cn:9000/out-36-83")
  }

}
