package cn.doitedu.day07

import org.apache.spark.{SparkConf, SparkContext}

/**
 * 使用普通的变量，没法将每个Task的计数器返回到Driver
 *
 */
object C13_AcumulatorDemo2 {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    val rdd1 = sc.parallelize(List(1,2,3,4,5,6,7,8,9), 2)

    //在Driver定义的
    //定义一个普通的变量，是无法将每个Task的计数器返回到Driver
    var acc = 0

    val rdd2 = rdd1.map(e => {
      if (e % 2 == 0) {
        acc += 1  //闭包，在Executor中累计的
      }
      e * 10
    })

    //就触发一次Action
    rdd2.saveAsTextFile("out/112")

    //每个Task中累计的数据会返回到Driver吗？
    println(acc)



  }

}
