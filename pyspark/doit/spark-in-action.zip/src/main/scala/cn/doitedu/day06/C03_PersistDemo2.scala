package cn.doitedu.day06

import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}

object C03_PersistDemo2 {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //设置spark的序列化方式为KryoSerializer
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")

    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //创建RDD，并没有立即读取数据，而是触发Action才会读取数据
    val rdd1 = sc.textFile("hdfs://node-1.51doit.cn:9000/cache")

    //最好对数据过滤、整理后再进行cache
    val rdd2 = rdd1.filter(_.contains("bigdata"))

    //以指定的序列化方式，如果内存能放得下就全部放内存，如果内存放不下，再将其余的分区的数据放到本地磁盘
    rdd2.persist(StorageLevel.MEMORY_AND_DISK_SER)

    //第一次触发Action，速度不会很快，甚至要更慢一些
    val c1 = rdd2.count()

    //再次触发Action，会比以前快几十倍，因为数据不是从HDFS中读取的，而是内存中读取的
    val c2 = rdd2.count()

    //释放缓存的数据
    //blocking = false 为 异步释放缓存的数据
    //blocking = true 为 同步释放缓存的数据
    rdd2.unpersist(false)

  }
}
