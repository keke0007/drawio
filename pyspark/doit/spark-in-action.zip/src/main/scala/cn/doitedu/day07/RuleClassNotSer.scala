package cn.doitedu.day07

/**
 * 使用一个class类封装数据
 */
class RuleClassNotSer {

  val rulesMap = Map(
    "ln" -> "辽宁省",
    "sd" -> "山东省",
    "sh" -> "上海市",
    "bj" -> "北京市"
  )

}
