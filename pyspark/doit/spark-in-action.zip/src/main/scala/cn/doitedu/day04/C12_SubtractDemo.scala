package cn.doitedu.day04

import cn.doitedu.utils.SparkUtil
import org.apache.spark.rdd.RDD

/**
 * 求两个RDD的差集
 *
 *
 */
object C12_SubtractDemo {

  def main(args: Array[String]): Unit = {

    //val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, true)

    val rdd1 = sc.parallelize(List("A", "B", "C", "D", "E"))
    val rdd2 = sc.parallelize(List("A", "B"))

    val rdd3: RDD[String] = rdd1.subtract(rdd2)

    val res = rdd3.collect()
    println(res.toBuffer)
  }
}
