package cn.doitedu.day11

import cn.doitedu.day07.Boy
import cn.doitedu.utils.IpUtils
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.{Encoder, Encoders, SparkSession}
import org.apache.spark.sql.expressions.Aggregator

/**
 * 实现UDAF（自定义聚合函数）
 *
 */
object C06_UDAFDemo {

  def main(args: Array[String]): Unit = {

    val spark: SparkSession = SparkSession.builder()
      .appName("SQLDemo1")
      .master("local[*]")
      .getOrCreate() //创建一个SparkSession或使用已有的SparkSession

    val df = spark.read
      .csv("data/stu.txt")
      .toDF("name", "age", "gender")

    df.createTempView("v_student")

    import org.apache.spark.sql.functions._
    //注册UDAF，需要使用udaf方法将Aggregator转成UserDefinedFunction
    spark.udf.register("my_avg", udaf(new MyAvgFunction))

    val res = spark.sql(
      """
        |select gender, my_avg(age) avg_age from v_student group by gender
        |""".stripMargin)

    res.show()

  }
}

class MyAvgFunction extends Aggregator[Int, (Int, Int), Double] {
  //在每个分区每个组的初始值(总年龄，总人数)
  override def zero: (Int, Int) = (0, 0)

  //在每个分区中，每来一条数据调用一次reduce方法(局部聚合运算)
  override def reduce(buffer: (Int, Int), a: Int): (Int, Int) = {
    (buffer._1 + a, buffer._2 + 1)
  }
  //全局聚合
  override def merge(b1: (Int, Int), b2: (Int, Int)): (Int, Int) = {
    (b1._1 + b2._1, b1._2 + b2._2)
  }

  //计算最终的结果(每一个组调用一次fish)
  override def finish(reduction: (Int, Int)): Double = {
    reduction._1.toDouble / reduction._2
  }

  //指定中间结果的序列化方式
  override def bufferEncoder: Encoder[(Int, Int)] = {
    Encoders.tuple(Encoders.scalaInt, Encoders.scalaInt)
    //Encoders.bean(classOf[Boy])
  }

  //指定返回值的序列化方式
  override def outputEncoder: Encoder[Double] = {
    Encoders.scalaDouble
  }
}
