package cn.doitedu.day04

import cn.doitedu.utils.SparkUtil
import org.apache.spark.rdd.RDD

/**
 * repartition作用:
 *  1.改变并行度
 *  2.将数据均匀的重新分区
 *
 * 底层使用的coalesce，shuffle = true
 *
 */
object C04_ReparationDemo {

  def main(args: Array[String]): Unit = {

    val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, isLocal)

    //指定以后从哪里读取数据创建RDD
    val rdd1: RDD[Int] = sc.parallelize(List(1, 2, 3, 4, 5, 6, 7, 8, 9, 10), 4)

    //repartition底层调用的是 coalesce(numPartitions, shuffle = true)
    //shuffle = true 一定shuffle
    //底层使用分区编号+分区数量生成随机数作为key，这样的目的是为了将数据相对均匀的分到多个分区中，即将数据打散，避免数倾斜
    val rdd2: RDD[Int] = rdd1.repartition(4)

    rdd2.saveAsTextFile("out/08")
  }
}
