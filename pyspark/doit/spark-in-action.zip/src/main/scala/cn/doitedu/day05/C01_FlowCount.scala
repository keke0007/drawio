package cn.doitedu.day05

import java.text.SimpleDateFormat

import cn.doitedu.utils.SparkUtil
import org.apache.spark.rdd.RDD

object C01_FlowCount {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    val lines: RDD[String] = sc.textFile("data/data.csv")

    lines.map(line => {
      val fields = line.split(",")
      val uid = fields(0)
      val startTime = fields(1)
      val endTime = fields(2)
      val downFlow = fields(3).toDouble
      (uid, (startTime, endTime, downFlow))
    }).groupByKey()
      .flatMapValues(it => {
        var temp: String = null
        val sorted = it.toList.sortBy(_._1)
        val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        var flag = 0
        var sum = 0
        sorted.map(e => {
          val startTime = e._1
          val endTime = e._2
          val downFlow = e._3
          if (temp != null) {
            if (sdf.parse(startTime).getTime - sdf.parse(temp).getTime > 600000) {
              flag = 1
            } else {
              flag = 0
            }
          }
          sum += flag
          temp = endTime
          (startTime, endTime, downFlow, sum)
        })
      }).map { case (uid, (startTime, endTime, downFlow, sum)) => {
      ((uid, sum), (startTime, endTime, downFlow))
    }}.reduceByKey((a, b) => {
      (Ordering[String].min(a._1, b._1), Ordering[String].max(a._2, b._2), a._3 + b._3)
    }).map{case ((uid, sum), (startTime, endTime, downFlow)) => {
      (uid, startTime, endTime, downFlow)
    }}.saveAsTextFile("out/68")

  }
}
