package cn.doitedu.day03

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object JoinDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //通过并行化的方式创建一个RDD
    val rdd1 = sc.parallelize(List(("tom", 1), ("tom", 2), ("jerry", 3), ("kitty", 2)), 2)
    //通过并行化的方式再创建一个RDD
    val rdd2 = sc.parallelize(List(("jerry", 2), ("tom", 1), ("shuke", 2), ("jerry", 4)), 2)
    val rdd3: RDD[(String, Int)] = rdd1.intersection(rdd2)

//    val rdd1 = sc.parallelize(List("tom", "jerry"), 2)
//    val rdd2 = sc.parallelize(List("tom", "kitty", "shuke"), 3)
//    val rdd3 = rdd1.cartesian(rdd2)

    rdd3.saveAsTextFile("out/05")

  }
}
