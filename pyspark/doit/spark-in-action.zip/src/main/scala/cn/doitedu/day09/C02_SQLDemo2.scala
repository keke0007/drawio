package cn.doitedu.day09

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

import scala.beans.BeanProperty

/**
 * 使用scala的class创建DataFrame
 */
object C01_SQLDemo2 {

  def main(args: Array[String]): Unit = {

    val spark: SparkSession = SparkSession.builder()
      .appName("SQLDemo1")
      .master("local[*]")
      .getOrCreate() //创建一个SparkSession或使用已有的SparkSession

    //创建RDD
    val lines: RDD[String] = spark.sparkContext.textFile("data/boy.txt")
    //对RDD进行整理
    val boyRDD: RDD[SBoy] = lines.map(e => {
      val fields = e.split(",")
      val id = fields(0).toInt
      val name = fields(1)
      val age = fields(2).toInt
      val fv = fields(3).toDouble
      new SBoy(id, name, age, fv) //关联scala class，就是关联了schema
    })

    import spark.implicits._
    //只能RDD中类型为case class才能使用
    //boyRDD.toDF()     //报错

    //将RDD关联schema
    val df: DataFrame = spark.createDataFrame(boyRDD, classOf[SBoy])

    df.printSchema()

    //写DSL风格的语法（编程的语法，不是函数，而是sparksql提供的一种表达式）
    val df2: DataFrame = df.where($"age" >= 18).orderBy($"fv".desc, $"age" asc)

    df2.show()

    //释放资源
    spark.stop()


  }
}

/**
 *
 * 普通的scala的class,必须探究getter方法
 */
class SBoy(val id: Int,
           val name: String,
           @BeanProperty
           val age: Int,
           @BeanProperty
           val fv: Double
          ) {


  def getId(): Int = {
    id
  }

  def getName(): String = {
    name
  }
}