package cn.doitedu.day05

import cn.doitedu.utils.SparkUtil

/**
 * sum方法是Action，实现的逻辑只能是相加
 */
object C06_FoldDemo {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    val rdd1 = sc.parallelize(List(1,2,3,4,5,6,7,8,9,10), 4)
    //fold与reduce方法类似，该方法是一个柯里化方法，第一个括号传入的初始值是0.0
    //第二个括号传入的函数(_ + _) ，局部聚合和全局聚合都是相加
    val r = rdd1.fold(0)(_ + _)

  }
}
