package cn.doitedu.day03

import org.apache.spark._
import org.apache.spark.rdd.{RDD, ShuffledRDD}

/**
 * 按照指定的分区器进行分区
 */
object C06_PartitionByDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)


    val lst: Seq[(String, Int)] = List(
      ("spark", 5), ("hadoop", 1), ("hive", 1), ("spark", 1),
      ("spark", 7), ("flink", 1), ("hbase", 1), ("spark", 3),
      ("kafka", 1), ("kafka", 1), ("kafka", 1), ("kafka", 1),
      ("hadoop", 1), ("flink", 4), ("hive", 1), ("flink", 1)
    )
    //通过并行化的方式创建RDD，分区数量为4
    val wordAndOne: RDD[(String, Int)] = sc.parallelize(lst, 4)

    val partitioner = new HashPartitioner(4)
    //按照指定的分区器进行分区（会产生shuffle）
    //val partitioned: RDD[(String, Int)] = wordAndOne.partitionBy(partitioner)

    //partitionBy底层就是就是使用ShuffledRDD，传入了指定的分区器
    val partitioned = new ShuffledRDD[String, Int, Int](wordAndOne, partitioner)

    partitioned.saveAsTextFile("out/13")
  }
}
