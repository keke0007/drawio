package cn.doitedu.day11

import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * 将两个DataFrame进行join操作
 */
object C03_ExecutePlanDemo2 {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .appName("SQLContinuedLogin")
      .master("local[*]")
      .getOrCreate()


    //DSL风格的API
    val orderDF: DataFrame = spark.read.json("data/order.json")
    val categoryDF: DataFrame = spark.read.json("data/category.json")

    import spark.implicits._

    //在生成执行计划时，按照代价进行了优化，使用了broadcast join
    val df = orderDF.join(categoryDF, $"cid" === $"id", "left_outer")

    val res = df.filter($"oid" <= 20)

    res.explain(true)

    res.show()

    Thread.sleep(100000000)

  }

}
