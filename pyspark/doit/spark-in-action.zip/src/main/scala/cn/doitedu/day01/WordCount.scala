package cn.doitedu.day01

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object WordCount {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setAppName("WordCount")
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //2.创建RDD（神奇的大集合，该集合中不装真正要计算的数据，而是装描述信息）
    val lines: RDD[String] = sc.textFile(args(0))

    //3.对RDD进行转换操作，调用RDD的方法（
    // ------Transformation (转换算子开始)---------
    //切分压平
    val words: RDD[String] = lines.flatMap(_.split(" "))

    //将单词和1组合放入到元组中
    val wordAndOne: RDD[(String, Int)] = words.map((_, 1))

    //将key相同的数据进行分组聚合
    val reduced: RDD[(String, Int)] = wordAndOne.reduceByKey(_ + _)

    //按照次数排序
    val sorted: RDD[(String, Int)] = reduced.sortBy(_._2, false)
    // ------Transformation (转换算子结束)---------

    //4.调用Action
    //将数据写入到外部的存储系统中
    sorted.saveAsTextFile(args(1))

    //5.释放资源
    sc.stop()

  }

}
