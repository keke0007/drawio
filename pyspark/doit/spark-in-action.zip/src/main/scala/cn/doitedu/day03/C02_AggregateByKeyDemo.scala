package cn.doitedu.day03

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

/**
 * aggregateByKey与reduceByKey功能一样，只不是一个柯里化方法，第一个括号可以传入初始值，该初始值只在每一个分区局部聚合时，应用一次，
 * 第二个括号，要传入两个函数，分别是局部聚合和全局聚合的运算逻辑（该方法更灵活，局部聚合和全局聚合的逻辑可以相同，也可以不同）
 */
object C02_AggregateByKeyDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)


    val lst: Seq[(String, Int)] = List(
      ("spark", 5), ("hadoop", 1), ("hive", 1), ("spark", 1),
      ("spark", 7), ("flink", 1), ("hbase", 1), ("spark", 3),
      ("kafka", 1), ("kafka", 1), ("kafka", 1), ("kafka", 1),
      ("hadoop", 1), ("flink", 4), ("hive", 1), ("flink", 1)
    )
    //通过并行化的方式创建RDD，分区数量为4
    val wordAndOne: RDD[(String, Int)] = sc.parallelize(lst, 4)

    //wordAndOne.aggregateByKey(0)(_+_, _+_)
    val res = wordAndOne.aggregateByKey(0)(math.max(_, _), _+_)

    println(res.collect().toBuffer)
  }
}
