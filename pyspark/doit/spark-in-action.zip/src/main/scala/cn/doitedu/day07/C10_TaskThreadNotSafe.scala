package cn.doitedu.day07

import cn.doitedu.utils.DateUtilObj
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

/**
 * 演示一个Executor中多个Task，访问一个共享对象（工具类），同时有读写操作，会出现线程不安全的问题
 */
object C10_TaskThreadNotSafe {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    val lines = sc.textFile("data/date.txt")

    val timeRDD: RDD[Long] = lines.map(e => {
      //将字符串转成long类型时间戳
      //使用自定义的object工具类
      val time: Long = DateUtilObj.parse(e)
      time
    })

    val res = timeRDD.collect()
    println(res.toBuffer)
  }

}
