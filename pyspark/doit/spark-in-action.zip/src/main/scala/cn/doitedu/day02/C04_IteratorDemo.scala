package cn.doitedu.day02

import scala.io.Source

/**
 * 迭代器和迭代器链
 */
object C04_IteratorDemo {


  def main(args: Array[String]): Unit = {


    val source = Source.fromFile("data/words.txt")

    //返回的是迭代器，但是该迭代器还没有开始迭代数据
    val lines: Iterator[String] = source.getLines()


    val filtered: Iterator[String] = lines.filter(line => {
      !line.startsWith("error")
    })

    val upper: Iterator[String] = filtered.map(line => {
      println(666)
      line.toUpperCase
    })

    while (upper.hasNext) {
      val e = upper.next()
      println(e)
    }





    source.close()
  }

}
