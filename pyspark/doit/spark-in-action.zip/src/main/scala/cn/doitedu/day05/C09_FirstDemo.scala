package cn.doitedu.day05

import cn.doitedu.utils.SparkUtil

/**
 * sum方法是Action，实现的逻辑只能是相加
 */
object C09_FirstDemo {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    val rdd1 = sc.parallelize(List(5,7 ,9,6,1 ,8,2, 4,3,10), 4)
    //返回RDD中对应的第一条数据
    val r: Int = rdd1.first()

  }
}
