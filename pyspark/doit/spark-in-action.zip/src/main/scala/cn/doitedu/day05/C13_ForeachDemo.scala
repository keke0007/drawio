package cn.doitedu.day05

import java.sql.DriverManager

import cn.doitedu.utils.SparkUtil

/**
 * foreach是Action，传入的函数是一条一条的处理
 */
object C13_ForeachDemo {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    //假设RDD中有大量的数据，要将大量的数据写入到HBase、Redis、MySQL
    val rdd1 = sc.parallelize(List(
      5, 7, 6, 4,
      9, 6, 1, 7,
      8, 2, 8, 5,
      4, 3, 10, 9
    ), 4)

    rdd1.foreach(e => {
      //但是不好，为什么？
      //每写一条数据用一个连接对象，效率太低了
      val connection = DriverManager.getConnection("jdbc:mysql://node-1.51doit.cn:3306/doit35?characterEncoding=utf-8", "root", "123456")
      val preparedStatement = connection.prepareStatement("Insert into tb_res values (?)")
      preparedStatement.setInt(1, e)
      preparedStatement.executeUpdate()
    })
  }
}
