package cn.doitedu.day02

/**
 * HashPartitioner的特点，key相同的，一定会被分到同一个分区，但是同一个分区中，可能会有多个不同的key
 */
object C13_HashPartitionerDemo {


  def nonNegativeMod(x: Int, mod: Int): Int = {
    val rawMod = x % mod
    rawMod + (if (rawMod < 0) mod else 0)
  }

  def main(args: Array[String]): Unit = {

    //val key = "spark"
    val key = "hadoop"

    val partition = nonNegativeMod(key.hashCode, 4)

    println(partition)





  }
}
