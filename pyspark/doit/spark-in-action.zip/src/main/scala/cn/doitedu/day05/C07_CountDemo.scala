package cn.doitedu.day05

import cn.doitedu.utils.SparkUtil

/**
 * count方法是Action，统计RDD中对应数据的条数
 */
object C07_CountDemo {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    val rdd1 = sc.parallelize(List(5,7 ,9,6,1 ,8,2, 4,3,10), 4)
    //在每个分区内先计算每个分区对应的数据条数（使用的是边遍历，边计数）
    //然后再将每个分区返回的条数，在Driver进行求和
    val r: Long = rdd1.count()

  }
}
