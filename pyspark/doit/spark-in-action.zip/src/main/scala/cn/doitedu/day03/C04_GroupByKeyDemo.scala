package cn.doitedu.day03

import org.apache.spark.rdd.{RDD, ShuffledRDD}
import org.apache.spark._

import scala.collection.mutable.ArrayBuffer

/**
 * groupByKey，按照指定的key进行分组（不聚合）
 * 将key相同的value，通过shuffle，传输到同一个分区的同一个组内
 */
object C04_GroupByKeyDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)


    val lst: Seq[(String, Int)] = List(
      ("spark", 5), ("hadoop", 1), ("hive", 1), ("spark", 1),
      ("spark", 7), ("flink", 1), ("hbase", 1), ("spark", 3),
      ("kafka", 1), ("kafka", 1), ("kafka", 1), ("kafka", 1),
      ("hadoop", 1), ("flink", 4), ("hive", 1), ("flink", 1)
    )
    //通过并行化的方式创建RDD，分区数量为4
    val wordAndOne: RDD[(String, Int)] = sc.parallelize(lst, 4)

    //groupByKey底层使用的是CombineByKeyWithClassTag, mapSideCombine = false
    //三个函数只会执行前两个，并且都是在下游执行的
    val grouped: RDD[(String, Iterable[Int])] = wordAndOne.groupByKey()

    //不使用groupByKey方法，而是使用ShuffledRDD实现同样的功能


    val partitioner = new HashPartitioner(wordAndOne.partitions.length)
    val shuffledRDD = new ShuffledRDD[String, Int, ArrayBuffer[Int]](wordAndOne, partitioner)

    val f1 = (x: Int) => ArrayBuffer(x)
    val f2 = (ab: ArrayBuffer[Int], e: Int) => ab += e
    val f3 = (a1: ArrayBuffer[Int], a2: ArrayBuffer[Int]) => a1 ++= a2

    val aggregator = new Aggregator[String, Int, ArrayBuffer[Int]](f1, f2, f3)

    shuffledRDD.setAggregator(aggregator)
    shuffledRDD.setMapSideCombine(false)

    shuffledRDD.saveAsTextFile("out/10")

  }
}
