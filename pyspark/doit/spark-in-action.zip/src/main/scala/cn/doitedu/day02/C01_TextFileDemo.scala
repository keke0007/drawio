package cn.doitedu.day02

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

/**
 * 使用本地模式运行Spark程序（开发调试的时候）
 */
object C01_TextFileDemo {

  def main(args: Array[String]): Unit = {

    //指定当前用户为root
    System.setProperty("HADOOP_USER_NAME", "root")

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //2.创建RDD（神奇的大集合，该集合中不装真正要计算的数据，而是装描述信息）
    //val lines: RDD[String] = sc.textFile("hdfs://node-1.51doit.cn:9000/test1")
    val lines: RDD[String] = sc.textFile("hdfs://node-1.51doit.cn:9000/splits")


    val r = lines.collect()



    //5.释放资源
    sc.stop()

  }

}
