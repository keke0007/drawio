package cn.doitedu.day04

import cn.doitedu.utils.SparkUtil
import org.apache.spark.rdd.RDD

/**
 * 求两个RDD的交集
 *
 *
 */
object C11_IntersectionDemo {

  def main(args: Array[String]): Unit = {

    //val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, true)

    val rdd1 = sc.parallelize(List(1,2,3,4,4,6), 2)
    val rdd2 = sc.parallelize(List(3,4,5,6,7,8), 2)

    //求两个RDD共有的数据，即交集
    val rdd3: RDD[Int] = rdd1.intersection(rdd2)

    val rdd11 = rdd1.map((_, null))
    val rdd22 = rdd2.map((_, null))

    val rdd33: RDD[(Int, (Iterable[Null], Iterable[Null]))] = rdd11.cogroup(rdd22)

    val rdd44: RDD[Int] = rdd33.filter { case (_, (it1, it2)) => it1.nonEmpty && it2.nonEmpty }.keys

    rdd44.saveAsTextFile("out/15")
  }
}
