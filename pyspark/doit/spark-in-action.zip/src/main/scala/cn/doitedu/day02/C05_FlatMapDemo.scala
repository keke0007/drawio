package cn.doitedu.day02

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

object C05_FlatMapDemo {

  def main(args: Array[String]): Unit = {



    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //scala集合，在Driver端的JVM的普通集合
    val arr = Array(
      "spark hive flink spark",
      "hive hive flink flink",
      "hive spark flink spark",
      "hive spark flink hive"
    )
    val rdd1: RDD[String] = sc.makeRDD(arr)
    val rdd2: RDD[String] = rdd1.flatMap(_.split(" "))





  }

}
