package cn.doitedu.day02

import org.apache.spark.rdd.{PairRDDFunctions, RDD}
import org.apache.spark.{SparkConf, SparkContext}

object C09_ValuesDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    val lst: Seq[(String, Int)] = List(
      ("spark", 1), ("hadoop", 1), ("hive", 1), ("spark", 1),
      ("spark", 1), ("flink", 1), ("hbase", 1), ("spark", 1),
      ("kafka", 1), ("kafka", 1), ("kafka", 1), ("kafka", 1),
      ("hadoop", 1), ("flink", 1), ("hive", 1), ("flink", 1)
    )
    //通过并行化的方式创建RDD，分区数量为4
    val wordAndOne: RDD[(String, Int)] = sc.parallelize(lst, 4)


    //不使用隐式转换
    //val pairRDDFunc = new PairRDDFunctions[String, Int](wordAndOne)
    //val valueRDD = pairRDDFunc.values

    //是因为RDD中有一个隐式转换方法
    //    implicit def rddToPairRDDFunctions[K, V](rdd: RDD[(K, V)])
    //      (implicit kt: ClassTag[K], vt: ClassTag[V], ord: Ordering[K] = null): PairRDDFunctions[K, V] = {
    //      new PairRDDFunctions(rdd)
    //    }
    //将RDD[(K,V)] => PairRDDFunction[K, V]
    val valueRDD: RDD[Int] = wordAndOne.values


    //也可以使用map实现累的的功能
    val valueRdd2: RDD[Int] = wordAndOne.map(_._2)

    val res = valueRDD.collect()

    println(res.toBuffer)
  }

}
