package cn.doitedu.day04

import cn.doitedu.utils.SparkUtil
import org.apache.spark.rdd.RDD

/**
 * groupBy、groupByKey是对【一个RDD】，使用HashPartitioner对RDD中多个分区中对应的数据进行分组
 *
 * Cogroup叫协同分组、联合分组，对多个RDD中对应的数据，使用HashPartitioner进行分组，可以保证来自多个RDD中key相同的数据被分到同一个分区的同一个组内
 *
 */
object C06_CogroupDemo {

  def main(args: Array[String]): Unit = {

    val isLocal = args(0).toBoolean
    val sc = SparkUtil.getContext(this.getClass.getSimpleName, isLocal)

    //通过并行化的方式创建一个RDD
    val rdd1 = sc.parallelize(List(("tom", 1), ("tom", 2), ("jerry", 3), ("kitty", 2)), 2)
    //通过并行化的方式再创建一个RDD
    val rdd2 = sc.parallelize(List(("jerry", 2), ("tom", 1), ("shuke", 2), ("jerry", 4)), 2)
    //将两个RDD都进行分组
    val grouped: RDD[(String, (Iterable[Int], Iterable[Int]))] = rdd1.cogroup(rdd2)


  }
}
