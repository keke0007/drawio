package cn.doitedu.day11

import cn.doitedu.utils.IpUtils
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession

/**
 *
 * 使用SQL计算IP地址的归宿地
 *
 * Spark SQL 的自定义函数
 *
 * User Defined Function
 *
 * 自定义函数分为3中
 * UDF  输入一行，返回一行
 * UDAF 输入多行，返回一行（一个组返回一行）
 * UDTF 输入一行，返回多行
 *
 */
object C05_UDFDemo2 {

  def main(args: Array[String]): Unit = {

    val spark: SparkSession = SparkSession.builder()
      .appName("SQLDemo1")
      .master("local[*]")
      .getOrCreate() //创建一个SparkSession或使用已有的SparkSession

    val df = spark.read
      .option("delimiter", "|")
      .csv("data/ipaccess.log")

    import spark.implicits._

    df.select($"_c1" as "ip").createTempView("v_ips")

    val sc = spark.sparkContext
    val ipLines = sc.textFile("data/ip.txt")
    val ipRulesInDriver: Array[(Long, Long, String, String)] = ipLines.map(e => {
      val fields = e.split("[|]")
      val startNum = fields(2).toLong
      val endNum = fields(3).toLong
      val province = fields(6)
      val city = fields(7)
      (startNum, endNum, province, city)
    }).collect()

    val broadcastRef: Broadcast[Array[(Long, Long, String, String)]] = sc.broadcast(ipRulesInDriver)

    //UDF，在Executor中的Task执行的
    val ipToLocation = (ip: String) => {
      val ipRulesInExecutor: Array[(Long, Long, String, String)] = broadcastRef.value
      val ipNum = IpUtils.ip2Long(ip)
      val index = IpUtils.binarySearch(ipRulesInExecutor, ipNum)
      var name = "未知"
      if (index > -1) {
        name = ipRulesInExecutor(index)._3
      }
      name
    }

    spark.udf.register("ip2Location", ipToLocation)

    val res = spark.sql(
      """
        |select ip, ip2Location(ip) location from v_ips
        |""".stripMargin)

    res.show()
  }
}
