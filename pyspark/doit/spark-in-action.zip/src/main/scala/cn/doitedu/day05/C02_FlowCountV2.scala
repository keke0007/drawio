package cn.doitedu.day05

import java.text.SimpleDateFormat

import cn.doitedu.utils.SparkUtil
import org.apache.spark.Partitioner
import org.apache.spark.rdd.RDD

object C02_FlowCountV2 {

  def main(args: Array[String]): Unit = {

    val sc = SparkUtil.getContext("FlowCount", true)

    val lines: RDD[String] = sc.textFile("data/data.csv")

    val uidStartTimeAndEndTimeDownFlow: RDD[((String, String), (String, Double))] = lines.map(line => {
      val fields = line.split(",")
      val uid = fields(0)
      val startTime = fields(1)
      val endTime = fields(2)
      val downFlow = fields(3).toDouble
      ((uid, startTime), (endTime, downFlow))
    })

    //分区且在分区内排序，key是tuple2(uid, startTime)
    val partitioner = new MyHashPartitioner(uidStartTimeAndEndTimeDownFlow.partitions.length)
    val partitionedAndSorted = uidStartTimeAndEndTimeDownFlow.repartitionAndSortWithinPartitions(partitioner)

    partitionedAndSorted.mapPartitions(it => {
      var tempUid: String = null
      var temp: String = null
      var flag = 0
      var sum = 0
      val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      it.map { case ((uid, startTime), (endTime, downFlow)) => {
        if (tempUid.equals(uid)) { //同一个用户的数据
          if(temp != null) {
            if (sdf.parse(startTime).getTime - sdf.parse(temp).getTime > 600000) {
              flag = 1
            } else {
              flag = 0
            }
          }
          sum += flag
        } else {
          temp = null
          flag = 0
          sum = 0
        }
        tempUid = uid
        temp = endTime
        ((uid, sum), (startTime, endTime, downFlow))
      }}
    }).saveAsTextFile("out/72")
  }
}

class MyHashPartitioner(length: Int) extends Partitioner {

  override def numPartitions: Int = length

  override def getPartition(key: Any): Int = {
    val uid = key.asInstanceOf[(String, String)]._1
    val rawMod = uid.hashCode % length
    rawMod + (if (rawMod < 0) length else 0)
  }
}
