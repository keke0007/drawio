package cn.doitedu.day02

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

/**
 * 通过并行化的方式创建RDD，即将Driver的一个结合，转换成一个分布式数据集RDD
 * （这种创建RDD的方式通常是用于做测试或实验，）
 */
object C02_ParallelizeDemo {

  def main(args: Array[String]): Unit = {

    //指定当前用户为root
    System.setProperty("HADOOP_USER_NAME", "root")

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //scala集合，在Driver端的JVM的普通集合
    val lst = List(1,2,3,4,5,6,7,8,9)

    //如果不指定分区数据，默认的并行度与执行环境的并行度保存一致
    val rdd1 = sc.parallelize(lst)

    //也可以人为指定分区数量
    //RDD中每个分区中的数据会相对均匀的分散到每个分区中，避免数据倾斜
    val rdd2 = sc.makeRDD(lst, 2)

    val r = rdd2.count()

    println(r)
    //5.释放资源
    sc.stop()

  }

}
