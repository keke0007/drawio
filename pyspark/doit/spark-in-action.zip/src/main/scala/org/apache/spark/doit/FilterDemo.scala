package org.apache.spark.doit

import org.apache.spark.rdd.{MapPartitionsRDD, RDD}
import org.apache.spark.{SparkConf, SparkContext}

object FilterDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //scala集合，在Driver端的JVM的普通集合
    val lst = List(1,2,3,4,5,6,7,8,9)

    //map是scala集合的方法，是一个单机集合，调用完map方法后，立即返回一个新的集合
    //val list2 = lst.map(_ * 10)


    val rdd1 = sc.parallelize(lst, 2)

    val func = (x: Int) => x % 2 == 0

    val rdd2 = new MapPartitionsRDD[Int, Int](
      rdd1,
      (_, _, it) => it.filter(func) //对RDD中的每个分区进行操作（调用方法、传入函数）
    )

    rdd2.saveAsTextFile("out4")

    sc.stop()



  }

}
