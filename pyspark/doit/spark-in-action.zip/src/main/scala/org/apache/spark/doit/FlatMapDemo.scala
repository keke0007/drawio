package org.apache.spark.doit

import org.apache.spark.rdd.{MapPartitionsRDD, RDD}
import org.apache.spark.{SparkConf, SparkContext, TaskContext}

object FlatMapDemo {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf()
      .setAppName("WordCount")
      .setMaster("local[*]") //本地模式，开多个线程
    //1.创建SparkContext
    val sc = new SparkContext(conf)

    //scala集合，在Driver端的JVM的普通集合
    val arr = Array(
      "spark hive flink spark",
      "hive hive flink flink",
      "hive spark flink spark",
      "hive spark flink hive"
    )
    val rdd1: RDD[String] = sc.makeRDD(arr)

    val f = (x: String) => x.split(" ").toIterator
    //val rdd2: RDD[String] = rdd1.flatMap(f)

    val rdd2 = new MapPartitionsRDD[String, String](
      rdd1,
      (tc: TaskContext, index: Int, it: Iterator[String]) => it.flatMap(f) //
    )

    rdd2.saveAsTextFile("out2")


    sc.stop()



  }

}
