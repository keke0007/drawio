#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__version__ = 'v0.8.1'
