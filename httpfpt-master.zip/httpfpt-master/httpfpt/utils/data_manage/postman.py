#!/usr/bin/env python3
# -*- coding: utf-8 -*-


def import_postman_file() -> None:
    ...
    # todo
