#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from rich import get_console

console = get_console()
