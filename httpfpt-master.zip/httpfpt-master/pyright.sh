#!/usr/bin/env bash

pyright -p . --verbose
