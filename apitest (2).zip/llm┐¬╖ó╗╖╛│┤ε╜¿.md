## 1.python虚拟环境搭建

```
python使用python3.10
conda create --name llm3.10 python=3.10
全局配置pip镜像地址

全局使用
pip config set global.index-url 镜像地址

镜像 https://mirrors.cloud.tencent.com/pypi/simple
```

## 2.pycharm环境配置

```
1.格式化配置
Tools--Actions on Save---Reformat code & Optimize imports
2.文件注释模板
File and Code Templates
--Python Script
3.插件推荐
.env files support
codeglance pro
```

## 3.依赖的安装

```
pip freeze > requirements.txt  会安装其他无关无关竟要的包

通过pipreqs安装依赖
pip install --no-deps pipreqs
pip install  yarg==0.1.9 docopt==0.6.2

pipreqs --ignore venv --force


requirements.txt文件的安装
pip install -r requirements.txt会自动安装requirements.txt文件中的依赖

```



